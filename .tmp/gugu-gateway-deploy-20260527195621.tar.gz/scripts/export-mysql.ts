import { Database } from 'bun:sqlite'
import { once } from 'node:events'
import * as fs from 'node:fs'
import * as fsp from 'node:fs/promises'
import * as path from 'node:path'
import { loadGatewayConfig } from '../src/config.js'

const args = process.argv.slice(2)

type ColumnType = 'datetime' | 'number' | 'text'

type ColumnSpec = {
  name: string
  type: ColumnType
}

type TableSpec = {
  name: string
  orderBy: string
  columns: ColumnSpec[]
}

const TABLES: TableSpec[] = [
  {
    name: 'devices',
    orderBy: 'device_id',
    columns: [
      { name: 'device_id', type: 'text' },
      { name: 'device_token', type: 'text' },
      { name: 'plan', type: 'text' },
      { name: 'credits_total', type: 'number' },
      { name: 'credits_remaining', type: 'number' },
      { name: 'expires_at', type: 'datetime' },
      { name: 'license_key', type: 'text' },
      { name: 'app_version', type: 'text' },
      { name: 'platform', type: 'text' },
      { name: 'created_at', type: 'datetime' },
      { name: 'updated_at', type: 'datetime' },
      { name: 'last_seen_at', type: 'datetime' },
    ],
  },
  {
    name: 'activation_codes',
    orderBy: 'license_key',
    columns: [
      { name: 'license_key', type: 'text' },
      { name: 'plan', type: 'text' },
      { name: 'credits_total', type: 'number' },
      { name: 'expires_at', type: 'datetime' },
      { name: 'max_activations', type: 'number' },
      { name: 'activations', type: 'number' },
      { name: 'disabled_at', type: 'datetime' },
      { name: 'created_at', type: 'datetime' },
      { name: 'package_id', type: 'text' },
      { name: 'activation_kind', type: 'text' },
    ],
  },
  {
    name: 'usage_events',
    orderBy: 'id',
    columns: [
      { name: 'id', type: 'number' },
      { name: 'device_id', type: 'text' },
      { name: 'kind', type: 'text' },
      { name: 'model', type: 'text' },
      { name: 'credits', type: 'number' },
      { name: 'input_tokens', type: 'number' },
      { name: 'output_tokens', type: 'number' },
      { name: 'created_at', type: 'datetime' },
      { name: 'metadata', type: 'text' },
    ],
  },
  {
    name: 'orders',
    orderBy: 'id',
    columns: [
      { name: 'id', type: 'number' },
      { name: 'order_id', type: 'text' },
      { name: 'package_id', type: 'text' },
      { name: 'package_name', type: 'text' },
      { name: 'package_kind', type: 'text' },
      { name: 'plan', type: 'text' },
      { name: 'credits', type: 'number' },
      { name: 'amount_cents', type: 'number' },
      { name: 'currency', type: 'text' },
      { name: 'status', type: 'text' },
      { name: 'contact', type: 'text' },
      { name: 'license_key', type: 'text' },
      { name: 'order_token', type: 'text' },
      { name: 'payment_provider', type: 'text' },
      { name: 'payment_code_url', type: 'text' },
      { name: 'payment_expires_at', type: 'datetime' },
      { name: 'wechat_transaction_id', type: 'text' },
      { name: 'wechat_trade_state', type: 'text' },
      { name: 'wechat_success_time', type: 'datetime' },
      { name: 'alipay_trade_no', type: 'text' },
      { name: 'alipay_trade_status', type: 'text' },
      { name: 'alipay_success_time', type: 'datetime' },
      { name: 'paid_amount_cents', type: 'number' },
      { name: 'payment_payload', type: 'text' },
      { name: 'created_at', type: 'datetime' },
      { name: 'updated_at', type: 'datetime' },
      { name: 'paid_at', type: 'datetime' },
      { name: 'fulfilled_at', type: 'datetime' },
      { name: 'cancelled_at', type: 'datetime' },
    ],
  },
  {
    name: 'payment_notifications',
    orderBy: 'id',
    columns: [
      { name: 'id', type: 'number' },
      { name: 'provider', type: 'text' },
      { name: 'notification_id', type: 'text' },
      { name: 'transaction_id', type: 'text' },
      { name: 'order_id', type: 'text' },
      { name: 'status', type: 'text' },
      { name: 'error_message', type: 'text' },
      { name: 'payload', type: 'text' },
      { name: 'created_at', type: 'datetime' },
      { name: 'updated_at', type: 'datetime' },
      { name: 'processed_at', type: 'datetime' },
    ],
  },
]

async function main(): Promise<void> {
  const config = loadGatewayConfig()
  const dbPath = path.resolve(readArg('--db', config.dbPath))
  const outPath = path.resolve(readArg('--out', defaultOutputPath(dbPath)))
  const manifestPath = path.resolve(readArg('--manifest', `${outPath}.manifest.json`))
  const batchSize = readPositiveIntArg('--batch-size', 250)

  assertReadableFile(dbPath)
  await fsp.mkdir(path.dirname(outPath), { recursive: true })
  await fsp.mkdir(path.dirname(manifestPath), { recursive: true })

  const db = new Database(dbPath, { readonly: true })
  const tmpOutPath = `${outPath}.tmp.${process.pid}`
  try {
    assertExpectedTables(db)
    await fsp.rm(tmpOutPath, { force: true }).catch(() => {})
    const manifest = await exportDataOnlySql(db, dbPath, tmpOutPath, batchSize)
    await fsp.rename(tmpOutPath, outPath)
    const completedManifest = {
      ...manifest,
      outputPath: outPath,
      manifestPath,
      outputBytes: fs.statSync(outPath).size,
    }
    await fsp.writeFile(manifestPath, `${JSON.stringify(completedManifest, null, 2)}\n`)
    console.log(JSON.stringify(completedManifest, null, 2))
  } finally {
    db.close()
    await fsp.rm(tmpOutPath, { force: true }).catch(() => {})
  }
}

async function exportDataOnlySql(
  db: Database,
  dbPath: string,
  outPath: string,
  batchSize: number,
): Promise<Record<string, unknown>> {
  const stream = fs.createWriteStream(outPath, { encoding: 'utf8' })
  const generatedAt = new Date().toISOString()
  const tableSummaries: Record<string, { rows: number }> = {}

  try {
    await writeLine(stream, '-- Gugu Gateway SQLite to MySQL data export.')
    await writeLine(stream, `-- Generated at: ${generatedAt}`)
    await writeLine(stream, `-- Source SQLite: ${dbPath}`)
    await writeLine(stream, '-- Apply schema first: mysql ... gugu_gateway < deploy/mysql/schema.sql')
    await writeLine(stream, '-- Import only into an empty dry-run database until cutover is approved.')
    await writeLine(stream, '')
    await writeLine(stream, "SET NAMES utf8mb4 COLLATE utf8mb4_0900_ai_ci;")
    await writeLine(stream, "SET time_zone = '+00:00';")
    await writeLine(stream, 'SET FOREIGN_KEY_CHECKS = 0;')
    await writeLine(stream, 'START TRANSACTION;')
    await writeLine(stream, '')

    for (const table of TABLES) {
      const rows = await exportTable(db, stream, table, batchSize)
      tableSummaries[table.name] = { rows }
    }

    await writeLine(stream, 'COMMIT;')
    await writeLine(stream, 'SET FOREIGN_KEY_CHECKS = 1;')
    await writeLine(stream, '')
  } finally {
    stream.end()
    await once(stream, 'finish')
  }

  return {
    ok: true,
    generatedAt,
    dbPath,
    target: {
      engine: 'mysql',
      version: '8.4 LTS',
      schema: 'deploy/mysql/schema.sql',
    },
    batchSize,
    tables: tableSummaries,
    sourceTotals: buildSourceTotals(db),
  }
}

async function exportTable(
  db: Database,
  stream: fs.WriteStream,
  table: TableSpec,
  batchSize: number,
): Promise<number> {
  const columnNames = table.columns.map((column) => column.name)
  const quotedColumns = columnNames.map(quoteIdentifier).join(', ')
  const selectSql = `SELECT ${columnNames.join(', ')} FROM ${table.name} ORDER BY ${table.orderBy}`
  const query = db.query(selectSql)
  let batch: string[] = []
  let count = 0

  await writeLine(stream, `-- ${table.name}`)
  for (const row of query.iterate() as Iterable<Record<string, unknown>>) {
    const values = table.columns.map((column) => formatValue(row[column.name], column)).join(', ')
    batch.push(`(${values})`)
    count += 1
    if (batch.length >= batchSize) {
      await flushInsert(stream, table.name, quotedColumns, batch)
      batch = []
    }
  }
  if (batch.length > 0) {
    await flushInsert(stream, table.name, quotedColumns, batch)
  }
  if (count === 0) {
    await writeLine(stream, `-- ${table.name}: 0 rows`)
  }
  await writeLine(stream, '')
  return count
}

async function flushInsert(
  stream: fs.WriteStream,
  tableName: string,
  quotedColumns: string,
  rows: string[],
): Promise<void> {
  await writeLine(stream, `INSERT INTO ${quoteIdentifier(tableName)} (${quotedColumns}) VALUES`)
  await writeLine(stream, `${rows.join(',\n')};`)
}

function formatValue(value: unknown, column: ColumnSpec): string {
  if (value === null || value === undefined) return 'NULL'
  if (column.type === 'number') return formatNumber(value, column.name)
  if (column.type === 'datetime') return quoteString(formatMysqlDateTime(value, column.name))
  return quoteString(String(value))
}

function formatNumber(value: unknown, columnName: string): string {
  const numberValue = Number(value)
  if (!Number.isFinite(numberValue)) {
    throw new Error(`Cannot export non-numeric value for ${columnName}: ${String(value)}`)
  }
  return String(Math.trunc(numberValue))
}

function formatMysqlDateTime(value: unknown, columnName: string): string {
  const date = new Date(String(value))
  if (!Number.isFinite(date.getTime())) {
    throw new Error(`Cannot export invalid datetime for ${columnName}: ${String(value)}`)
  }
  const pad = (input: number, length = 2) => String(input).padStart(length, '0')
  return [
    date.getUTCFullYear(),
    '-',
    pad(date.getUTCMonth() + 1),
    '-',
    pad(date.getUTCDate()),
    ' ',
    pad(date.getUTCHours()),
    ':',
    pad(date.getUTCMinutes()),
    ':',
    pad(date.getUTCSeconds()),
    '.',
    pad(date.getUTCMilliseconds(), 3),
  ].join('')
}

function quoteString(value: string): string {
  return `'${value
    .replace(/\\/g, '\\\\')
    .replace(/\0/g, '\\0')
    .replace(/\n/g, '\\n')
    .replace(/\r/g, '\\r')
    .replace(/\x1a/g, '\\Z')
    .replace(/'/g, "''")}'`
}

function quoteIdentifier(value: string): string {
  return `\`${value.replace(/`/g, '``')}\``
}

async function writeLine(stream: fs.WriteStream, line: string): Promise<void> {
  if (stream.write(`${line}\n`)) return
  await once(stream, 'drain')
}

function buildSourceTotals(db: Database): Record<string, unknown> {
  return {
    devicesCreditsTotal: sumColumn(db, 'devices', 'credits_total'),
    devicesCreditsRemaining: sumColumn(db, 'devices', 'credits_remaining'),
    usageCredits: sumColumn(db, 'usage_events', 'credits'),
    usageInputTokens: sumColumn(db, 'usage_events', 'input_tokens'),
    usageOutputTokens: sumColumn(db, 'usage_events', 'output_tokens'),
    ordersAmountCents: sumColumn(db, 'orders', 'amount_cents'),
    ordersPaidAmountCents: sumColumn(db, 'orders', 'paid_amount_cents'),
  }
}

function sumColumn(db: Database, table: string, column: string): number {
  const row = db
    .query(`SELECT COALESCE(SUM(${column}), 0) AS value FROM ${table}`)
    .get() as { value: number } | null
  return Number(row?.value ?? 0)
}

function assertExpectedTables(db: Database): void {
  const rows = db
    .query("SELECT name FROM sqlite_master WHERE type = 'table'")
    .all() as Array<{ name: string }>
  const existing = new Set(rows.map((row) => row.name))
  const missing = TABLES.filter((table) => !existing.has(table.name)).map((table) => table.name)
  if (missing.length > 0) {
    throw new Error(`SQLite database is missing expected tables: ${missing.join(', ')}`)
  }
}

function assertReadableFile(filePath: string): void {
  const stat = fs.statSync(filePath, { throwIfNoEntry: false })
  if (!stat?.isFile()) {
    throw new Error(`SQLite database not found: ${filePath}`)
  }
}

function defaultOutputPath(dbPath: string): string {
  return path.join(
    path.dirname(dbPath),
    'exports',
    `gateway-mysql-import-${formatTimestamp(new Date())}.sql`,
  )
}

function formatTimestamp(date: Date): string {
  const pad = (value: number) => String(value).padStart(2, '0')
  return [
    date.getFullYear(),
    pad(date.getMonth() + 1),
    pad(date.getDate()),
    '-',
    pad(date.getHours()),
    pad(date.getMinutes()),
    pad(date.getSeconds()),
  ].join('')
}

function readArg(name: string, fallback: string): string {
  const index = args.indexOf(name)
  if (index === -1) return fallback
  return args[index + 1] ?? fallback
}

function readPositiveIntArg(name: string, fallback: number): number {
  const value = Number.parseInt(readArg(name, String(fallback)), 10)
  return Number.isFinite(value) && value > 0 ? Math.trunc(value) : fallback
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error))
  process.exit(1)
})
