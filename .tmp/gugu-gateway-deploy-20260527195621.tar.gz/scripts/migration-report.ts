import { Database } from 'bun:sqlite'
import * as fs from 'node:fs'
import * as path from 'node:path'
import { loadGatewayConfig } from '../src/config.js'

const args = process.argv.slice(2)

const EXPECTED_TABLES = [
  'devices',
  'activation_codes',
  'usage_events',
  'orders',
  'payment_notifications',
] as const

const VALID_PLANS = new Set(['free', 'light', 'pro', 'max', 'team'])
const VALID_PACKAGE_KINDS = new Set(['subscription', 'topup', 'trial'])
const VALID_ORDER_STATUSES = new Set(['pending_payment', 'paid', 'fulfilled', 'cancelled'])
const VALID_PAYMENT_PROVIDERS = new Set(['wechat', 'alipay'])
const VALID_NOTIFICATION_STATUSES = new Set(['processing', 'processed', 'failed'])

type IssueSeverity = 'error' | 'warning'

type MigrationIssue = {
  severity: IssueSeverity
  code: string
  message: string
  table?: string
  count?: number
  samples?: unknown[]
}

type CountRow = {
  count: number
}

type GroupCountRow = {
  value: string | null
  count: number
}

async function main(): Promise<void> {
  const config = loadGatewayConfig()
  const dbPath = path.resolve(readArg('--db', config.dbPath))
  const failOnIssues = hasFlag('--fail-on-issues')
  const failOnWarnings = hasFlag('--fail-on-warnings')

  assertReadableFile(dbPath)

  const report = buildMigrationReport(dbPath)
  console.log(JSON.stringify(report, null, 2))

  const hasErrors = report.issues.some((issue) => issue.severity === 'error')
  const hasWarnings = report.issues.some((issue) => issue.severity === 'warning')
  if ((failOnIssues && hasErrors) || (failOnWarnings && (hasErrors || hasWarnings))) {
    process.exitCode = 1
  }
}

function buildMigrationReport(dbPath: string): Record<string, unknown> & { issues: MigrationIssue[] } {
  const db = new Database(dbPath, { readonly: true })
  try {
    db.exec('PRAGMA foreign_keys = ON')
    const generatedAt = new Date().toISOString()
    const fileBytes = fs.statSync(dbPath).size
    const integrity = readIntegrity(db)
    const existingTables = getExistingTables(db)
    const missingTables = EXPECTED_TABLES.filter((table) => !existingTables.has(table))
    const issues: MigrationIssue[] = []

    if (integrity !== 'ok') {
      issues.push({
        severity: 'error',
        code: 'SQLITE_INTEGRITY_CHECK_FAILED',
        message: `SQLite integrity_check returned ${integrity}`,
      })
    }

    if (missingTables.length > 0) {
      issues.push({
        severity: 'error',
        code: 'MISSING_TABLES',
        message: `Missing expected gateway tables: ${missingTables.join(', ')}`,
        samples: missingTables,
      })
    }

    const foreignKeyViolations = tableExists(existingTables, 'usage_events')
      ? db.query('PRAGMA foreign_key_check').all() as Array<Record<string, unknown>>
      : []
    addCountIssue(issues, {
      severity: 'error',
      code: 'SQLITE_FOREIGN_KEY_VIOLATIONS',
      message: 'SQLite foreign_key_check found broken references.',
      count: foreignKeyViolations.length,
      samples: foreignKeyViolations.slice(0, 20),
    })

    addUniquenessIssues(db, existingTables, issues)
    addEnumIssues(db, existingTables, issues)
    addLedgerIssues(db, existingTables, issues)
    addPaymentIssues(db, existingTables, issues)
    addTimestampIssues(db, existingTables, issues)
    addJsonIssues(db, existingTables, issues)

    const tables = Object.fromEntries(
      EXPECTED_TABLES
        .filter((table) => tableExists(existingTables, table))
        .map((table) => [table, countWhere(db, table)]),
    )
    const errorCount = issues.filter((issue) => issue.severity === 'error').length
    const warningCount = issues.filter((issue) => issue.severity === 'warning').length

    return {
      ok: integrity === 'ok' && errorCount === 0,
      generatedAt,
      dbPath,
      fileBytes,
      sqlite: {
        integrity,
        foreignKeyViolations: foreignKeyViolations.length,
      },
      target: {
        engine: 'mysql',
        version: '8.4 LTS',
        schema: 'gateway/deploy/mysql/schema.sql',
      },
      tables,
      business: {
        devices: buildDeviceSummary(db, existingTables),
        activationCodes: buildActivationSummary(db, existingTables),
        usage: buildUsageSummary(db, existingTables),
        orders: buildOrderSummary(db, existingTables),
        paymentNotifications: buildPaymentNotificationSummary(db, existingTables),
      },
      issueSummary: {
        errors: errorCount,
        warnings: warningCount,
      },
      issues,
    }
  } finally {
    db.close()
  }
}

function buildDeviceSummary(db: Database, tables: Set<string>): Record<string, unknown> | null {
  if (!tableExists(tables, 'devices')) return null
  const now = Date.now()
  return {
    total: countWhere(db, 'devices'),
    active7d: countWhere(db, 'devices', 'last_seen_at >= ?', [new Date(now - 7 * 24 * 60 * 60 * 1000).toISOString()]),
    active30d: countWhere(db, 'devices', 'last_seen_at >= ?', [new Date(now - 30 * 24 * 60 * 60 * 1000).toISOString()]),
    byPlan: groupCounts(db, 'devices', 'plan'),
    creditsTotal: sumColumn(db, 'devices', 'credits_total'),
    creditsRemaining: sumColumn(db, 'devices', 'credits_remaining'),
  }
}

function buildActivationSummary(db: Database, tables: Set<string>): Record<string, unknown> | null {
  if (!tableExists(tables, 'activation_codes')) return null
  return {
    total: countWhere(db, 'activation_codes'),
    disabled: countWhere(db, 'activation_codes', 'disabled_at IS NOT NULL'),
    byPlan: groupCounts(db, 'activation_codes', 'plan'),
    byKind: groupCounts(db, 'activation_codes', 'activation_kind'),
    totalActivations: sumColumn(db, 'activation_codes', 'activations'),
  }
}

function buildUsageSummary(db: Database, tables: Set<string>): Record<string, unknown> | null {
  if (!tableExists(tables, 'usage_events')) return null
  return {
    total: countWhere(db, 'usage_events'),
    credits: sumColumn(db, 'usage_events', 'credits'),
    inputTokens: sumColumn(db, 'usage_events', 'input_tokens'),
    outputTokens: sumColumn(db, 'usage_events', 'output_tokens'),
    byKind: groupCounts(db, 'usage_events', 'kind'),
    byModel: groupCounts(db, 'usage_events', 'model', 20),
  }
}

function buildOrderSummary(db: Database, tables: Set<string>): Record<string, unknown> | null {
  if (!tableExists(tables, 'orders')) return null
  return {
    total: countWhere(db, 'orders'),
    byStatus: groupCounts(db, 'orders', 'status'),
    byProvider: groupCounts(db, 'orders', 'payment_provider'),
    amountCents: sumColumn(db, 'orders', 'amount_cents'),
    paidAmountCents: sumColumn(db, 'orders', 'paid_amount_cents'),
    paidOrFulfilledAmountCents: sumColumn(db, 'orders', 'amount_cents', "status IN ('paid', 'fulfilled')"),
    missingOrderToken: countWhere(db, 'orders', "order_token IS NULL OR TRIM(order_token) = ''"),
  }
}

function buildPaymentNotificationSummary(db: Database, tables: Set<string>): Record<string, unknown> | null {
  if (!tableExists(tables, 'payment_notifications')) return null
  return {
    total: countWhere(db, 'payment_notifications'),
    byProvider: groupCounts(db, 'payment_notifications', 'provider'),
    byStatus: groupCounts(db, 'payment_notifications', 'status'),
  }
}

function addUniquenessIssues(db: Database, tables: Set<string>, issues: MigrationIssue[]): void {
  if (tableExists(tables, 'devices')) {
    addDuplicateIssue(db, issues, 'devices', 'device_token')
  }
  if (tableExists(tables, 'orders')) {
    addDuplicateIssue(db, issues, 'orders', 'order_id')
    addDuplicateIssue(db, issues, 'orders', 'wechat_transaction_id', "wechat_transaction_id IS NOT NULL AND TRIM(wechat_transaction_id) <> ''")
    addDuplicateIssue(db, issues, 'orders', 'alipay_trade_no', "alipay_trade_no IS NOT NULL AND TRIM(alipay_trade_no) <> ''")
  }
  if (tableExists(tables, 'payment_notifications')) {
    const duplicates = db
      .query(
        `SELECT provider || ':' || notification_id AS value, COUNT(*) AS count
         FROM payment_notifications
         GROUP BY provider, notification_id
         HAVING COUNT(*) > 1
         ORDER BY count DESC
         LIMIT 20`,
      )
      .all() as GroupCountRow[]
    addCountIssue(issues, {
      severity: 'error',
      code: 'DUPLICATE_PAYMENT_NOTIFICATION_IDS',
      table: 'payment_notifications',
      message: 'payment_notifications must be unique by provider and notification_id before migration.',
      count: duplicates.length,
      samples: duplicates,
    })
  }
}

function addEnumIssues(db: Database, tables: Set<string>, issues: MigrationIssue[]): void {
  addInvalidValueIssue(db, tables, issues, 'devices', 'plan', VALID_PLANS)
  addInvalidValueIssue(db, tables, issues, 'activation_codes', 'plan', VALID_PLANS)
  addInvalidValueIssue(db, tables, issues, 'activation_codes', 'activation_kind', VALID_PACKAGE_KINDS)
  addInvalidValueIssue(db, tables, issues, 'orders', 'package_kind', VALID_PACKAGE_KINDS)
  addInvalidValueIssue(db, tables, issues, 'orders', 'plan', VALID_PLANS)
  addInvalidValueIssue(db, tables, issues, 'orders', 'status', VALID_ORDER_STATUSES)
  addInvalidValueIssue(db, tables, issues, 'orders', 'payment_provider', VALID_PAYMENT_PROVIDERS, true)
  addInvalidValueIssue(db, tables, issues, 'payment_notifications', 'provider', VALID_PAYMENT_PROVIDERS)
  addInvalidValueIssue(db, tables, issues, 'payment_notifications', 'status', VALID_NOTIFICATION_STATUSES)
}

function addLedgerIssues(db: Database, tables: Set<string>, issues: MigrationIssue[]): void {
  if (tableExists(tables, 'devices')) {
    addWhereIssue(db, issues, 'error', 'NEGATIVE_DEVICE_CREDITS', 'devices', 'Device credits cannot be negative.', 'credits_total < 0 OR credits_remaining < 0')
    addWhereIssue(db, issues, 'error', 'DEVICE_REMAINING_EXCEEDS_TOTAL', 'devices', 'Device credits_remaining cannot exceed credits_total.', 'credits_remaining > credits_total')
    addBlankIssue(db, issues, 'devices', 'device_id')
    addBlankIssue(db, issues, 'devices', 'device_token')
  }
  if (tableExists(tables, 'activation_codes')) {
    addWhereIssue(db, issues, 'error', 'INVALID_ACTIVATION_COUNTS', 'activation_codes', 'Activation counts cannot be negative or exceed max_activations.', 'credits_total < 0 OR max_activations < 0 OR activations < 0 OR activations > max_activations')
    addBlankIssue(db, issues, 'activation_codes', 'license_key')
  }
  if (tableExists(tables, 'usage_events')) {
    addWhereIssue(db, issues, 'error', 'INVALID_USAGE_CREDITS', 'usage_events', 'Usage event credits must be positive.', 'credits <= 0')
    addWhereIssue(db, issues, 'error', 'NEGATIVE_USAGE_TOKENS', 'usage_events', 'Usage token counts cannot be negative.', 'input_tokens < 0 OR output_tokens < 0')
    addWhereIssue(
      db,
      issues,
      'error',
      'USAGE_EVENTS_WITHOUT_DEVICE',
      'usage_events',
      'Every usage event must reference an existing device.',
      'NOT EXISTS (SELECT 1 FROM devices d WHERE d.device_id = usage_events.device_id)',
      tableExists(tables, 'devices'),
    )
  }
}

function addPaymentIssues(db: Database, tables: Set<string>, issues: MigrationIssue[]): void {
  if (tableExists(tables, 'orders')) {
    addWhereIssue(db, issues, 'error', 'NEGATIVE_ORDER_AMOUNTS', 'orders', 'Order amount and paid amount cannot be negative.', 'credits < 0 OR amount_cents < 0 OR paid_amount_cents < 0')
    addWhereIssue(db, issues, 'error', 'FULFILLED_ORDER_WITHOUT_LICENSE', 'orders', 'Fulfilled orders must have a license_key.', "status = 'fulfilled' AND (license_key IS NULL OR TRIM(license_key) = '')")
    addWhereIssue(db, issues, 'error', 'PAID_AMOUNT_MISMATCH', 'orders', 'Paid order amount must match the package amount.', 'paid_amount_cents IS NOT NULL AND paid_amount_cents <> amount_cents')
    addWhereIssue(db, issues, 'warning', 'PAID_ORDER_WITHOUT_PAID_AT', 'orders', 'Paid or fulfilled orders should have paid_at populated.', "status IN ('paid', 'fulfilled') AND paid_at IS NULL")
    addWhereIssue(db, issues, 'warning', 'PUBLIC_ORDER_WITHOUT_TOKEN', 'orders', 'Orders without order_token cannot use the public order-status flow.', "order_token IS NULL OR TRIM(order_token) = ''")
    addBlankIssue(db, issues, 'orders', 'order_id')
  }
  if (tableExists(tables, 'payment_notifications')) {
    addWhereIssue(db, issues, 'warning', 'PROCESSED_NOTIFICATION_WITHOUT_PROCESSED_AT', 'payment_notifications', 'Processed payment notifications should have processed_at populated.', "status = 'processed' AND processed_at IS NULL")
    addBlankIssue(db, issues, 'payment_notifications', 'notification_id')
  }
}

function addTimestampIssues(db: Database, tables: Set<string>, issues: MigrationIssue[]): void {
  const timestampColumns = [
    { table: 'devices', column: 'expires_at', nullable: true },
    { table: 'devices', column: 'created_at', nullable: false },
    { table: 'devices', column: 'updated_at', nullable: false },
    { table: 'devices', column: 'last_seen_at', nullable: false },
    { table: 'activation_codes', column: 'expires_at', nullable: true },
    { table: 'activation_codes', column: 'disabled_at', nullable: true },
    { table: 'activation_codes', column: 'created_at', nullable: false },
    { table: 'usage_events', column: 'created_at', nullable: false },
    { table: 'orders', column: 'payment_expires_at', nullable: true },
    { table: 'orders', column: 'wechat_success_time', nullable: true },
    { table: 'orders', column: 'alipay_success_time', nullable: true },
    { table: 'orders', column: 'created_at', nullable: false },
    { table: 'orders', column: 'updated_at', nullable: false },
    { table: 'orders', column: 'paid_at', nullable: true },
    { table: 'orders', column: 'fulfilled_at', nullable: true },
    { table: 'orders', column: 'cancelled_at', nullable: true },
    { table: 'payment_notifications', column: 'created_at', nullable: false },
    { table: 'payment_notifications', column: 'updated_at', nullable: false },
    { table: 'payment_notifications', column: 'processed_at', nullable: true },
  ]

  for (const item of timestampColumns) {
    if (!tableExists(tables, item.table)) continue
    const blankWhere = item.nullable
      ? `${item.column} IS NOT NULL AND TRIM(${item.column}) = ''`
      : `${item.column} IS NULL OR TRIM(${item.column}) = ''`
    addWhereIssue(
      db,
      issues,
      'error',
      `BLANK_TIMESTAMP_${item.table.toUpperCase()}_${item.column.toUpperCase()}`,
      item.table,
      `${item.table}.${item.column} cannot be blank before MySQL DATETIME import.`,
      blankWhere,
    )
    addWhereIssue(
      db,
      issues,
      'error',
      `INVALID_TIMESTAMP_${item.table.toUpperCase()}_${item.column.toUpperCase()}`,
      item.table,
      `${item.table}.${item.column} must be parseable as a timestamp before MySQL DATETIME import.`,
      `${item.column} IS NOT NULL AND TRIM(${item.column}) <> '' AND julianday(${item.column}) IS NULL`,
    )
  }
}

function addJsonIssues(db: Database, tables: Set<string>, issues: MigrationIssue[]): void {
  addInvalidJsonIssue(db, tables, issues, 'usage_events', 'metadata')
  addInvalidJsonIssue(db, tables, issues, 'orders', 'payment_payload')
  addInvalidJsonIssue(db, tables, issues, 'payment_notifications', 'payload')
}

function addDuplicateIssue(
  db: Database,
  issues: MigrationIssue[],
  table: string,
  column: string,
  where = `${column} IS NOT NULL AND TRIM(${column}) <> ''`,
): void {
  const duplicates = db
    .query(
      `SELECT ${column} AS value, COUNT(*) AS count
       FROM ${table}
       WHERE ${where}
       GROUP BY ${column}
       HAVING COUNT(*) > 1
       ORDER BY count DESC
       LIMIT 20`,
    )
    .all() as GroupCountRow[]
  addCountIssue(issues, {
    severity: 'error',
    code: `DUPLICATE_${table.toUpperCase()}_${column.toUpperCase()}`,
    table,
    message: `${table}.${column} must be unique before migration.`,
    count: duplicates.length,
    samples: duplicates,
  })
}

function addInvalidValueIssue(
  db: Database,
  tables: Set<string>,
  issues: MigrationIssue[],
  table: string,
  column: string,
  validValues: Set<string>,
  allowNull = false,
): void {
  if (!tableExists(tables, table)) return
  const rows = groupCounts(db, table, column, 200)
  const invalid = rows.filter((row) => {
    if (row.value === null && allowNull) return false
    return !row.value || !validValues.has(row.value)
  })
  addCountIssue(issues, {
    severity: 'error',
    code: `INVALID_${table.toUpperCase()}_${column.toUpperCase()}`,
    table,
    message: `${table}.${column} contains values outside the MySQL schema contract.`,
    count: invalid.length,
    samples: invalid.slice(0, 20),
  })
}

function addInvalidJsonIssue(
  db: Database,
  tables: Set<string>,
  issues: MigrationIssue[],
  table: string,
  column: string,
): void {
  if (!tableExists(tables, table)) return
  try {
    addWhereIssue(
      db,
      issues,
      'warning',
      `INVALID_JSON_${table.toUpperCase()}_${column.toUpperCase()}`,
      table,
      `${table}.${column} should contain valid JSON when present.`,
      `${column} IS NOT NULL AND TRIM(${column}) <> '' AND json_valid(${column}) = 0`,
    )
  } catch (error) {
    issues.push({
      severity: 'warning',
      code: `JSON_VALID_CHECK_SKIPPED_${table.toUpperCase()}_${column.toUpperCase()}`,
      table,
      message: `Skipped JSON validation for ${table}.${column}: ${error instanceof Error ? error.message : String(error)}`,
    })
  }
}

function addBlankIssue(db: Database, issues: MigrationIssue[], table: string, column: string): void {
  addWhereIssue(
    db,
    issues,
    'error',
    `BLANK_${table.toUpperCase()}_${column.toUpperCase()}`,
    table,
    `${table}.${column} cannot be blank before migration.`,
    `${column} IS NULL OR TRIM(CAST(${column} AS TEXT)) = ''`,
  )
}

function addWhereIssue(
  db: Database,
  issues: MigrationIssue[],
  severity: IssueSeverity,
  code: string,
  table: string,
  message: string,
  where: string,
  enabled = true,
): void {
  if (!enabled) return
  const count = countWhere(db, table, where)
  const samples = count > 0 ? sampleRows(db, table, where) : []
  addCountIssue(issues, { severity, code, table, message, count, samples })
}

function addCountIssue(issues: MigrationIssue[], issue: MigrationIssue & { count: number }): void {
  if (issue.count <= 0) return
  issues.push(issue)
}

function sampleRows(db: Database, table: string, where: string, limit = 10): Array<Record<string, unknown>> {
  return db
    .query(`SELECT * FROM ${table} WHERE ${where} LIMIT ${limit}`)
    .all() as Array<Record<string, unknown>>
}

function readIntegrity(db: Database): string {
  const row = db.query('PRAGMA integrity_check').get() as Record<string, string> | null
  return Object.values(row ?? {})[0] ?? 'missing integrity_check result'
}

function getExistingTables(db: Database): Set<string> {
  const rows = db
    .query("SELECT name FROM sqlite_master WHERE type = 'table'")
    .all() as Array<{ name: string }>
  return new Set(rows.map((row) => row.name))
}

function tableExists(tables: Set<string>, table: string): boolean {
  return tables.has(table)
}

function countWhere(db: Database, table: string, where?: string, params: unknown[] = []): number {
  const sql = where
    ? `SELECT COUNT(*) AS count FROM ${table} WHERE ${where}`
    : `SELECT COUNT(*) AS count FROM ${table}`
  const row = db.query(sql).get(...params) as CountRow | null
  return Number(row?.count ?? 0)
}

function sumColumn(db: Database, table: string, column: string, where?: string): number {
  const sql = where
    ? `SELECT COALESCE(SUM(${column}), 0) AS count FROM ${table} WHERE ${where}`
    : `SELECT COALESCE(SUM(${column}), 0) AS count FROM ${table}`
  const row = db.query(sql).get() as CountRow | null
  return Number(row?.count ?? 0)
}

function groupCounts(db: Database, table: string, column: string, limit = 50): GroupCountRow[] {
  return db
    .query(
      `SELECT ${column} AS value, COUNT(*) AS count
       FROM ${table}
       GROUP BY ${column}
       ORDER BY count DESC
       LIMIT ${limit}`,
    )
    .all() as GroupCountRow[]
}

function assertReadableFile(filePath: string): void {
  const stat = fs.statSync(filePath, { throwIfNoEntry: false })
  if (!stat?.isFile()) {
    throw new Error(`SQLite database not found: ${filePath}`)
  }
}

function readArg(name: string, fallback: string): string {
  const index = args.indexOf(name)
  if (index === -1) return fallback
  return args[index + 1] ?? fallback
}

function hasFlag(name: string): boolean {
  return args.includes(name)
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error))
  process.exit(1)
})
