-- Gugu Gateway MySQL 8.4 LTS initial schema draft.
-- Apply inside the gugu_gateway database:
--   mysql -h127.0.0.1 -ugugu_gateway_app -p gugu_gateway < gateway/deploy/mysql/schema.sql
--
-- SQLite is still the production source of truth until the storage migration is
-- implemented and validated. SQLite ISO timestamp strings should be normalized
-- to UTC DATETIME(3) values during import; the MySQL storage layer should expose
-- ISO strings back to the existing GatewayStorage contract.

SET NAMES utf8mb4 COLLATE utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS devices (
  device_id VARCHAR(128) NOT NULL,
  device_token VARCHAR(128) NOT NULL,
  plan VARCHAR(32) NOT NULL,
  credits_total BIGINT UNSIGNED NOT NULL,
  credits_remaining BIGINT UNSIGNED NOT NULL,
  expires_at DATETIME(3) NULL,
  license_key VARCHAR(128) NULL,
  app_version VARCHAR(64) NULL,
  platform VARCHAR(64) NULL,
  created_at DATETIME(3) NOT NULL,
  updated_at DATETIME(3) NOT NULL,
  last_seen_at DATETIME(3) NOT NULL,
  PRIMARY KEY (device_id),
  UNIQUE KEY uq_devices_device_token (device_token),
  KEY idx_devices_plan (plan),
  KEY idx_devices_last_seen_at (last_seen_at),
  KEY idx_devices_license_key (license_key),
  CONSTRAINT chk_devices_plan CHECK (plan IN ('free', 'light', 'pro', 'max', 'team')),
  CONSTRAINT chk_devices_credits CHECK (credits_remaining <= credits_total)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS activation_codes (
  license_key VARCHAR(128) NOT NULL,
  plan VARCHAR(32) NOT NULL,
  credits_total BIGINT UNSIGNED NOT NULL,
  expires_at DATETIME(3) NULL,
  max_activations INT UNSIGNED NOT NULL,
  activations INT UNSIGNED NOT NULL DEFAULT 0,
  disabled_at DATETIME(3) NULL,
  created_at DATETIME(3) NOT NULL,
  package_id VARCHAR(64) NULL,
  activation_kind VARCHAR(32) NOT NULL DEFAULT 'subscription',
  PRIMARY KEY (license_key),
  KEY idx_activation_codes_package_id (package_id),
  KEY idx_activation_codes_plan (plan),
  KEY idx_activation_codes_created_at (created_at),
  CONSTRAINT chk_activation_codes_plan CHECK (plan IN ('free', 'light', 'pro', 'max', 'team')),
  CONSTRAINT chk_activation_codes_kind CHECK (activation_kind IN ('subscription', 'topup', 'trial')),
  CONSTRAINT chk_activation_codes_activations CHECK (activations <= max_activations)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS usage_events (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  device_id VARCHAR(128) NOT NULL,
  kind VARCHAR(64) NOT NULL,
  model VARCHAR(128) NOT NULL,
  credits BIGINT UNSIGNED NOT NULL,
  input_tokens BIGINT UNSIGNED NULL,
  output_tokens BIGINT UNSIGNED NULL,
  created_at DATETIME(3) NOT NULL,
  metadata LONGTEXT NULL,
  PRIMARY KEY (id),
  KEY idx_usage_events_device_id (device_id),
  KEY idx_usage_events_created_at (created_at),
  KEY idx_usage_events_model (model),
  KEY idx_usage_events_kind (kind),
  CONSTRAINT fk_usage_events_device_id
    FOREIGN KEY (device_id) REFERENCES devices(device_id)
    ON UPDATE CASCADE
    ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS orders (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  order_id VARCHAR(128) NOT NULL,
  package_id VARCHAR(64) NOT NULL,
  package_name VARCHAR(255) NOT NULL,
  package_kind VARCHAR(32) NOT NULL,
  plan VARCHAR(32) NOT NULL,
  credits BIGINT UNSIGNED NOT NULL,
  amount_cents BIGINT UNSIGNED NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'CNY',
  status VARCHAR(32) NOT NULL,
  contact VARCHAR(255) NULL,
  license_key VARCHAR(128) NULL,
  order_token VARCHAR(128) NULL,
  payment_provider VARCHAR(32) NULL,
  payment_code_url TEXT NULL,
  payment_expires_at DATETIME(3) NULL,
  wechat_transaction_id VARCHAR(128) NULL,
  wechat_trade_state VARCHAR(64) NULL,
  wechat_success_time DATETIME(3) NULL,
  alipay_trade_no VARCHAR(128) NULL,
  alipay_trade_status VARCHAR(64) NULL,
  alipay_success_time DATETIME(3) NULL,
  paid_amount_cents BIGINT UNSIGNED NULL,
  payment_payload LONGTEXT NULL,
  created_at DATETIME(3) NOT NULL,
  updated_at DATETIME(3) NOT NULL,
  paid_at DATETIME(3) NULL,
  fulfilled_at DATETIME(3) NULL,
  cancelled_at DATETIME(3) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_orders_order_id (order_id),
  UNIQUE KEY uq_orders_wechat_transaction_id (wechat_transaction_id),
  UNIQUE KEY uq_orders_alipay_trade_no (alipay_trade_no),
  KEY idx_orders_order_token (order_token),
  KEY idx_orders_status (status),
  KEY idx_orders_created_at (created_at),
  KEY idx_orders_payment_provider (payment_provider),
  KEY idx_orders_license_key (license_key),
  CONSTRAINT chk_orders_package_kind CHECK (package_kind IN ('subscription', 'topup', 'trial')),
  CONSTRAINT chk_orders_plan CHECK (plan IN ('free', 'light', 'pro', 'max', 'team')),
  CONSTRAINT chk_orders_currency CHECK (currency = 'CNY'),
  CONSTRAINT chk_orders_status CHECK (status IN ('pending_payment', 'paid', 'fulfilled', 'cancelled')),
  CONSTRAINT chk_orders_payment_provider CHECK (payment_provider IS NULL OR payment_provider IN ('wechat', 'alipay'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS payment_notifications (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  provider VARCHAR(32) NOT NULL,
  notification_id VARCHAR(128) NOT NULL,
  transaction_id VARCHAR(128) NULL,
  order_id VARCHAR(128) NULL,
  status VARCHAR(32) NOT NULL,
  error_message TEXT NULL,
  payload LONGTEXT NULL,
  created_at DATETIME(3) NOT NULL,
  updated_at DATETIME(3) NOT NULL,
  processed_at DATETIME(3) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_payment_notifications_provider_notification (provider, notification_id),
  KEY idx_payment_notifications_transaction_id (transaction_id),
  KEY idx_payment_notifications_order_id (order_id),
  KEY idx_payment_notifications_status (status),
  CONSTRAINT chk_payment_notifications_provider CHECK (provider IN ('wechat', 'alipay')),
  CONSTRAINT chk_payment_notifications_status CHECK (status IN ('processing', 'processed', 'failed'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS gateway_schema_migrations (
  version VARCHAR(64) NOT NULL,
  description VARCHAR(255) NOT NULL,
  applied_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (version)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT IGNORE INTO gateway_schema_migrations (version, description)
VALUES ('001', 'initial gateway mysql schema');
