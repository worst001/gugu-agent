import { GatewayStore, type GatewayStorage } from './store.js'
import { MysqlGatewayStore } from './mysqlStore.js'
import type { GatewayConfig } from './types.js'

export class GatewayStorageConfigError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'GatewayStorageConfigError'
  }
}

export function createGatewayStorage(config: GatewayConfig): GatewayStorage {
  if (config.storeDriver === 'sqlite') {
    return new GatewayStore(config)
  }

  if (config.storeDriver === 'mysql') {
    return new MysqlGatewayStore(config)
  }

  throw new GatewayStorageConfigError(`Unsupported gateway storage driver: ${config.storeDriver}`)
}
