import * as os from 'node:os'
import * as path from 'node:path'
import type { GatewayConfig, GatewayStoreDriver } from './types.js'

function readIntEnv(name: string, fallback: number): number {
  const raw = process.env[name]?.trim()
  if (!raw) return fallback
  const value = Number.parseInt(raw, 10)
  return Number.isFinite(value) && value >= 0 ? value : fallback
}

function readPositiveIntEnv(name: string, fallback: number): number {
  const raw = process.env[name]?.trim()
  if (!raw) return fallback
  const value = Number.parseInt(raw, 10)
  return Number.isFinite(value) && value > 0 ? value : fallback
}

function readOptionalUrl(name: string): string | null {
  const raw = process.env[name]?.trim()
  if (!raw) return null
  try {
    const url = new URL(raw)
    if (url.protocol !== 'http:' && url.protocol !== 'https:') return null
    return url.toString().replace(/\/+$/, '')
  } catch {
    return null
  }
}

function readOptionalPositiveIntEnv(name: string): number | null {
  const raw = process.env[name]?.trim()
  if (!raw) return null
  const value = Number.parseInt(raw, 10)
  return Number.isFinite(value) && value > 0 ? value : null
}

function readBoolEnv(name: string): boolean {
  const raw = process.env[name]?.trim().toLowerCase()
  return raw === '1' || raw === 'true' || raw === 'yes' || raw === 'on'
}

function readBoolEnvWithFallback(name: string, fallback: boolean): boolean {
  const raw = process.env[name]?.trim().toLowerCase()
  if (!raw) return fallback
  if (raw === '1' || raw === 'true' || raw === 'yes' || raw === 'on') return true
  if (raw === '0' || raw === 'false' || raw === 'no' || raw === 'off') return false
  return fallback
}

function readStringEnv(name: string): string {
  return process.env[name]?.trim() || ''
}

function readStringEnvWithFallback(name: string, fallback: string): string {
  return process.env[name]?.trim() || fallback
}

function readStoreDriver(): GatewayStoreDriver {
  const raw = process.env.GUGU_STORE_DRIVER?.trim().toLowerCase()
  return raw === 'mysql' ? 'mysql' : 'sqlite'
}

export function loadGatewayConfig(): GatewayConfig {
  const legacyDownloadUrl = readOptionalUrl('GUGU_DOWNLOAD_URL')
  const legacyDownloadSha256 = process.env.GUGU_DOWNLOAD_SHA256?.trim() || null
  const publicBaseUrl = readOptionalUrl('GUGU_PUBLIC_BASE_URL')

  return {
    storeDriver: readStoreDriver(),
    dbPath:
      process.env.GUGU_GATEWAY_DB_PATH?.trim() ||
      path.join(os.homedir(), '.gugu-agent', 'gateway.sqlite'),
    mysqlUrl: process.env.GUGU_MYSQL_URL?.trim() || '',
    freeCredits: readIntEnv('GUGU_FREE_CREDITS', 50),
    purchaseUrl: readOptionalUrl('GUGU_PURCHASE_URL'),
    publicBaseUrl,
    icpRecord: process.env.GUGU_ICP_RECORD?.trim() || null,
    icpUrl: readOptionalUrl('GUGU_ICP_URL') || 'https://beian.miit.gov.cn/',
    downloadUrl: legacyDownloadUrl,
    downloadReleaseJsonUrl: readOptionalUrl('GUGU_DOWNLOAD_RELEASE_JSON_URL'),
    downloadWindowsUrl: readOptionalUrl('GUGU_DOWNLOAD_WINDOWS_URL') || legacyDownloadUrl,
    downloadMacosUrl: readOptionalUrl('GUGU_DOWNLOAD_MACOS_URL'),
    downloadVersion: process.env.GUGU_DOWNLOAD_VERSION?.trim() || null,
    downloadSha256: legacyDownloadSha256,
    downloadWindowsSha256: process.env.GUGU_DOWNLOAD_WINDOWS_SHA256?.trim() || legacyDownloadSha256,
    downloadMacosSha256: process.env.GUGU_DOWNLOAD_MACOS_SHA256?.trim() || null,
    adminToken: process.env.GUGU_ADMIN_TOKEN?.trim() || '',
    requestLogEnabled: readBoolEnvWithFallback('GUGU_REQUEST_LOG_ENABLED', true),
    dashboardTokenPerCredit: readOptionalPositiveIntEnv('GUGU_DASHBOARD_TOKEN_PER_CREDIT'),
    maintenanceMode: readBoolEnv('GUGU_MAINTENANCE_MODE'),
    maintenanceDisableOrders: readBoolEnv('GUGU_MAINTENANCE_DISABLE_ORDERS'),
    maintenanceMessage: readStringEnvWithFallback(
      'GUGU_MAINTENANCE_MESSAGE',
      '系统维护中，购买和支付暂不可用，已支付订单会自动补发。',
    ),
    deepseekApiKey: process.env.GUGU_DEEPSEEK_API_KEY?.trim() || '',
    deepseekBaseUrl:
      readOptionalUrl('GUGU_DEEPSEEK_BASE_URL') ||
      'https://api.deepseek.com/anthropic',
    deepseekMainModel:
      process.env.GUGU_DEEPSEEK_MODEL?.trim() || 'deepseek-v4-pro',
    deepseekFastModel:
      process.env.GUGU_DEEPSEEK_FAST_MODEL?.trim() || 'deepseek-v4-flash',
    deepseekTimeoutMs: readPositiveIntEnv('GUGU_DEEPSEEK_TIMEOUT_MS', 90_000),
    deepseekStreamIdleTimeoutMs: readPositiveIntEnv('GUGU_DEEPSEEK_STREAM_IDLE_TIMEOUT_MS', 120_000),
    deepseekCircuitFailureThreshold: readPositiveIntEnv('GUGU_DEEPSEEK_CIRCUIT_FAILURE_THRESHOLD', 5),
    deepseekCircuitOpenMs: readPositiveIntEnv('GUGU_DEEPSEEK_CIRCUIT_OPEN_MS', 30_000),
    messageMaxRequestBytes: readPositiveIntEnv(
      'GUGU_MESSAGE_MAX_REQUEST_BYTES',
      8 * 1024 * 1024,
    ),
    messageMaxConcurrency: readPositiveIntEnv('GUGU_MESSAGE_MAX_CONCURRENCY', 80),
    messageQueueLimit: readIntEnv('GUGU_MESSAGE_QUEUE_LIMIT', 40),
    messageQueueTimeoutMs: readPositiveIntEnv('GUGU_MESSAGE_QUEUE_TIMEOUT_MS', 3_000),
    glmJsonMaxRequestBytes: readPositiveIntEnv(
      'GUGU_GLM_JSON_MAX_REQUEST_BYTES',
      20 * 1024 * 1024,
    ),
    glmFileParseMaxBytes: readPositiveIntEnv(
      'GUGU_FILE_PARSE_MAX_BYTES',
      20 * 1024 * 1024,
    ),
    glmImageMaxBytes: readPositiveIntEnv(
      'GUGU_GLM_IMAGE_MAX_BYTES',
      8 * 1024 * 1024,
    ),
    glmRequestTimeoutMs: readPositiveIntEnv('GUGU_GLM_REQUEST_TIMEOUT_MS', 120_000),
    glmCircuitFailureThreshold: readPositiveIntEnv('GUGU_GLM_CIRCUIT_FAILURE_THRESHOLD', 5),
    glmCircuitOpenMs: readPositiveIntEnv('GUGU_GLM_CIRCUIT_OPEN_MS', 30_000),
    glmMaxConcurrency: readPositiveIntEnv('GUGU_GLM_MAX_CONCURRENCY', 8),
    glmQueueLimit: readIntEnv('GUGU_GLM_QUEUE_LIMIT', 16),
    glmQueueTimeoutMs: readPositiveIntEnv('GUGU_GLM_QUEUE_TIMEOUT_MS', 3_000),
    deviceRegisterRateLimitPerMinute: readIntEnv('GUGU_DEVICE_REGISTER_RATE_LIMIT_PER_MINUTE', 20),
    orderCreateRateLimitPerMinute: readIntEnv('GUGU_ORDER_CREATE_RATE_LIMIT_PER_MINUTE', 10),
    freeMessageRateLimitPerMinute: readIntEnv('GUGU_FREE_MESSAGE_RATE_LIMIT_PER_MINUTE', 6),
    lightMessageRateLimitPerMinute: readIntEnv('GUGU_LIGHT_MESSAGE_RATE_LIMIT_PER_MINUTE', 20),
    proMessageRateLimitPerMinute: readIntEnv('GUGU_PRO_MESSAGE_RATE_LIMIT_PER_MINUTE', 40),
    maxMessageRateLimitPerMinute: readIntEnv('GUGU_MAX_MESSAGE_RATE_LIMIT_PER_MINUTE', 60),
    freeAttachmentRateLimitPerMinute: readIntEnv('GUGU_FREE_ATTACHMENT_RATE_LIMIT_PER_MINUTE', 2),
    lightAttachmentRateLimitPerMinute: readIntEnv('GUGU_LIGHT_ATTACHMENT_RATE_LIMIT_PER_MINUTE', 4),
    proAttachmentRateLimitPerMinute: readIntEnv('GUGU_PRO_ATTACHMENT_RATE_LIMIT_PER_MINUTE', 8),
    maxAttachmentRateLimitPerMinute: readIntEnv('GUGU_MAX_ATTACHMENT_RATE_LIMIT_PER_MINUTE', 12),
    messageCreditCost: readPositiveIntEnv('GUGU_MESSAGE_CREDIT_COST', 1),
    attachmentCreditCost: readPositiveIntEnv('GUGU_ATTACHMENT_CREDIT_COST', 6),
    fileParseCreditCost: readPositiveIntEnv('GUGU_FILE_PARSE_CREDIT_COST', 3),
    summarizeCreditCost: readPositiveIntEnv('GUGU_SUMMARIZE_CREDIT_COST', 4),
    glmApiKey: process.env.GUGU_GLM_API_KEY?.trim() || '',
    glmBaseUrl:
      readOptionalUrl('GUGU_GLM_BASE_URL') ||
      'https://open.bigmodel.cn/api/paas/v4',
    wechatPay: {
      enabled: readBoolEnv('GUGU_WECHAT_PAY_ENABLED'),
      appId: readStringEnv('GUGU_WECHAT_APP_ID'),
      mchId: readStringEnv('GUGU_WECHAT_MCH_ID'),
      merchantCertSerialNo: readStringEnv('GUGU_WECHAT_MCH_CERT_SERIAL_NO'),
      privateKeyPath: readStringEnv('GUGU_WECHAT_PRIVATE_KEY_PATH'),
      wechatPayPublicKeyId: readStringEnv('GUGU_WECHATPAY_PUBLIC_KEY_ID'),
      wechatPayPublicKeyPath: readStringEnv('GUGU_WECHATPAY_PUBLIC_KEY_PATH'),
      apiV3Key: readStringEnv('GUGU_WECHAT_API_V3_KEY'),
      notifyUrl:
        readOptionalUrl('GUGU_WECHAT_NOTIFY_URL') ||
        (publicBaseUrl ? `${publicBaseUrl}/v1/payments/wechat/notify` : null),
    },
    alipay: {
      enabled: readBoolEnv('GUGU_ALIPAY_PAY_ENABLED'),
      appId: readStringEnv('GUGU_ALIPAY_APP_ID'),
      privateKeyPath: readStringEnv('GUGU_ALIPAY_PRIVATE_KEY_PATH'),
      alipayPublicKeyPath: readStringEnv('GUGU_ALIPAY_PUBLIC_KEY_PATH'),
      notifyUrl:
        readOptionalUrl('GUGU_ALIPAY_NOTIFY_URL') ||
        (publicBaseUrl ? `${publicBaseUrl}/v1/payments/alipay/notify` : null),
      gatewayUrl:
        readOptionalUrl('GUGU_ALIPAY_GATEWAY_URL') ||
        'https://openapi.alipay.com/gateway.do',
      sellerId: readStringEnv('GUGU_ALIPAY_SELLER_ID'),
    },
  }
}
