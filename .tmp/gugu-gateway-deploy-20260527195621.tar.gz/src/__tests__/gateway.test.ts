import { afterEach, beforeEach, describe, expect, test } from 'bun:test'
import { createCipheriv, generateKeyPairSync, randomBytes, sign } from 'node:crypto'
import type { KeyObject } from 'node:crypto'
import * as fs from 'node:fs/promises'
import * as os from 'node:os'
import * as path from 'node:path'
import { createGatewayHandler } from '../index.js'
import { GatewayStore } from '../store.js'
import type { GatewayConfig } from '../types.js'

describe('Gugu Gateway', () => {
  let tmpDir: string
  let originalFetch: typeof fetch
  let stores: GatewayStore[]

  beforeEach(async () => {
    tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'gugu-gateway-'))
    originalFetch = globalThis.fetch
    stores = []
  })

  afterEach(async () => {
    globalThis.fetch = originalFetch
    for (const store of stores) store.close()
    await fs.rm(tmpDir, { recursive: true, force: true })
  })

  test('registers devices and returns trial entitlement', async () => {
    const { handler } = makeGateway({ freeCredits: 3 })

    const response = await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }))
    const body = await response.json() as {
      deviceId: string
      deviceToken: string
      entitlement: { creditsTotal: number; creditsRemaining: number; expiresAt: string | null; isTrial: boolean; purchaseUrl: string | null }
    }

    expect(response.status).toBe(200)
    expect(body.deviceId).toBe('device-1')
    expect(body.deviceToken.startsWith('gugu_')).toBe(true)
    expect(body.entitlement.creditsTotal).toBe(3)
    expect(body.entitlement.creditsRemaining).toBe(3)
    expect(body.entitlement.expiresAt).toBeTruthy()
    expect(body.entitlement.isTrial).toBe(true)
    expect(body.entitlement.purchaseUrl).toBe('https://buy.example.com')
  })

  test('rate limits device registration by IP before creating trial devices', async () => {
    const { handler, store } = makeGateway({ deviceRegisterRateLimitPerMinute: 1 })

    const first = await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }, undefined, {
      'X-Forwarded-For': '203.0.113.10',
    }))
    const second = await handler(jsonRequest('/v1/devices', { deviceId: 'device-2' }, undefined, {
      'X-Forwarded-For': '203.0.113.10',
    }))
    const secondBody = await second.json() as { error: { code: string; message: string } }
    const otherIp = await handler(jsonRequest('/v1/devices', { deviceId: 'device-3' }, undefined, {
      'X-Forwarded-For': '203.0.113.11',
    }))

    expect(first.status).toBe(200)
    expect(second.status).toBe(429)
    expect(second.headers.get('retry-after')).toBe('60')
    expect(second.headers.get('x-gugu-ratelimit-limit')).toBe('1')
    expect(secondBody.error.code).toBe('RATE_LIMITED')
    expect(otherIp.status).toBe(200)
    expect(store.listDevices({ limit: 10 }).data.map((device) => device.deviceId).sort()).toEqual([
      'device-1',
      'device-3',
    ])
  })

  test('serves the package purchase page', async () => {
    const { handler } = makeGateway({ icpRecord: '沪ICP备2026021385号-1' })

    const response = await handler(getRequest('/buy'))
    const html = await response.text()

    expect(response.status).toBe(200)
    expect(response.headers.get('content-type')).toBe('text/html; charset=utf-8')
    expect(html).toContain('Gugu Agent')
    expect(html).toContain('当前购买流程')
    expect(html).toContain('购买页只负责帮你选对档位')
    expect(html).toContain('结算页单独处理')
    expect(html).toContain('light-monthly')
    expect(html).toContain('pro-monthly')
    expect(html).toContain('max-monthly')
    expect(html).toContain('/checkout?packageId=light-monthly')
    expect(html).toContain('订阅')
    expect(html).not.toContain('topup-large')
    expect(html).not.toContain('补充包')
    expect(html).not.toContain('/v1/orders')
    expect(html).not.toContain('联系方式或备注')
    expect(html).not.toContain('微信支付二维码')
    expect(html).not.toContain('data-copy-license')
    expect(html).not.toContain('orderResult')
    expect(html).toContain('沪ICP备2026021385号-1')
    expect(html).toContain('https://beian.miit.gov.cn/')
  })

  test('serves a checkout page for a selected package', async () => {
    const { handler } = makeGateway({ icpRecord: '沪ICP备2026021385号-1' })

    const response = await handler(getRequest('/checkout?packageId=light-monthly'))
    const html = await response.text()

    expect(response.status).toBe(200)
    expect(html).toContain('轻量版')
    expect(html).toContain('¥19')
    expect(html).toContain('联系方式或备注')
    expect(html).toContain('微信支付')
    expect(html).toContain('支付宝')
    expect(html).toContain('支付宝即将上线')
    expect(html).toContain('/v1/orders')
    expect(html).toContain('paymentProvider: provider')
    expect(html).toContain('data-provider="alipay"')
    expect(html).toContain('沪ICP备2026021385号-1')
  })

  test('serves a checkout error for invalid packages without creating orders', async () => {
    const { handler } = makeGateway()

    const response = await handler(getRequest('/checkout?packageId=topup-large'))
    const html = await response.text()

    expect(response.status).toBe(200)
    expect(html).toContain('套餐不可用')
    expect(html).toContain('/buy')
    expect(html).not.toContain('/v1/orders')
  })

  test('serves the public home and download pages', async () => {
    const { handler } = makeGateway({
      downloadUrl: 'https://downloads.example.com/Gugu-Agent.exe',
      downloadWindowsUrl: 'https://downloads.example.com/Gugu-Agent.msi',
      downloadMacosUrl: 'https://downloads.example.com/Gugu-Agent.dmg',
      downloadVersion: '0.1.0',
      downloadSha256: 'abc123',
      downloadWindowsSha256: 'windows-sha',
      downloadMacosSha256: 'macos-sha',
      icpRecord: '沪ICP备2026021385号-1',
    })

    const home = await handler(getRequest('/'))
    const download = await handler(getRequest('/download'))
    const homeHtml = await home.text()
    const downloadHtml = await download.text()

    expect(home.status).toBe(200)
    expect(homeHtml).toContain('Gugu Agent')
    expect(homeHtml).toContain('/buy')
    expect(homeHtml).toContain('/download')
    expect(homeHtml).toContain('沪ICP备2026021385号-1')
    expect(download.status).toBe(200)
    expect(downloadHtml).toContain('https://downloads.example.com/Gugu-Agent.msi')
    expect(downloadHtml).toContain('https://downloads.example.com/Gugu-Agent.dmg')
    expect(downloadHtml).toContain('官方 HTTPS 下载源')
    expect(downloadHtml).toContain('下载 Windows MSI')
    expect(downloadHtml).toContain('下载 macOS DMG')
    expect(downloadHtml).toContain('安装安全说明')
    expect(downloadHtml).toContain('危险下载内容')
    expect(downloadHtml).toContain('Windows SHA256')
    expect(downloadHtml).toContain('windows-sha')
    expect(downloadHtml).toContain('macOS SHA256')
    expect(downloadHtml).toContain('macos-sha')
    expect(downloadHtml).toContain('0.1.0')
    expect(downloadHtml).toContain('沪ICP备2026021385号-1')
    expect(downloadHtml).not.toContain('待配置')
    expect(downloadHtml).not.toContain('安装包准备中')
  })

  test('serves download metadata from release.json when configured', async () => {
    let requestedUrl = ''
    globalThis.fetch = (async (input) => {
      requestedUrl = String(input)
      return jsonResponse({
        version: '0.1.15',
        windows: {
          url: 'https://oss.example.com/Gugu-Agent-latest-windows-x64.msi',
          sha256: 'a'.repeat(64),
        },
        macos: {
          url: 'https://oss.example.com/Gugu-Agent-latest-aarch64.dmg',
          sha256: 'b'.repeat(64),
        },
      })
    }) as typeof fetch

    const { handler } = makeGateway({
      adminToken: 'admin-token',
      downloadReleaseJsonUrl: 'https://oss.example.com/release.json',
      downloadVersion: '0.1.14',
      downloadWindowsUrl: 'https://fallback.example.com/Gugu-Agent.msi',
    })

    const download = await handler(getRequest('/download'))
    const downloadHtml = await download.text()
    const admin = await handler(getRequest('/admin/api/download', 'admin-token'))
    const adminBody = await admin.json() as {
      downloadVersion: string
      downloadWindowsUrl: string
      downloadMacosUrl: string
      downloadWindowsSha256: string
      downloadMacosSha256: string
    }

    expect(requestedUrl).toBe('https://oss.example.com/release.json')
    expect(downloadHtml).toContain('0.1.15')
    expect(downloadHtml).toContain('https://oss.example.com/Gugu-Agent-latest-windows-x64.msi')
    expect(downloadHtml).toContain('https://oss.example.com/Gugu-Agent-latest-aarch64.dmg')
    expect(adminBody.downloadVersion).toBe('0.1.15')
    expect(adminBody.downloadWindowsUrl).toBe('https://oss.example.com/Gugu-Agent-latest-windows-x64.msi')
    expect(adminBody.downloadMacosUrl).toBe('https://oss.example.com/Gugu-Agent-latest-aarch64.dmg')
    expect(adminBody.downloadWindowsSha256).toBe('a'.repeat(64))
    expect(adminBody.downloadMacosSha256).toBe('b'.repeat(64))
  })

  test('deducts free credits and returns 402 when exhausted', async () => {
    let upstreamCalls = 0
    globalThis.fetch = (async () => {
      upstreamCalls += 1
      return jsonResponse({ id: 'msg_1', type: 'message', content: [] })
    }) as typeof fetch

    const { handler } = makeGateway({ freeCredits: 1, deepseekApiKey: 'deepseek-key' })
    const registered = await (await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }))).json() as {
      deviceToken: string
    }

    const first = await handler(jsonRequest('/v1/messages', {
      model: 'gugu-managed-main',
      max_tokens: 16,
      messages: [{ role: 'user', content: 'hi' }],
    }, registered.deviceToken))
    const second = await handler(jsonRequest('/v1/messages', {
      model: 'gugu-managed-main',
      max_tokens: 16,
      messages: [{ role: 'user', content: 'again' }],
    }, registered.deviceToken))
    const secondBody = await second.json() as { error: { code: string } }

    expect(first.status).toBe(200)
    expect(second.status).toBe(402)
    expect(secondBody.error.code).toBe('GUGU_QUOTA_EXHAUSTED')
    expect(upstreamCalls).toBe(1)
  })

  test('rejects oversized message payloads before consuming credits', async () => {
    let upstreamCalls = 0
    globalThis.fetch = (async () => {
      upstreamCalls += 1
      return jsonResponse({ id: 'msg_1', type: 'message', content: [] })
    }) as typeof fetch

    const { handler, store } = makeGateway({
      freeCredits: 2,
      deepseekApiKey: 'deepseek-key',
      messageMaxRequestBytes: 300,
    })
    const registered = await (await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }))).json() as {
      deviceToken: string
    }

    const response = await handler(jsonRequest('/v1/messages', {
      model: 'gugu-managed-main',
      max_tokens: 16,
      messages: [{ role: 'user', content: 'x'.repeat(1000) }],
    }, registered.deviceToken))
    const body = await response.json() as {
      error: { code: string; entitlement: { creditsRemaining: number } }
    }
    const summary = store.getDeviceSummary({ deviceToken: registered.deviceToken })
    const events = store.listUsageEvents({ deviceToken: registered.deviceToken, limit: 10 })

    expect(response.status).toBe(413)
    expect(body.error.code).toBe('PAYLOAD_TOO_LARGE')
    expect(body.error.entitlement.creditsRemaining).toBe(2)
    expect(summary?.entitlement.creditsRemaining).toBe(2)
    expect(events).toHaveLength(0)
    expect(upstreamCalls).toBe(0)
  })

  test('forces free plan message requests onto the fast DeepSeek model', async () => {
    let forwardedModel = ''
    globalThis.fetch = (async (_input, init) => {
      forwardedModel = JSON.parse(String(init?.body ?? '{}')).model
      return jsonResponse({ id: 'msg_1', type: 'message', content: [] })
    }) as typeof fetch

    const { handler, store } = makeGateway({ freeCredits: 2, deepseekApiKey: 'deepseek-key' })
    const registered = await (await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }))).json() as {
      deviceToken: string
    }

    const response = await handler(jsonRequest('/v1/messages', {
      model: 'gugu-managed-main',
      max_tokens: 16,
      messages: [{ role: 'user', content: 'hi' }],
    }, registered.deviceToken))
    const events = store.listUsageEvents({ deviceToken: registered.deviceToken, limit: 10 })

    expect(response.status).toBe(200)
    expect(forwardedModel).toBe('deepseek-v4-flash')
    expect(events[0].model).toBe('deepseek-v4-flash')
  })

  test('activates a license code and upgrades entitlement', async () => {
    const { handler, store } = makeGateway({ freeCredits: 1 })
    const registered = await (await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }))).json() as {
      deviceToken: string
    }
    const licenseKey = store.issueActivationCode({
      plan: 'pro',
      creditsTotal: 100,
      maxActivations: 1,
    })

    const response = await handler(jsonRequest('/v1/activate', { licenseKey }, registered.deviceToken))
    const body = await response.json() as {
      entitlement: { plan: string; creditsTotal: number; creditsRemaining: number; isTrial: boolean }
    }

    expect(response.status).toBe(200)
    expect(body.entitlement.plan).toBe('pro')
    expect(body.entitlement.creditsTotal).toBe(100)
    expect(body.entitlement.creditsRemaining).toBe(100)
    expect(body.entitlement.isTrial).toBe(false)
  })

  test('keeps paid plan message requests on the requested managed DeepSeek model', async () => {
    let forwardedModel = ''
    globalThis.fetch = (async (_input, init) => {
      forwardedModel = JSON.parse(String(init?.body ?? '{}')).model
      return jsonResponse({ id: 'msg_1', type: 'message', content: [] })
    }) as typeof fetch

    const { handler, store } = makeGateway({ freeCredits: 1, deepseekApiKey: 'deepseek-key' })
    const registered = await (await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }))).json() as {
      deviceToken: string
    }
    const licenseKey = store.issueActivationCode({
      plan: 'pro',
      creditsTotal: 100,
      maxActivations: 1,
    })
    await handler(jsonRequest('/v1/activate', { licenseKey }, registered.deviceToken))

    const response = await handler(jsonRequest('/v1/messages', {
      model: 'gugu-managed-main',
      max_tokens: 16,
      messages: [{ role: 'user', content: 'hi' }],
    }, registered.deviceToken))
    const events = store.listUsageEvents({ deviceToken: registered.deviceToken, limit: 10 })

    expect(response.status).toBe(200)
    expect(forwardedModel).toBe('deepseek-v4-pro')
    expect(events[0].model).toBe('deepseek-v4-pro')
  })

  test('applies stricter free message rate limits than paid plans before consuming credits', async () => {
    let fetchCalls = 0
    globalThis.fetch = (async () => {
      fetchCalls += 1
      return jsonResponse({
        id: `msg_${fetchCalls}`,
        type: 'message',
        content: [],
        usage: { input_tokens: 1, output_tokens: 1 },
      })
    }) as typeof fetch

    const { handler, store } = makeGateway({
      freeCredits: 20,
      deepseekApiKey: 'deepseek-key',
      freeMessageRateLimitPerMinute: 1,
      proMessageRateLimitPerMinute: 2,
    })
    const freeDevice = await (await handler(jsonRequest('/v1/devices', { deviceId: 'free-device' }))).json() as {
      deviceToken: string
    }
    const paidDevice = await (await handler(jsonRequest('/v1/devices', { deviceId: 'paid-device' }, undefined, {
      'X-Forwarded-For': '203.0.113.50',
    }))).json() as { deviceToken: string }
    const licenseKey = store.issueActivationCode({
      plan: 'pro',
      creditsTotal: 20,
      maxActivations: 1,
    })
    store.activate(paidDevice.deviceToken, licenseKey)

    const freeFirst = await handler(jsonRequest('/v1/messages', {
      model: 'gugu-managed-main',
      max_tokens: 16,
      messages: [{ role: 'user', content: 'hi' }],
    }, freeDevice.deviceToken))
    await freeFirst.json()
    const freeSecond = await handler(jsonRequest('/v1/messages', {
      model: 'gugu-managed-main',
      max_tokens: 16,
      messages: [{ role: 'user', content: 'again' }],
    }, freeDevice.deviceToken))
    const freeSecondBody = await freeSecond.json() as { error: { code: string; entitlement: { creditsRemaining: number } } }

    const paidFirst = await handler(jsonRequest('/v1/messages', {
      model: 'gugu-managed-main',
      max_tokens: 16,
      messages: [{ role: 'user', content: 'hi' }],
    }, paidDevice.deviceToken))
    await paidFirst.json()
    const paidSecond = await handler(jsonRequest('/v1/messages', {
      model: 'gugu-managed-main',
      max_tokens: 16,
      messages: [{ role: 'user', content: 'again' }],
    }, paidDevice.deviceToken))
    await paidSecond.json()
    const paidThird = await handler(jsonRequest('/v1/messages', {
      model: 'gugu-managed-main',
      max_tokens: 16,
      messages: [{ role: 'user', content: 'third' }],
    }, paidDevice.deviceToken))
    const paidThirdBody = await paidThird.json() as { error: { code: string; entitlement: { creditsRemaining: number } } }

    expect(freeSecond.status).toBe(429)
    expect(freeSecond.headers.get('x-gugu-ratelimit-limit')).toBe('1')
    expect(freeSecondBody.error.code).toBe('RATE_LIMITED')
    expect(freeSecondBody.error.entitlement.creditsRemaining).toBe(19)
    expect(paidThird.status).toBe(429)
    expect(paidThird.headers.get('x-gugu-ratelimit-limit')).toBe('2')
    expect(paidThirdBody.error.code).toBe('RATE_LIMITED')
    expect(paidThirdBody.error.entitlement.creditsRemaining).toBe(18)
    expect(fetchCalls).toBe(3)
  })

  test('tracks usage and exposes admin device summaries', async () => {
    globalThis.fetch = (async () => jsonResponse({ id: 'msg_1', type: 'message', content: [] })) as typeof fetch

    const { handler, store } = makeGateway({ freeCredits: 2, deepseekApiKey: 'deepseek-key' })
    const registered = await (await handler(jsonRequest('/v1/devices', {
      deviceId: 'device-1',
      appVersion: '0.1.10',
      platform: 'win32-x64',
    }))).json() as {
      deviceToken: string
    }

    const firstMessage = await handler(jsonRequest('/v1/messages', {
      model: 'gugu-managed-main',
      max_tokens: 16,
      messages: [{ role: 'user', content: 'hi' }],
    }, registered.deviceToken))
    await firstMessage.text()
    await new Promise((resolve) => setTimeout(resolve, 0))

    const summary = store.getDeviceSummary({ deviceToken: registered.deviceToken })
    const events = store.listUsageEvents({ deviceToken: registered.deviceToken, limit: 10 })
    const adjusted = store.setDeviceCreditsByDeviceId('device-1', 5, 10)

    expect(summary?.deviceId).toBe('device-1')
    expect(summary?.appVersion).toBe('0.1.10')
    expect(summary?.platform).toBe('win32-x64')
    expect(summary?.entitlement.creditsRemaining).toBe(1)
    expect(events).toHaveLength(1)
    expect(events[0].kind).toBe('message')
    expect(events[0].model).toBe('deepseek-v4-flash')
    expect(adjusted.creditsRemaining).toBe(5)
    expect(adjusted.creditsTotal).toBe(10)
  })

  test('records DeepSeek JSON token usage without changing message forwarding', async () => {
    globalThis.fetch = (async () => jsonResponse({
      id: 'msg_1',
      type: 'message',
      content: [],
      usage: { input_tokens: 11, output_tokens: 7 },
    })) as typeof fetch

    const { handler, store } = makeGateway({ freeCredits: 2, deepseekApiKey: 'deepseek-key' })
    const registered = await (await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }))).json() as {
      deviceToken: string
    }

    const response = await handler(jsonRequest('/v1/messages', {
      model: 'gugu-managed-main',
      max_tokens: 16,
      messages: [{ role: 'user', content: 'hi' }],
    }, registered.deviceToken))
    const body = await response.json() as { id: string }
    const events = store.listUsageEvents({ deviceToken: registered.deviceToken, limit: 10 })

    expect(response.status).toBe(200)
    expect(body.id).toBe('msg_1')
    expect(events[0].inputTokens).toBe(11)
    expect(events[0].outputTokens).toBe(7)
  })

  test('returns a clear timeout error and refunds credits when DeepSeek does not respond', async () => {
    globalThis.fetch = (async () => {
      throw new DOMException('The operation timed out.', 'TimeoutError')
    }) as typeof fetch

    const { handler, store } = makeGateway({
      freeCredits: 2,
      deepseekApiKey: 'deepseek-key',
      deepseekTimeoutMs: 10,
    })
    const registered = await (await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }))).json() as {
      deviceToken: string
    }

    const response = await handler(jsonRequest('/v1/messages', {
      model: 'gugu-managed-main',
      max_tokens: 16,
      messages: [{ role: 'user', content: 'hi' }],
    }, registered.deviceToken))
    const body = await response.json() as { error: { code: string; entitlement: { creditsRemaining: number } } }
    const summary = store.getDeviceSummary({ deviceToken: registered.deviceToken })
    const events = store.listUsageEvents({ deviceToken: registered.deviceToken, limit: 10 })
    const metadata = JSON.parse(events[0].metadata || '{}') as { upstreamError?: string; refundedCredits?: number }

    expect(response.status).toBe(504)
    expect(body.error.code).toBe('UPSTREAM_TIMEOUT')
    expect(body.error.entitlement.creditsRemaining).toBe(2)
    expect(summary?.entitlement.creditsRemaining).toBe(2)
    expect(metadata.upstreamError).toBe('timeout')
    expect(metadata.refundedCredits).toBe(1)
  })

  test('records DeepSeek SSE token usage without breaking streaming', async () => {
    globalThis.fetch = (async () => new Response(
      [
        'event: message_start\n',
        'data: {"type":"message_start","message":{"usage":{"input_tokens":17,"output_tokens":1}}}\n\n',
        'event: message_delta\n',
        'data: {"type":"message_delta","usage":{"output_tokens":9}}\n\n',
      ].join(''),
      { headers: { 'Content-Type': 'text/event-stream' } },
    )) as typeof fetch

    const { handler, store } = makeGateway({ freeCredits: 2, deepseekApiKey: 'deepseek-key' })
    const registered = await (await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }))).json() as {
      deviceToken: string
    }

    const response = await handler(jsonRequest('/v1/messages', {
      model: 'gugu-managed-main',
      max_tokens: 16,
      messages: [{ role: 'user', content: 'hi' }],
    }, registered.deviceToken))
    const text = await response.text()
    const events = store.listUsageEvents({ deviceToken: registered.deviceToken, limit: 10 })

    expect(response.status).toBe(200)
    expect(text).toContain('message_delta')
    expect(events[0].inputTokens).toBe(17)
    expect(events[0].outputTokens).toBe(9)
  })

  test('closes stalled DeepSeek streams, refunds credits, and opens the circuit', async () => {
    let fetchCalls = 0
    globalThis.fetch = (async () => {
      fetchCalls += 1
      return new Response(
        new ReadableStream<Uint8Array>({
          start(controller) {
            controller.enqueue(new TextEncoder().encode(
              'event: message_start\n' +
              'data: {"type":"message_start","message":{"usage":{"input_tokens":3}}}\n\n',
            ))
          },
        }),
        { headers: { 'Content-Type': 'text/event-stream' } },
      )
    }) as typeof fetch

    const { handler, store } = makeGateway({
      freeCredits: 2,
      deepseekApiKey: 'deepseek-key',
      deepseekStreamIdleTimeoutMs: 10,
      deepseekCircuitFailureThreshold: 1,
      deepseekCircuitOpenMs: 1_000,
    })
    const registered = await (await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }))).json() as {
      deviceToken: string
    }

    const response = await handler(jsonRequest('/v1/messages', {
      model: 'gugu-managed-main',
      max_tokens: 16,
      messages: [{ role: 'user', content: 'hi' }],
    }, registered.deviceToken))
    const text = await response.text()
    const second = await handler(jsonRequest('/v1/messages', {
      model: 'gugu-managed-main',
      max_tokens: 16,
      messages: [{ role: 'user', content: 'again' }],
    }, registered.deviceToken))
    const secondBody = await second.json() as { error: { code: string; entitlement: { creditsRemaining: number } } }
    const events = store.listUsageEvents({ deviceToken: registered.deviceToken, limit: 10 })
    const metadata = JSON.parse(events[0].metadata || '{}') as {
      upstreamError?: string
      refundedCredits?: number
    }

    expect(response.status).toBe(200)
    expect(text).toContain('stream was idle for too long')
    expect(second.status).toBe(503)
    expect(second.headers.get('retry-after')).toBe('1')
    expect(secondBody.error.code).toBe('UPSTREAM_CIRCUIT_OPEN')
    expect(secondBody.error.entitlement.creditsRemaining).toBe(2)
    expect(fetchCalls).toBe(1)
    expect(store.getEntitlement(registered.deviceToken).creditsRemaining).toBe(2)
    expect(metadata.upstreamError).toBe('stream_idle_timeout')
    expect(metadata.refundedCredits).toBe(1)
  })

  test('returns 429 when the message concurrency queue is full', async () => {
    const upstream = createDeferred<Response>()
    let fetchCalls = 0
    globalThis.fetch = (async () => {
      fetchCalls += 1
      return upstream.promise
    }) as typeof fetch

    const { handler, store } = makeGateway({
      freeCredits: 2,
      deepseekApiKey: 'deepseek-key',
      messageMaxConcurrency: 1,
      messageQueueLimit: 0,
    })
    const registered = await (await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }))).json() as {
      deviceToken: string
    }

    const first = handler(jsonRequest('/v1/messages', {
      model: 'gugu-managed-main',
      max_tokens: 16,
      messages: [{ role: 'user', content: 'hi' }],
    }, registered.deviceToken))
    await waitFor(() => fetchCalls === 1)

    const busy = await handler(jsonRequest('/v1/messages', {
      model: 'gugu-managed-main',
      max_tokens: 16,
      messages: [{ role: 'user', content: 'still there?' }],
    }, registered.deviceToken))
    const busyBody = await busy.json() as { error: { code: string; message: string } }

    expect(busy.status).toBe(429)
    expect(busy.headers.get('retry-after')).toBe('3')
    expect(busyBody.error.code).toBe('GATEWAY_BUSY')
    expect(fetchCalls).toBe(1)
    expect(store.getEntitlement(registered.deviceToken).creditsRemaining).toBe(1)
    expect(store.listUsageEvents({ deviceToken: registered.deviceToken, limit: 10 })).toHaveLength(1)

    upstream.resolve(jsonResponse({
      id: 'msg_1',
      type: 'message',
      content: [],
      usage: { input_tokens: 3, output_tokens: 2 },
    }))
    const firstBody = await (await first).json() as { id: string }
    expect(firstBody.id).toBe('msg_1')
  })

  test('deducts weighted attachment credits and records GLM usage tokens', async () => {
    globalThis.fetch = (async () => jsonResponse({
      ok: true,
      usage: { prompt_tokens: 21, completion_tokens: 8 },
    })) as typeof fetch

    const { handler, store } = makeGateway({
      freeCredits: 10,
      glmApiKey: 'glm-key',
      attachmentCreditCost: 6,
    })
    const registered = await (await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }))).json() as {
      deviceToken: string
    }

    const response = await handler(jsonRequest('/v1/attachments/parse', {
      operation: 'chat_completions',
      body: { model: 'glm-5v-turbo', messages: [] },
    }, registered.deviceToken))
    const summary = store.getDeviceSummary({ deviceToken: registered.deviceToken })
    const events = store.listUsageEvents({ deviceToken: registered.deviceToken, limit: 10 })

    expect(response.status).toBe(200)
    expect(response.headers.get('x-gugu-credits-remaining')).toBe('4')
    expect(summary?.entitlement.creditsRemaining).toBe(4)
    expect(events).toHaveLength(1)
    expect(events[0].kind).toBe('vision')
    expect(events[0].model).toBe('glm-5v-turbo')
    expect(events[0].credits).toBe(6)
    expect(events[0].inputTokens).toBe(21)
    expect(events[0].outputTokens).toBe(8)
  })

  test('rate limits attachment parsing by device plan before consuming credits', async () => {
    let fetchCalls = 0
    globalThis.fetch = (async () => {
      fetchCalls += 1
      return jsonResponse({ ok: true })
    }) as typeof fetch

    const { handler, store } = makeGateway({
      freeCredits: 20,
      glmApiKey: 'glm-key',
      freeAttachmentRateLimitPerMinute: 1,
    })
    const registered = await (await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }))).json() as {
      deviceToken: string
    }

    const first = await handler(jsonRequest('/v1/attachments/parse', {
      operation: 'chat_completions',
      body: { model: 'glm-5v-turbo', messages: [] },
    }, registered.deviceToken))
    await first.json()
    const second = await handler(jsonRequest('/v1/attachments/parse', {
      operation: 'chat_completions',
      body: { model: 'glm-5v-turbo', messages: [] },
    }, registered.deviceToken))
    const secondBody = await second.json() as { error: { code: string; entitlement: { creditsRemaining: number } } }

    expect(second.status).toBe(429)
    expect(second.headers.get('x-gugu-ratelimit-limit')).toBe('1')
    expect(secondBody.error.code).toBe('RATE_LIMITED')
    expect(secondBody.error.entitlement.creditsRemaining).toBe(14)
    expect(fetchCalls).toBe(1)
    expect(store.listUsageEvents({ deviceToken: registered.deviceToken, limit: 10 })).toHaveLength(1)
  })

  test('uses summary and OCR credit weights for GLM attachment operations', async () => {
    globalThis.fetch = (async () => jsonResponse({ ok: true })) as typeof fetch

    const { handler, store } = makeGateway({
      freeCredits: 10,
      glmApiKey: 'glm-key',
      fileParseCreditCost: 3,
      summarizeCreditCost: 4,
    })
    const registered = await (await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }))).json() as {
      deviceToken: string
    }

    await handler(jsonRequest('/v1/attachments/parse', {
      operation: 'layout_parsing',
      body: { model: 'glm-ocr' },
    }, registered.deviceToken))
    await handler(jsonRequest('/v1/attachments/parse', {
      operation: 'chat_completions',
      body: { model: 'glm-5.1', messages: [] },
    }, registered.deviceToken))

    const events = store.listUsageEvents({ deviceToken: registered.deviceToken, limit: 10 })
    expect(events.map((event) => event.kind)).toEqual(['summarize', 'ocr'])
    expect(events.map((event) => event.credits)).toEqual([4, 3])
    expect(store.getEntitlement(registered.deviceToken).creditsRemaining).toBe(3)
  })

  test('times out queued GLM requests without blocking health checks', async () => {
    const upstream = createDeferred<Response>()
    let fetchCalls = 0
    globalThis.fetch = (async () => {
      fetchCalls += 1
      return upstream.promise
    }) as typeof fetch

    const { handler, store } = makeGateway({
      freeCredits: 20,
      glmApiKey: 'glm-key',
      glmMaxConcurrency: 1,
      glmQueueLimit: 1,
      glmQueueTimeoutMs: 10,
    })
    const registered = await (await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }))).json() as {
      deviceToken: string
    }

    const first = handler(jsonRequest('/v1/attachments/parse', {
      operation: 'chat_completions',
      body: { model: 'glm-5v-turbo', messages: [] },
    }, registered.deviceToken))
    await waitFor(() => fetchCalls === 1)

    const queued = handler(jsonRequest('/v1/attachments/parse', {
      operation: 'chat_completions',
      body: { model: 'glm-5v-turbo', messages: [] },
    }, registered.deviceToken))
    const health = await handler(getRequest('/health'))
    const busy = await queued
    const busyBody = await busy.json() as { error: { code: string; message: string } }

    expect(health.status).toBe(200)
    expect(busy.status).toBe(429)
    expect(busy.headers.get('retry-after')).toBe('1')
    expect(busyBody.error.code).toBe('GATEWAY_BUSY')
    expect(fetchCalls).toBe(1)
    expect(store.getEntitlement(registered.deviceToken).creditsRemaining).toBe(14)
    expect(store.listUsageEvents({ deviceToken: registered.deviceToken, limit: 10 })).toHaveLength(1)

    upstream.resolve(jsonResponse({ ok: true }))
    expect((await first).status).toBe(200)
  })

  test('opens the GLM circuit after upstream failures before consuming more credits', async () => {
    let fetchCalls = 0
    globalThis.fetch = (async () => {
      fetchCalls += 1
      throw new TypeError('network down')
    }) as typeof fetch

    const { handler, store } = makeGateway({
      freeCredits: 20,
      glmApiKey: 'glm-key',
      glmCircuitFailureThreshold: 1,
      glmCircuitOpenMs: 1_000,
    })
    const registered = await (await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }))).json() as {
      deviceToken: string
    }

    const first = await handler(jsonRequest('/v1/attachments/parse', {
      operation: 'chat_completions',
      body: { model: 'glm-5v-turbo', messages: [] },
    }, registered.deviceToken))
    const firstBody = await first.json() as { error: { code: string; entitlement: { creditsRemaining: number } } }
    const second = await handler(jsonRequest('/v1/attachments/parse', {
      operation: 'chat_completions',
      body: { model: 'glm-5v-turbo', messages: [] },
    }, registered.deviceToken))
    const secondBody = await second.json() as { error: { code: string; entitlement: { creditsRemaining: number } } }
    const events = store.listUsageEvents({ deviceToken: registered.deviceToken, limit: 10 })
    const metadata = JSON.parse(events[0].metadata || '{}') as { upstreamError?: string; refundedCredits?: number }

    expect(first.status).toBe(502)
    expect(firstBody.error.code).toBe('UPSTREAM_NETWORK_ERROR')
    expect(firstBody.error.entitlement.creditsRemaining).toBe(20)
    expect(second.status).toBe(503)
    expect(secondBody.error.code).toBe('UPSTREAM_CIRCUIT_OPEN')
    expect(secondBody.error.entitlement.creditsRemaining).toBe(20)
    expect(fetchCalls).toBe(1)
    expect(events).toHaveLength(1)
    expect(metadata.upstreamError).toBe('network')
    expect(metadata.refundedCredits).toBe(6)
  })

  test('rejects oversized GLM file parser payloads before consuming credits', async () => {
    let fetchCalls = 0
    globalThis.fetch = (async () => {
      fetchCalls += 1
      return jsonResponse({ ok: true })
    }) as typeof fetch

    const { handler, store } = makeGateway({
      freeCredits: 10,
      glmApiKey: 'glm-key',
      glmFileParseMaxBytes: 4,
    })
    const registered = await (await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }))).json() as {
      deviceToken: string
    }

    const response = await handler(jsonRequest('/v1/attachments/parse', {
      operation: 'file_parser',
      name: 'large.docx',
      mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      dataBase64: Buffer.alloc(5, 1).toString('base64'),
    }, registered.deviceToken))
    const body = await response.json() as { error: { code: string; message: string } }

    expect(response.status).toBe(413)
    expect(body.error.code).toBe('PAYLOAD_TOO_LARGE')
    expect(fetchCalls).toBe(0)
    expect(store.getEntitlement(registered.deviceToken).creditsRemaining).toBe(10)
    expect(store.listUsageEvents({ deviceToken: registered.deviceToken, limit: 10 })).toHaveLength(0)
  })

  test('rejects unsupported GLM file MIME types before consuming credits', async () => {
    let fetchCalls = 0
    globalThis.fetch = (async () => {
      fetchCalls += 1
      return jsonResponse({ ok: true })
    }) as typeof fetch

    const { handler, store } = makeGateway({
      freeCredits: 10,
      glmApiKey: 'glm-key',
    })
    const registered = await (await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }))).json() as {
      deviceToken: string
    }

    const response = await handler(jsonRequest('/v1/attachments/parse', {
      operation: 'file_parser',
      name: 'archive.zip',
      mimeType: 'application/zip',
      dataBase64: Buffer.from('zip-content').toString('base64'),
    }, registered.deviceToken))
    const body = await response.json() as { error: { code: string; message: string } }

    expect(response.status).toBe(400)
    expect(body.error.code).toBe('UNSUPPORTED_FILE_TYPE')
    expect(fetchCalls).toBe(0)
    expect(store.getEntitlement(registered.deviceToken).creditsRemaining).toBe(10)
    expect(store.listUsageEvents({ deviceToken: registered.deviceToken, limit: 10 })).toHaveLength(0)
  })

  test('rejects oversized GLM layout files before consuming credits', async () => {
    let fetchCalls = 0
    globalThis.fetch = (async () => {
      fetchCalls += 1
      return jsonResponse({ ok: true })
    }) as typeof fetch

    const { handler, store } = makeGateway({
      freeCredits: 10,
      glmApiKey: 'glm-key',
      glmFileParseMaxBytes: 4,
    })
    const registered = await (await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }))).json() as {
      deviceToken: string
    }

    const response = await handler(jsonRequest('/v1/attachments/parse', {
      operation: 'layout_parsing',
      body: {
        model: 'glm-ocr',
        file: `data:application/pdf;base64,${Buffer.alloc(5, 1).toString('base64')}`,
      },
    }, registered.deviceToken))
    const body = await response.json() as { error: { code: string; message: string } }

    expect(response.status).toBe(413)
    expect(body.error.code).toBe('PAYLOAD_TOO_LARGE')
    expect(fetchCalls).toBe(0)
    expect(store.getEntitlement(registered.deviceToken).creditsRemaining).toBe(10)
    expect(store.listUsageEvents({ deviceToken: registered.deviceToken, limit: 10 })).toHaveLength(0)
  })

  test('rejects unsupported GLM image MIME types before consuming credits', async () => {
    let fetchCalls = 0
    globalThis.fetch = (async () => {
      fetchCalls += 1
      return jsonResponse({ ok: true })
    }) as typeof fetch

    const { handler, store } = makeGateway({
      freeCredits: 10,
      glmApiKey: 'glm-key',
    })
    const registered = await (await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }))).json() as {
      deviceToken: string
    }

    const response = await handler(jsonRequest('/v1/attachments/parse', {
      operation: 'chat_completions',
      body: {
        model: 'glm-5v-turbo',
        messages: [{
          role: 'user',
          content: [{
            type: 'image_url',
            image_url: {
              url: `data:image/webp;base64,${Buffer.from('image').toString('base64')}`,
            },
          }],
        }],
      },
    }, registered.deviceToken))
    const body = await response.json() as { error: { code: string; message: string } }

    expect(response.status).toBe(400)
    expect(body.error.code).toBe('UNSUPPORTED_FILE_TYPE')
    expect(fetchCalls).toBe(0)
    expect(store.getEntitlement(registered.deviceToken).creditsRemaining).toBe(10)
    expect(store.listUsageEvents({ deviceToken: registered.deviceToken, limit: 10 })).toHaveLength(0)
  })

  test('creates manual orders and fulfills them idempotently', async () => {
    const { handler, store } = makeGateway({ adminToken: 'secret' })

    const created = await handler(jsonRequest('/v1/orders', {
      packageId: 'pro-monthly',
      contact: 'wechat: gugu',
    }))
    const createdBody = await created.json() as {
      order: { orderId: string; status: string; amountCents: number }
      orderToken: string
      payment: null
    }
    const listed = await handler(getRequest('/admin/api/orders?q=gugu', 'secret'))
    const listedBody = await listed.json() as { data: Array<{ orderId: string; contact: string | null }> }
    const missingStatus = await handler(orderStatusRequest(createdBody.order.orderId))
    const wrongStatus = await handler(orderStatusRequest(createdBody.order.orderId, 'wrong-token'))
    const pendingStatus = await handler(orderStatusRequest(createdBody.order.orderId, createdBody.orderToken))
    const pendingStatusBody = await pendingStatus.json() as { order: { status: string }; licenseKey: string | null }
    const paid = store.markOrderPaid(createdBody.order.orderId)
    const fulfilled = store.fulfillOrder(createdBody.order.orderId)
    const fulfilledAgain = store.fulfillOrder(createdBody.order.orderId)
    const fulfilledStatus = await handler(orderStatusRequest(createdBody.order.orderId, createdBody.orderToken))
    const fulfilledStatusBody = await fulfilledStatus.json() as { order: { status: string }; licenseKey: string | null }

    expect(created.status).toBe(200)
    expect(createdBody.order.status).toBe('pending_payment')
    expect(createdBody.order.amountCents).toBe(4900)
    expect(createdBody.orderToken.startsWith('ord_')).toBe(true)
    expect(createdBody.payment).toBeNull()
    expect(listedBody.data[0]?.orderId).toBe(createdBody.order.orderId)
    expect(listedBody.data[0]?.contact).toBe('wechat: gugu')
    expect(missingStatus.status).toBe(401)
    expect(wrongStatus.status).toBe(401)
    expect(pendingStatus.status).toBe(200)
    expect(pendingStatusBody.order.status).toBe('pending_payment')
    expect(pendingStatusBody.licenseKey).toBeNull()
    expect(paid.status).toBe('paid')
    expect(fulfilled.status).toBe('fulfilled')
    expect(fulfilled.licenseKey?.startsWith('GUGU-')).toBe(true)
    expect(fulfilledAgain.licenseKey).toBe(fulfilled.licenseKey)
    expect(fulfilledStatusBody.order.status).toBe('fulfilled')
    expect(fulfilledStatusBody.licenseKey).toBe(fulfilled.licenseKey)
  })

  test('rate limits order creation by IP before creating another order', async () => {
    const { handler, store } = makeGateway({ orderCreateRateLimitPerMinute: 1 })

    const first = await handler(jsonRequest('/v1/orders', {
      packageId: 'pro-monthly',
      contact: 'wechat: gugu',
    }, undefined, { 'X-Forwarded-For': '198.51.100.20' }))
    const second = await handler(jsonRequest('/v1/orders', {
      packageId: 'light-monthly',
      contact: 'wechat: gugu',
    }, undefined, { 'X-Forwarded-For': '198.51.100.20' }))
    const secondBody = await second.json() as { error: { code: string } }

    expect(first.status).toBe(200)
    expect(second.status).toBe(429)
    expect(second.headers.get('retry-after')).toBe('60')
    expect(secondBody.error.code).toBe('RATE_LIMITED')
    expect(store.listOrders({ limit: 10 }).data).toHaveLength(1)
  })

  test('maintenance mode blocks new orders and marks checkout pages', async () => {
    const { handler } = makeGateway({
      maintenanceMode: true,
      maintenanceDisableOrders: true,
      maintenanceMessage: '凌晨维护中',
    })

    const buy = await handler(getRequest('/buy'))
    const checkout = await handler(getRequest('/checkout?packageId=pro-monthly'))
    const order = await handler(jsonRequest('/v1/orders', {
      packageId: 'pro-monthly',
      paymentProvider: 'wechat',
    }))
    const orderBody = await order.json() as { error: { code: string; message: string } }

    expect(buy.status).toBe(200)
    expect(await buy.text()).toContain('凌晨维护中')
    expect(checkout.status).toBe(200)
    expect(await checkout.text()).toContain('购买和支付暂不可用')
    expect(order.status).toBe(503)
    expect(orderBody.error.code).toBe('MAINTENANCE')
    expect(orderBody.error.message).toBe('凌晨维护中')
  })

  test('creates WeChat Native orders when payment is configured', async () => {
    const fixture = await makeWechatPayFixture(tmpDir)
    const nativeCalls: Array<{ url: string; authorization: string | null; body: Record<string, unknown> }> = []
    globalThis.fetch = (async (input, init) => {
      const body = JSON.parse(String(init?.body ?? '{}')) as Record<string, unknown>
      nativeCalls.push({
        url: String(input),
        authorization: new Headers(init?.headers).get('authorization'),
        body,
      })
      return signedWechatResponse(fixture, JSON.stringify({ code_url: 'weixin://wxpay/test-code' }))
    }) as typeof fetch

    const { handler } = makeGateway({ wechatPay: fixture.config })
    const created = await handler(jsonRequest('/v1/orders', {
      packageId: 'pro-monthly',
      contact: 'wechat: gugu',
      paymentProvider: 'wechat',
    }))
    const body = await created.json() as {
      order: {
        orderId: string
        paymentProvider: string | null
        paymentCodeUrl: string | null
        paymentExpiresAt: string | null
      }
      orderToken: string
      payment: { provider: string; codeUrl: string; qrDataUrl: string; expiresAt: string }
    }

    expect(created.status).toBe(200)
    expect(nativeCalls).toHaveLength(1)
    expect(nativeCalls[0]?.url).toBe('https://api.mch.weixin.qq.com/v3/pay/transactions/native')
    expect(nativeCalls[0]?.authorization).toContain('mchid="1900000001"')
    expect(nativeCalls[0]?.body.out_trade_no).toBe(body.order.orderId)
    expect((nativeCalls[0]?.body.amount as { total?: number }).total).toBe(4900)
    expect(nativeCalls[0]?.body.notify_url).toBe(fixture.config.notifyUrl)
    expect(body.order.paymentProvider).toBe('wechat')
    expect(body.order.paymentCodeUrl).toBe('weixin://wxpay/test-code')
    expect(body.order.paymentExpiresAt).toBe(body.payment.expiresAt)
    expect(body.orderToken.startsWith('ord_')).toBe(true)
    expect(body.payment.provider).toBe('wechat')
    expect(body.payment.codeUrl).toBe('weixin://wxpay/test-code')
    expect(body.payment.qrDataUrl.startsWith('data:image/png;base64,')).toBe(true)
  })

  test('falls back to a manual order when WeChat Native creation fails', async () => {
    const fixture = await makeWechatPayFixture(tmpDir)
    globalThis.fetch = (async () => jsonResponse({
      code: 'SYSTEM_ERROR',
      message: 'try again later',
    }, { status: 500 })) as typeof fetch

    const { handler } = makeGateway({ wechatPay: fixture.config })
    const response = await handler(jsonRequest('/v1/orders', {
      packageId: 'light-monthly',
      contact: 'wechat: gugu',
    }))
    const body = await response.json() as {
      order: { status: string; paymentProvider: string | null }
      orderToken: string
      payment: null
      paymentError: string
    }

    expect(response.status).toBe(200)
    expect(body.order.status).toBe('pending_payment')
    expect(body.order.paymentProvider).toBeNull()
    expect(body.orderToken.startsWith('ord_')).toBe(true)
    expect(body.payment).toBeNull()
    expect(body.paymentError).toContain('SYSTEM_ERROR')
  })

  test('rejects invalid WeChat notifications without fulfilling orders', async () => {
    const fixture = await makeWechatPayFixture(tmpDir)
    const { handler, store } = makeGateway({ wechatPay: fixture.config })
    const order = store.createOrder({ packageId: 'light-monthly' })
    const orderToken = store.getOrderToken(order.orderId)

    const invalidSignature = await handler(wechatNotifyRequest(fixture, {
      orderId: order.orderId,
      transactionId: 'wx-tx-invalid-signature',
      amountCents: order.amountCents,
      tamperSignature: true,
    }))
    const wrongAmount = await handler(wechatNotifyRequest(fixture, {
      orderId: order.orderId,
      transactionId: 'wx-tx-wrong-amount',
      amountCents: order.amountCents + 1,
    }))
    const unknownOrder = await handler(wechatNotifyRequest(fixture, {
      orderId: 'GUGU-20990101-NOTFOUND',
      transactionId: 'wx-tx-unknown-order',
      amountCents: order.amountCents,
    }))
    const status = await handler(orderStatusRequest(order.orderId, orderToken))
    const statusBody = await status.json() as { order: { status: string }; licenseKey: string | null }

    expect(invalidSignature.status).toBe(400)
    expect(wrongAmount.status).toBe(400)
    expect(unknownOrder.status).toBe(400)
    expect(statusBody.order.status).toBe('pending_payment')
    expect(statusBody.licenseKey).toBeNull()
  })

  test('fulfills WeChat success notifications idempotently', async () => {
    const fixture = await makeWechatPayFixture(tmpDir)
    const { handler, store } = makeGateway({ wechatPay: fixture.config })
    const order = store.createOrder({ packageId: 'max-monthly' })
    const orderToken = store.getOrderToken(order.orderId)

    const firstNotify = await handler(wechatNotifyRequest(fixture, {
      orderId: order.orderId,
      transactionId: 'wx-tx-success',
      amountCents: order.amountCents,
    }))
    const firstStatus = await handler(orderStatusRequest(order.orderId, orderToken))
    const firstStatusBody = await firstStatus.json() as {
      order: { status: string; wechatTransactionId: string | null; paidAmountCents: number | null }
      licenseKey: string | null
    }
    const secondNotify = await handler(wechatNotifyRequest(fixture, {
      orderId: order.orderId,
      transactionId: 'wx-tx-success',
      amountCents: order.amountCents,
    }))
    const secondStatus = await handler(orderStatusRequest(order.orderId, orderToken))
    const secondStatusBody = await secondStatus.json() as { licenseKey: string | null }

    expect(firstNotify.status).toBe(204)
    expect(secondNotify.status).toBe(204)
    expect(firstStatusBody.order.status).toBe('fulfilled')
    expect(firstStatusBody.order.wechatTransactionId).toBe('wx-tx-success')
    expect(firstStatusBody.order.paidAmountCents).toBe(order.amountCents)
    expect(firstStatusBody.licenseKey?.startsWith('GUGU-')).toBe(true)
    expect(secondStatusBody.licenseKey).toBe(firstStatusBody.licenseKey)
  })

  test('rejects WeChat notifications that reuse a transaction id for another order', async () => {
    const fixture = await makeWechatPayFixture(tmpDir)
    const { handler, store } = makeGateway({ wechatPay: fixture.config })
    const firstOrder = store.createOrder({ packageId: 'max-monthly' })
    const secondOrder = store.createOrder({ packageId: 'max-monthly' })
    const firstToken = store.getOrderToken(firstOrder.orderId)
    const secondToken = store.getOrderToken(secondOrder.orderId)

    const firstNotify = await handler(wechatNotifyRequest(fixture, {
      orderId: firstOrder.orderId,
      transactionId: 'wx-tx-reused',
      amountCents: firstOrder.amountCents,
      notificationId: 'wx-notify-1',
    }))
    const secondNotify = await handler(wechatNotifyRequest(fixture, {
      orderId: secondOrder.orderId,
      transactionId: 'wx-tx-reused',
      amountCents: secondOrder.amountCents,
      notificationId: 'wx-notify-2',
    }))
    const firstStatus = await (await handler(orderStatusRequest(firstOrder.orderId, firstToken))).json() as {
      order: { status: string }
    }
    const secondStatus = await (await handler(orderStatusRequest(secondOrder.orderId, secondToken))).json() as {
      order: { status: string }
      licenseKey: string | null
    }

    expect(firstNotify.status).toBe(204)
    expect(secondNotify.status).toBe(400)
    expect(firstStatus.order.status).toBe('fulfilled')
    expect(secondStatus.order.status).toBe('pending_payment')
    expect(secondStatus.licenseKey).toBeNull()
    expect(store.getPaymentNotificationStatus('wechat', 'wx-notify-1')).toBe('processed')
    expect(store.getPaymentNotificationStatus('wechat', 'wx-notify-2')).toBe('failed')
  })

  test('rejects removed topup packages from public orders', async () => {
    const { handler } = makeGateway()

    const response = await handler(jsonRequest('/v1/orders', {
      packageId: 'topup-large',
    }))
    const body = await response.json() as { error: { code: string; message: string } }

    expect(response.status).toBe(400)
    expect(body.error.code).toBe('BAD_REQUEST')
    expect(body.error.message).toContain('not available')
  })

  test('creates manual fallback orders when Alipay is unavailable', async () => {
    const { handler } = makeGateway()

    const response = await handler(jsonRequest('/v1/orders', {
      packageId: 'light-monthly',
      paymentProvider: 'alipay',
    }))
    const body = await response.json() as {
      order: { status: string; paymentProvider: string | null }
      orderToken: string
      payment: null
    }

    expect(response.status).toBe(200)
    expect(body.order.status).toBe('pending_payment')
    expect(body.order.paymentProvider).toBeNull()
    expect(body.orderToken.startsWith('ord_')).toBe(true)
    expect(body.payment).toBeNull()
  })

  test('creates Alipay page-pay orders with a direct Alipay QR URL', async () => {
    const fixture = await makeAlipayFixture(tmpDir)
    const fetchCalls: string[] = []
    globalThis.fetch = (async (input) => {
      fetchCalls.push(String(input))
      return jsonResponse({ unexpected: true })
    }) as typeof fetch

    const { handler } = makeGateway({
      publicBaseUrl: 'https://gugu.example.com',
      alipay: fixture.config,
    })
    const created = await handler(jsonRequest('/v1/orders', {
      packageId: 'pro-monthly',
      contact: 'alipay: gugu',
      paymentProvider: 'alipay',
    }))
    const body = await created.json() as {
      order: {
        orderId: string
        paymentProvider: string | null
        paymentCodeUrl: string | null
        paymentExpiresAt: string | null
        paymentPayload: string | null
      }
      orderToken: string
      payment: { provider: string; codeUrl: string; qrDataUrl: string; expiresAt: string }
    }
    const codeUrl = new URL(body.payment.codeUrl)
    const bizContent = JSON.parse(codeUrl.searchParams.get('biz_content') || '{}') as Record<string, unknown>
    const paymentPayload = JSON.parse(body.order.paymentPayload || '{}') as Record<string, unknown>

    expect(created.status).toBe(200)
    expect(fetchCalls).toHaveLength(0)
    expect(`${codeUrl.origin}${codeUrl.pathname}`).toBe(fixture.config.gatewayUrl)
    expect(codeUrl.searchParams.get('method')).toBe('alipay.trade.page.pay')
    expect(codeUrl.searchParams.get('app_id')).toBe(fixture.config.appId)
    expect(codeUrl.searchParams.get('sign_type')).toBe('RSA2')
    expect(codeUrl.searchParams.get('notify_url')).toBe(fixture.config.notifyUrl)
    expect(codeUrl.searchParams.get('sign')).toBeTruthy()
    expect(body.payment.codeUrl).not.toContain('gugu.example.com/v1/payments/alipay/checkout')
    expect(bizContent.out_trade_no).toBe(body.order.orderId)
    expect(bizContent.total_amount).toBe('49.00')
    expect(bizContent.product_code).toBe('FAST_INSTANT_TRADE_PAY')
    expect(body.order.paymentProvider).toBe('alipay')
    expect(body.order.paymentCodeUrl).toBe(body.payment.codeUrl)
    expect(body.order.paymentExpiresAt).toBe(body.payment.expiresAt)
    expect(body.orderToken.startsWith('ord_')).toBe(true)
    expect(body.payment.provider).toBe('alipay')
    expect(body.payment.qrDataUrl.startsWith('data:image/png;base64,')).toBe(true)
    expect(paymentPayload.cashierUrl).toBe(body.payment.codeUrl)
  })

  test('rejects invalid Alipay notifications without fulfilling orders', async () => {
    const fixture = await makeAlipayFixture(tmpDir)
    const { handler, store } = makeGateway({ alipay: fixture.config })
    const order = store.createOrder({ packageId: 'light-monthly' })
    const orderToken = store.getOrderToken(order.orderId)

    const invalidSignature = await handler(alipayNotifyRequest(fixture, {
      orderId: order.orderId,
      transactionId: 'ali-tx-invalid-signature',
      amountCents: order.amountCents,
      tamperSignature: true,
    }))
    const wrongAmount = await handler(alipayNotifyRequest(fixture, {
      orderId: order.orderId,
      transactionId: 'ali-tx-wrong-amount',
      amountCents: order.amountCents + 1,
    }))
    const unknownOrder = await handler(alipayNotifyRequest(fixture, {
      orderId: 'GUGU-20990101-NOTFOUND',
      transactionId: 'ali-tx-unknown-order',
      amountCents: order.amountCents,
    }))
    const status = await handler(orderStatusRequest(order.orderId, orderToken))
    const statusBody = await status.json() as { order: { status: string }; licenseKey: string | null }

    expect(invalidSignature.status).toBe(400)
    expect(await invalidSignature.text()).toBe('fail')
    expect(wrongAmount.status).toBe(400)
    expect(unknownOrder.status).toBe(400)
    expect(statusBody.order.status).toBe('pending_payment')
    expect(statusBody.licenseKey).toBeNull()
  })

  test('fulfills Alipay success notifications idempotently', async () => {
    const fixture = await makeAlipayFixture(tmpDir)
    const { handler, store } = makeGateway({ alipay: fixture.config })
    const order = store.createOrder({ packageId: 'max-monthly' })
    const orderToken = store.getOrderToken(order.orderId)

    const firstNotify = await handler(alipayNotifyRequest(fixture, {
      orderId: order.orderId,
      transactionId: 'ali-tx-success',
      amountCents: order.amountCents,
    }))
    const firstStatus = await handler(orderStatusRequest(order.orderId, orderToken))
    const firstStatusBody = await firstStatus.json() as {
      order: { status: string; alipayTradeNo: string | null; paidAmountCents: number | null }
      licenseKey: string | null
    }
    const secondNotify = await handler(alipayNotifyRequest(fixture, {
      orderId: order.orderId,
      transactionId: 'ali-tx-success',
      amountCents: order.amountCents,
    }))
    const secondStatus = await handler(orderStatusRequest(order.orderId, orderToken))
    const secondStatusBody = await secondStatus.json() as { licenseKey: string | null }

    expect(firstNotify.status).toBe(200)
    expect(await firstNotify.text()).toBe('success')
    expect(secondNotify.status).toBe(200)
    expect(await secondNotify.text()).toBe('success')
    expect(firstStatusBody.order.status).toBe('fulfilled')
    expect(firstStatusBody.order.alipayTradeNo).toBe('ali-tx-success')
    expect(firstStatusBody.order.paidAmountCents).toBe(order.amountCents)
    expect(firstStatusBody.licenseKey?.startsWith('GUGU-')).toBe(true)
    expect(secondStatusBody.licenseKey).toBe(firstStatusBody.licenseKey)
  })

  test('records Alipay notifications and rejects reused trade numbers', async () => {
    const fixture = await makeAlipayFixture(tmpDir)
    const { handler, store } = makeGateway({ alipay: fixture.config })
    const firstOrder = store.createOrder({ packageId: 'pro-monthly' })
    const secondOrder = store.createOrder({ packageId: 'pro-monthly' })
    const firstToken = store.getOrderToken(firstOrder.orderId)
    const secondToken = store.getOrderToken(secondOrder.orderId)

    const firstNotify = await handler(alipayNotifyRequest(fixture, {
      orderId: firstOrder.orderId,
      transactionId: 'ali-tx-reused',
      amountCents: firstOrder.amountCents,
      notificationId: 'ali-notify-1',
    }))
    const duplicateNotify = await handler(alipayNotifyRequest(fixture, {
      orderId: firstOrder.orderId,
      transactionId: 'ali-tx-reused',
      amountCents: firstOrder.amountCents,
      notificationId: 'ali-notify-1',
    }))
    const secondNotify = await handler(alipayNotifyRequest(fixture, {
      orderId: secondOrder.orderId,
      transactionId: 'ali-tx-reused',
      amountCents: secondOrder.amountCents,
      notificationId: 'ali-notify-2',
    }))
    const firstStatus = await (await handler(orderStatusRequest(firstOrder.orderId, firstToken))).json() as {
      order: { status: string }
    }
    const secondStatus = await (await handler(orderStatusRequest(secondOrder.orderId, secondToken))).json() as {
      order: { status: string }
      licenseKey: string | null
    }

    expect(firstNotify.status).toBe(200)
    expect(await firstNotify.text()).toBe('success')
    expect(duplicateNotify.status).toBe(200)
    expect(await duplicateNotify.text()).toBe('success')
    expect(secondNotify.status).toBe(400)
    expect(await secondNotify.text()).toBe('fail')
    expect(firstStatus.order.status).toBe('fulfilled')
    expect(secondStatus.order.status).toBe('pending_payment')
    expect(secondStatus.licenseKey).toBeNull()
    expect(store.getPaymentNotificationStatus('alipay', 'ali-notify-1')).toBe('processed')
    expect(store.getPaymentNotificationStatus('alipay', 'ali-notify-2')).toBe('failed')
  })

  test('protects dashboard APIs with the admin token', async () => {
    const disabled = makeGateway()
    const disabledDashboard = await disabled.handler(getRequest('/admin/dashboard'))
    const disabledSummary = await disabled.handler(getRequest('/admin/api/summary'))

    const enabled = makeGateway({ adminToken: 'secret' })
    const noToken = await enabled.handler(getRequest('/admin/api/summary'))
    const withToken = await enabled.handler(getRequest('/admin/api/summary?range=30d', 'secret'))
    const downloadInfo = await enabled.handler(getRequest('/admin/api/download', 'secret'))
    const dashboard = await enabled.handler(getRequest('/admin/dashboard'))
    const body = await withToken.json() as { range: string; devices: { total: number } }
    const downloadBody = await downloadInfo.json() as { downloadUrl: string | null }

    expect(disabledDashboard.status).toBe(404)
    expect(disabledSummary.status).toBe(404)
    expect(noToken.status).toBe(401)
    expect(withToken.status).toBe(200)
    expect(downloadInfo.status).toBe(200)
    expect(downloadBody.downloadUrl).toBeNull()
    expect(body.range).toBe('30d')
    expect(body.devices.total).toBe(0)
    expect(dashboard.status).toBe(200)
    expect(await dashboard.text()).toContain('/admin/api/summary')
    expect(await (await enabled.handler(getRequest('/admin/dashboard'))).text()).toContain('/admin/api/download')
  })

  test('exposes lightweight gateway metrics without leaking device tokens', async () => {
    globalThis.fetch = (async () => jsonResponse({
      id: 'msg_1',
      type: 'message',
      content: [],
      usage: { input_tokens: 1, output_tokens: 1 },
    })) as typeof fetch

    const { handler } = makeGateway({
      adminToken: 'secret',
      freeCredits: 5,
      deepseekApiKey: 'deepseek-key',
      freeMessageRateLimitPerMinute: 1,
    })
    const registered = await (await handler(jsonRequest('/v1/devices', { deviceId: 'device-1' }))).json() as {
      deviceToken: string
    }

    await handler(jsonRequest('/v1/messages', {
      model: 'gugu-managed-main',
      max_tokens: 16,
      messages: [{ role: 'user', content: 'hi' }],
    }, registered.deviceToken))
    const limited = await handler(jsonRequest('/v1/messages', {
      model: 'gugu-managed-main',
      max_tokens: 16,
      messages: [{ role: 'user', content: 'again' }],
    }, registered.deviceToken))
    const metricsResponse = await handler(getRequest('/admin/api/metrics', 'secret'))
    const metrics = await metricsResponse.json() as {
      requests: {
        total: number
        byStatusClass: Record<string, number>
        byErrorCode: Record<string, number>
        recent: Array<{ path: string; status: number; errorCode?: string; deviceHash?: string }>
      }
      queues: { message: { active: number; waiting: number }; glm: { active: number; waiting: number } }
      circuits: { deepseek: { state: string }; glm: { state: string } }
    }
    const metricsText = JSON.stringify(metrics)

    expect(limited.status).toBe(429)
    expect(metricsResponse.status).toBe(200)
    expect(metrics.requests.total).toBeGreaterThanOrEqual(3)
    expect(metrics.requests.byStatusClass['2xx']).toBeGreaterThanOrEqual(2)
    expect(metrics.requests.byErrorCode.RATE_LIMITED).toBe(1)
    expect(metrics.queues.message.active).toBeGreaterThanOrEqual(0)
    expect(metrics.queues.message.waiting).toBe(0)
    expect(metrics.queues.glm.waiting).toBe(0)
    expect(metrics.circuits.deepseek.state).toBe('closed')
    expect(metrics.circuits.glm.state).toBe('closed')
    expect(metrics.requests.recent.some((entry) => entry.path === '/v1/messages' && entry.deviceHash)).toBe(true)
    expect(metricsText).not.toContain(registered.deviceToken)
  })

  test('writes structured request logs when enabled', async () => {
    const logs: string[] = []
    const originalInfo = console.info
    console.info = (...args: unknown[]) => {
      logs.push(args.map(String).join(' '))
    }

    try {
      const { handler } = makeGateway({ requestLogEnabled: true })
      const response = await handler(getRequest('/missing'))
      const body = await response.json() as { error: { code: string } }
      const record = JSON.parse(logs[0] || '{}') as {
        event?: string
        method?: string
        path?: string
        status?: number
        errorCode?: string
        requestId?: string
      }

      expect(response.status).toBe(404)
      expect(response.headers.get('x-gugu-request-id')).toBeTruthy()
      expect(response.headers.get('x-gugu-error-code')).toBe('NOT_FOUND')
      expect(body.error.code).toBe('NOT_FOUND')
      expect(record.event).toBe('gateway_request')
      expect(record.method).toBe('GET')
      expect(record.path).toBe('/missing')
      expect(record.status).toBe(404)
      expect(record.errorCode).toBe('NOT_FOUND')
      expect(record.requestId).toBe(response.headers.get('x-gugu-request-id'))
    } finally {
      console.info = originalInfo
    }
  })

  test('issues package activation codes with package defaults', async () => {
    const { store } = makeGateway()
    const licenseKey = store.issueActivationCodeForPackage('pro-monthly')
    const registered = store.registerDevice({ deviceId: 'device-1' })
    const entitlement = store.activate(registered.deviceToken, licenseKey)

    expect(licenseKey.startsWith('GUGU-')).toBe(true)
    expect(entitlement.plan).toBe('pro')
    expect(entitlement.creditsTotal).toBe(600)
  })

  function makeGateway(overrides: Partial<GatewayConfig> = {}) {
    const config: GatewayConfig = {
      storeDriver: 'sqlite',
      dbPath: path.join(tmpDir, 'gateway.sqlite'),
      mysqlUrl: '',
      freeCredits: 5,
      purchaseUrl: 'https://buy.example.com',
      publicBaseUrl: null,
      icpRecord: null,
      icpUrl: 'https://beian.miit.gov.cn/',
      downloadUrl: null,
      downloadReleaseJsonUrl: null,
      downloadWindowsUrl: null,
      downloadMacosUrl: null,
      downloadVersion: null,
      downloadSha256: null,
      downloadWindowsSha256: null,
      downloadMacosSha256: null,
      adminToken: '',
      requestLogEnabled: false,
      dashboardTokenPerCredit: null,
      maintenanceMode: false,
      maintenanceDisableOrders: false,
      maintenanceMessage: '系统维护中，购买和支付暂不可用，已支付订单会自动补发。',
      deepseekApiKey: '',
      deepseekBaseUrl: 'https://deepseek.example.com/anthropic',
      deepseekMainModel: 'deepseek-v4-pro',
      deepseekFastModel: 'deepseek-v4-flash',
      deepseekTimeoutMs: 90_000,
      deepseekStreamIdleTimeoutMs: 120_000,
      deepseekCircuitFailureThreshold: 5,
      deepseekCircuitOpenMs: 30_000,
      messageMaxRequestBytes: 8 * 1024 * 1024,
      messageMaxConcurrency: 80,
      messageQueueLimit: 40,
      messageQueueTimeoutMs: 3_000,
      glmJsonMaxRequestBytes: 20 * 1024 * 1024,
      glmFileParseMaxBytes: 20 * 1024 * 1024,
      glmImageMaxBytes: 8 * 1024 * 1024,
      glmRequestTimeoutMs: 120_000,
      glmCircuitFailureThreshold: 5,
      glmCircuitOpenMs: 30_000,
      glmMaxConcurrency: 8,
      glmQueueLimit: 16,
      glmQueueTimeoutMs: 3_000,
      deviceRegisterRateLimitPerMinute: 20,
      orderCreateRateLimitPerMinute: 10,
      freeMessageRateLimitPerMinute: 6,
      lightMessageRateLimitPerMinute: 20,
      proMessageRateLimitPerMinute: 40,
      maxMessageRateLimitPerMinute: 60,
      freeAttachmentRateLimitPerMinute: 2,
      lightAttachmentRateLimitPerMinute: 4,
      proAttachmentRateLimitPerMinute: 8,
      maxAttachmentRateLimitPerMinute: 12,
      messageCreditCost: 1,
      attachmentCreditCost: 6,
      fileParseCreditCost: 3,
      summarizeCreditCost: 4,
      glmApiKey: '',
      glmBaseUrl: 'https://glm.example.com/api/paas/v4',
      wechatPay: disabledWechatPayConfig(),
      alipay: disabledAlipayConfig(),
      ...overrides,
    }
    const store = new GatewayStore(config)
    stores.push(store)
    return { config, store, handler: createGatewayHandler(config, store) }
  }
})

function jsonRequest(
  pathname: string,
  body: unknown,
  token?: string,
  extraHeaders: Record<string, string> = {},
): Request {
  return new Request(`http://localhost${pathname}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...extraHeaders,
    },
    body: JSON.stringify(body),
  })
}

function getRequest(pathname: string, token?: string): Request {
  return new Request(`http://localhost${pathname}`, {
    headers: {
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
  })
}

function createDeferred<T>(): {
  promise: Promise<T>
  resolve: (value: T) => void
  reject: (reason?: unknown) => void
} {
  let resolve!: (value: T) => void
  let reject!: (reason?: unknown) => void
  const promise = new Promise<T>((resolvePromise, rejectPromise) => {
    resolve = resolvePromise
    reject = rejectPromise
  })
  return { promise, resolve, reject }
}

async function waitFor(predicate: () => boolean, timeoutMs = 1000): Promise<void> {
  const startedAt = Date.now()
  while (Date.now() - startedAt < timeoutMs) {
    if (predicate()) return
    await new Promise((resolve) => setTimeout(resolve, 5))
  }
  throw new Error('Timed out waiting for condition')
}

function orderStatusRequest(orderId: string, orderToken?: string): Request {
  return new Request(`http://localhost/v1/orders/${encodeURIComponent(orderId)}/status`, {
    headers: {
      ...(orderToken ? { 'X-Gugu-Order-Token': orderToken } : {}),
    },
  })
}

function jsonResponse(body: unknown, init?: ResponseInit): Response {
  return new Response(JSON.stringify(body), {
    status: init?.status ?? 200,
    headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) },
  })
}

type WechatPayFixture = {
  config: GatewayConfig['wechatPay']
  wechatPrivateKey: KeyObject
}

async function makeWechatPayFixture(baseDir: string): Promise<WechatPayFixture> {
  const merchant = generateKeyPairSync('rsa', { modulusLength: 2048 })
  const wechat = generateKeyPairSync('rsa', { modulusLength: 2048 })
  const merchantPrivateKeyPath = path.join(baseDir, `merchant-${randomBytes(4).toString('hex')}.pem`)
  const wechatPublicKeyPath = path.join(baseDir, `wechat-${randomBytes(4).toString('hex')}.pem`)
  await fs.writeFile(
    merchantPrivateKeyPath,
    merchant.privateKey.export({ type: 'pkcs8', format: 'pem' }),
  )
  await fs.writeFile(
    wechatPublicKeyPath,
    wechat.publicKey.export({ type: 'spki', format: 'pem' }),
  )

  return {
    config: {
      enabled: true,
      appId: 'wx-app-id',
      mchId: '1900000001',
      merchantCertSerialNo: 'MERCHANT_SERIAL_NO',
      privateKeyPath: merchantPrivateKeyPath,
      wechatPayPublicKeyId: 'PUB_KEY_ID_TEST',
      wechatPayPublicKeyPath: wechatPublicKeyPath,
      apiV3Key: '12345678901234567890123456789012',
      notifyUrl: 'https://gugu.example.com/v1/payments/wechat/notify',
    },
    wechatPrivateKey: wechat.privateKey,
  }
}

function disabledWechatPayConfig(): GatewayConfig['wechatPay'] {
  return {
    enabled: false,
    appId: '',
    mchId: '',
    merchantCertSerialNo: '',
    privateKeyPath: '',
    wechatPayPublicKeyId: '',
    wechatPayPublicKeyPath: '',
    apiV3Key: '',
    notifyUrl: null,
  }
}

type AlipayFixture = {
  config: GatewayConfig['alipay']
  alipayPrivateKey: KeyObject
}

async function makeAlipayFixture(baseDir: string): Promise<AlipayFixture> {
  const merchant = generateKeyPairSync('rsa', { modulusLength: 2048 })
  const alipay = generateKeyPairSync('rsa', { modulusLength: 2048 })
  const merchantPrivateKeyPath = path.join(baseDir, `alipay-merchant-${randomBytes(4).toString('hex')}.pem`)
  const alipayPublicKeyPath = path.join(baseDir, `alipay-public-${randomBytes(4).toString('hex')}.pem`)
  await fs.writeFile(
    merchantPrivateKeyPath,
    merchant.privateKey.export({ type: 'pkcs8', format: 'pem' }),
  )
  await fs.writeFile(
    alipayPublicKeyPath,
    alipay.publicKey.export({ type: 'spki', format: 'pem' }),
  )

  return {
    config: {
      enabled: true,
      appId: '2021000000000000',
      privateKeyPath: merchantPrivateKeyPath,
      alipayPublicKeyPath,
      notifyUrl: 'https://gugu.example.com/v1/payments/alipay/notify',
      gatewayUrl: 'https://openapi.alipay.test/gateway.do',
      sellerId: '2088000000000000',
    },
    alipayPrivateKey: alipay.privateKey,
  }
}

function disabledAlipayConfig(): GatewayConfig['alipay'] {
  return {
    enabled: false,
    appId: '',
    privateKeyPath: '',
    alipayPublicKeyPath: '',
    notifyUrl: null,
    gatewayUrl: 'https://openapi.alipay.com/gateway.do',
    sellerId: '',
  }
}

function alipayNotifyRequest(
  fixture: AlipayFixture,
  input: {
    orderId: string
    transactionId: string
    amountCents: number
    tradeStatus?: 'TRADE_SUCCESS' | 'TRADE_FINISHED' | 'WAIT_BUYER_PAY'
    notificationId?: string
    tamperSignature?: boolean
  },
): Request {
  const params: Record<string, string> = {
    app_id: fixture.config.appId,
    seller_id: fixture.config.sellerId,
    notify_time: '2026-05-22 10:00:00',
    notify_type: 'trade_status_sync',
    notify_id: input.notificationId || `notify-${randomBytes(4).toString('hex')}`,
    out_trade_no: input.orderId,
    trade_no: input.transactionId,
    trade_status: input.tradeStatus || 'TRADE_SUCCESS',
    total_amount: formatTestAmountYuan(input.amountCents),
    gmt_payment: '2026-05-22 10:00:00',
    subject: 'Gugu Agent',
  }
  const signedPayload = canonicalizeAlipayNotifyParams(params)
  params.sign_type = 'RSA2'
  params.sign = signAlipayPayload(
    fixture.alipayPrivateKey,
    input.tamperSignature ? `${signedPayload}x` : signedPayload,
  )
  return new Request('http://localhost/v1/payments/alipay/notify', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
    body: new URLSearchParams(params).toString(),
  })
}

function canonicalizeAlipayNotifyParams(params: Record<string, string>): string {
  return Object.keys(params)
    .filter((key) => key !== 'sign' && key !== 'sign_type' && params[key] !== '')
    .sort()
    .map((key) => `${key}=${params[key]}`)
    .join('&')
}

function signAlipayPayload(privateKey: KeyObject, payload: string): string {
  return sign('RSA-SHA256', Buffer.from(payload), privateKey).toString('base64')
}

function formatTestAmountYuan(amountCents: number): string {
  return (amountCents / 100).toFixed(2)
}

function signedWechatResponse(fixture: WechatPayFixture, body: string, init?: ResponseInit): Response {
  const timestamp = '1779152400'
  const nonce = 'test-notify-nonce'
  const signature = signWechatPayload(fixture.wechatPrivateKey, `${timestamp}\n${nonce}\n${body}\n`)
  return new Response(body, {
    status: init?.status ?? 200,
    headers: {
      'Content-Type': 'application/json',
      'Wechatpay-Serial': fixture.config.wechatPayPublicKeyId,
      'Wechatpay-Signature': signature,
      'Wechatpay-Timestamp': timestamp,
      'Wechatpay-Nonce': nonce,
      ...(init?.headers ?? {}),
    },
  })
}

function wechatNotifyRequest(
  fixture: WechatPayFixture,
  input: {
    orderId: string
    transactionId: string
    amountCents: number
    notificationId?: string
    tamperSignature?: boolean
  },
): Request {
  const rawBody = JSON.stringify({
    id: input.notificationId || `notify-${randomBytes(4).toString('hex')}`,
    event_type: 'TRANSACTION.SUCCESS',
    resource_type: 'encrypt-resource',
    resource: encryptWechatResource(fixture, {
      out_trade_no: input.orderId,
      transaction_id: input.transactionId,
      trade_state: 'SUCCESS',
      success_time: '2026-05-21T10:00:00+08:00',
      amount: {
        total: input.amountCents,
        currency: 'CNY',
      },
    }),
  })
  const timestamp = '1779152400'
  const nonce = `nonce-${randomBytes(4).toString('hex')}`
  const signature = signWechatPayload(
    fixture.wechatPrivateKey,
    `${timestamp}\n${nonce}\n${input.tamperSignature ? `${rawBody}x` : rawBody}\n`,
  )
  return new Request('http://localhost/v1/payments/wechat/notify', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Wechatpay-Serial': fixture.config.wechatPayPublicKeyId,
      'Wechatpay-Signature': signature,
      'Wechatpay-Timestamp': timestamp,
      'Wechatpay-Nonce': nonce,
    },
    body: rawBody,
  })
}

function encryptWechatResource(
  fixture: WechatPayFixture,
  payload: Record<string, unknown>,
): Record<string, string> {
  const nonce = randomBytes(12).toString('hex').slice(0, 12)
  const associatedData = 'transaction'
  const cipher = createCipheriv(
    'aes-256-gcm',
    Buffer.from(fixture.config.apiV3Key, 'utf8'),
    Buffer.from(nonce, 'utf8'),
  )
  cipher.setAAD(Buffer.from(associatedData, 'utf8'))
  const encrypted = Buffer.concat([
    cipher.update(JSON.stringify(payload), 'utf8'),
    cipher.final(),
  ])
  return {
    algorithm: 'AEAD_AES_256_GCM',
    ciphertext: Buffer.concat([encrypted, cipher.getAuthTag()]).toString('base64'),
    associated_data: associatedData,
    nonce,
    original_type: 'transaction',
  }
}

function signWechatPayload(privateKey: KeyObject, payload: string): string {
  return sign('RSA-SHA256', Buffer.from(payload), privateKey).toString('base64')
}
