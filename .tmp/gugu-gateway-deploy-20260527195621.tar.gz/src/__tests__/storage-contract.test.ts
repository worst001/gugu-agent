import * as fs from 'node:fs/promises'
import * as os from 'node:os'
import * as path from 'node:path'
import { loadGatewayConfig } from '../config.js'
import { GatewayStore } from '../store.js'
import { registerGatewayStorageContract } from './storageContractSuite.js'

registerGatewayStorageContract('GatewayStore SQLite storage contract', async () => {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'gugu-storage-contract-'))
  const originalDbPath = process.env.GUGU_GATEWAY_DB_PATH
  const originalFreeCredits = process.env.GUGU_FREE_CREDITS
  process.env.GUGU_GATEWAY_DB_PATH = path.join(tmpDir, 'gateway.sqlite')
  process.env.GUGU_FREE_CREDITS = '5'

  return {
    storage: new GatewayStore(loadGatewayConfig()),
    async cleanup() {
      restoreEnv('GUGU_GATEWAY_DB_PATH', originalDbPath)
      restoreEnv('GUGU_FREE_CREDITS', originalFreeCredits)
      await fs.rm(tmpDir, { recursive: true, force: true })
    },
  }
})

function restoreEnv(name: string, value: string | undefined): void {
  if (value === undefined) delete process.env[name]
  else process.env[name] = value
}
