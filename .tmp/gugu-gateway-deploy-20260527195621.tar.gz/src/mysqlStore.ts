import { randomBytes, randomUUID } from 'node:crypto'
import mysql from 'mysql2/promise'
import type { Pool, PoolConnection, ResultSetHeader, RowDataPacket } from 'mysql2/promise'
import { getGatewayPackage, isPurchasablePackageId, packageExpiresAt } from './packages.js'
import {
  GatewayAuthError,
  GatewayQuotaError,
  getEntitlementMessage,
  type GatewayPaymentNotificationClaim,
  type GatewayStorage,
  type GatewayUsageReservation,
  type GatewayUsageTokens,
} from './store.js'
import type {
  GatewayConfig,
  GatewayDashboardSummary,
  GatewayDeviceResponse,
  GatewayDeviceSummary,
  GatewayEntitlement,
  GatewayListResponse,
  GatewayOrder,
  GatewayOrderStatus,
  GatewayOrderStatusResponse,
  GatewayPackageId,
  GatewayPaymentProvider,
  GatewayPlan,
  GatewayUsageEvent,
} from './types.js'

const REQUIRED_TABLES = [
  'devices',
  'activation_codes',
  'usage_events',
  'orders',
  'payment_notifications',
  'gateway_schema_migrations',
] as const

const REQUIRED_INDEXES = [
  { table: 'devices', key: 'uq_devices_device_token' },
  { table: 'orders', key: 'uq_orders_order_id' },
  { table: 'orders', key: 'uq_orders_wechat_transaction_id' },
  { table: 'orders', key: 'uq_orders_alipay_trade_no' },
  { table: 'payment_notifications', key: 'uq_payment_notifications_provider_notification' },
] as const

type DbClient = Pool | PoolConnection

type DeviceRow = RowDataPacket & {
  device_id: string
  device_token: string
  plan: GatewayPlan
  credits_total: number
  credits_remaining: number
  expires_at: string | Date | null
  license_key: string | null
  app_version: string | null
  platform: string | null
  created_at: string | Date
  updated_at: string | Date
  last_seen_at: string | Date
}

type ActivationCodeRow = RowDataPacket & {
  license_key: string
  plan: GatewayPlan
  credits_total: number
  expires_at: string | Date | null
  max_activations: number
  activations: number
  disabled_at: string | Date | null
  package_id: GatewayPackageId | null
  activation_kind: 'subscription' | 'topup' | 'trial'
}

type UsageEventRow = RowDataPacket & {
  id: number
  device_id: string
  kind: string
  model: string
  credits: number
  input_tokens: number | null
  output_tokens: number | null
  created_at: string | Date
  metadata: string | null
}

type OrderRow = RowDataPacket & {
  id: number
  order_id: string
  package_id: GatewayPackageId
  package_name: string
  package_kind: 'subscription' | 'topup' | 'trial'
  plan: GatewayPlan
  credits: number
  amount_cents: number
  currency: 'CNY'
  status: GatewayOrderStatus
  contact: string | null
  license_key: string | null
  order_token: string | null
  payment_provider: GatewayPaymentProvider | null
  payment_code_url: string | null
  payment_expires_at: string | Date | null
  wechat_transaction_id: string | null
  wechat_trade_state: string | null
  wechat_success_time: string | Date | null
  alipay_trade_no: string | null
  alipay_trade_status: string | null
  alipay_success_time: string | Date | null
  paid_amount_cents: number | null
  payment_payload: string | null
  created_at: string | Date
  updated_at: string | Date
  paid_at: string | Date | null
  fulfilled_at: string | Date | null
  cancelled_at: string | Date | null
}

type PaymentNotificationRow = RowDataPacket & {
  status: 'processing' | 'processed' | 'failed'
}

type ScalarRow = RowDataPacket & { value: number | string | null }

export type MysqlGatewaySchemaCheck = {
  ok: boolean
  version: string
  database: string
  missingTables: string[]
  missingIndexes: Array<{ table: string; key: string }>
}

export class MysqlGatewayStoreConfigError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'MysqlGatewayStoreConfigError'
  }
}

export class MysqlGatewayStore implements GatewayStorage {
  private readonly pool: Pool

  constructor(private readonly config: GatewayConfig) {
    if (!config.mysqlUrl) {
      throw new MysqlGatewayStoreConfigError('GUGU_MYSQL_URL is required when enabling MySQL storage.')
    }
    this.pool = mysql.createPool({
      uri: config.mysqlUrl,
      dateStrings: true,
      supportBigNumbers: true,
      bigNumberStrings: false,
      connectionLimit: 10,
    })
  }

  async close(): Promise<void> {
    await this.pool.end()
  }

  async ping(): Promise<void> {
    const connection = await this.pool.getConnection()
    try {
      await connection.ping()
    } finally {
      connection.release()
    }
  }

  async checkSchema(): Promise<MysqlGatewaySchemaCheck> {
    const versionRows = await this.query<ScalarRow & { database_name: string }>(
      this.pool,
      'SELECT VERSION() AS value, DATABASE() AS database_name',
    )
    const version = String(versionRows[0]?.value ?? '')
    const database = String(versionRows[0]?.database_name ?? '')
    const tableRows = await this.query<RowDataPacket & { table_name: string }>(
      this.pool,
      `SELECT TABLE_NAME AS table_name
       FROM information_schema.TABLES
       WHERE TABLE_SCHEMA = DATABASE()`,
    )
    const existingTables = new Set(tableRows.map((row) => String(row.table_name)))
    const missingTables = REQUIRED_TABLES.filter((table) => !existingTables.has(table))
    const missingIndexes: Array<{ table: string; key: string }> = []

    for (const index of REQUIRED_INDEXES) {
      if (!existingTables.has(index.table)) {
        missingIndexes.push(index)
        continue
      }
      const indexRows = await this.query<RowDataPacket>(
        this.pool,
        `SELECT INDEX_NAME AS index_name
         FROM information_schema.STATISTICS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = ?
           AND INDEX_NAME = ?
         LIMIT 1`,
        [index.table, index.key],
      )
      if (indexRows.length === 0) missingIndexes.push(index)
    }

    return {
      ok: missingTables.length === 0 && missingIndexes.length === 0,
      version,
      database,
      missingTables,
      missingIndexes,
    }
  }

  async registerDevice(input: {
    deviceId?: string
    appVersion?: string
    platform?: string
  }): Promise<GatewayDeviceResponse> {
    const now = nowIso()
    const requestedId = normalizeId(input.deviceId)
    const existing = requestedId ? await this.getDeviceById(requestedId) : null

    if (existing) {
      await this.execute(
        this.pool,
        'UPDATE devices SET last_seen_at = ?, updated_at = ? WHERE device_id = ?',
        [toMysqlDateTime(now), toMysqlDateTime(now), existing.device_id],
      )
      const row = await this.requireDeviceByToken(existing.device_token)
      return {
        deviceId: row.device_id,
        deviceToken: row.device_token,
        entitlement: this.toEntitlement(row),
      }
    }

    const deviceId = requestedId || randomUUID()
    const token = createDeviceToken()
    const trialExpiresAt = packageExpiresAt('trial', new Date(now))
    await this.execute(
      this.pool,
      `INSERT INTO devices (
        device_id, device_token, plan, credits_total, credits_remaining,
        expires_at, created_at, updated_at, last_seen_at, app_version, platform
      ) VALUES (?, ?, 'free', ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        deviceId,
        token,
        this.config.freeCredits,
        this.config.freeCredits,
        toMysqlDateTime(trialExpiresAt),
        toMysqlDateTime(now),
        toMysqlDateTime(now),
        toMysqlDateTime(now),
        input.appVersion || null,
        input.platform || null,
      ],
    )

    const row = await this.requireDeviceByToken(token)
    return {
      deviceId,
      deviceToken: token,
      entitlement: this.toEntitlement(row),
    }
  }

  async getEntitlement(deviceToken: string): Promise<GatewayEntitlement> {
    return this.toEntitlement(await this.requireDeviceByToken(deviceToken))
  }

  async activate(deviceToken: string, licenseKey: string): Promise<GatewayEntitlement> {
    const normalized = licenseKey.trim()
    if (!normalized) throw new Error('licenseKey is required')

    await this.withTransaction(async (connection) => {
      const device = await this.requireDeviceByToken(deviceToken, connection, true)
      const code = await this.queryOne<ActivationCodeRow>(
        connection,
        'SELECT * FROM activation_codes WHERE license_key = ? FOR UPDATE',
        [normalized],
      )
      if (!code || code.disabled_at) throw new Error('Activation code is invalid or disabled.')
      if (code.activations >= code.max_activations) throw new Error('Activation code has reached its activation limit.')
      const expiresAt = toIso(code.expires_at)
      if (expiresAt && Date.parse(expiresAt) < Date.now()) throw new Error('Activation code has expired.')

      const now = nowIso()
      const activationKind = code.activation_kind || 'subscription'
      if (activationKind === 'topup') {
        await this.execute(
          connection,
          `UPDATE devices
           SET credits_total = credits_total + ?,
               credits_remaining = credits_remaining + ?,
               license_key = ?,
               updated_at = ?,
               last_seen_at = ?
           WHERE device_token = ?`,
          [code.credits_total, code.credits_total, normalized, toMysqlDateTime(now), toMysqlDateTime(now), deviceToken],
        )
      } else {
        await this.execute(
          connection,
          `UPDATE devices
           SET plan = ?,
               credits_total = ?,
               credits_remaining = ?,
               expires_at = ?,
               license_key = ?,
               updated_at = ?,
               last_seen_at = ?
           WHERE device_token = ?`,
          [
            code.plan,
            code.credits_total,
            code.credits_total,
            toMysqlDateTime(expiresAt),
            normalized,
            toMysqlDateTime(now),
            toMysqlDateTime(now),
            deviceToken,
          ],
        )
      }
      await this.execute(
        connection,
        'UPDATE activation_codes SET activations = activations + 1 WHERE license_key = ?',
        [normalized],
      )
      await this.requireDeviceByToken(device.device_token, connection)
    })

    return this.getEntitlement(deviceToken)
  }

  async issueActivationCode(input: {
    licenseKey?: string
    plan: GatewayPlan
    creditsTotal: number
    expiresAt?: string | null
    maxActivations?: number
    packageId?: GatewayPackageId | null
    activationKind?: 'subscription' | 'topup' | 'trial'
  }): Promise<string> {
    const licenseKey = input.licenseKey?.trim() || `GUGU-${randomBytes(12).toString('hex').toUpperCase()}`
    const now = nowIso()
    await this.execute(
      this.pool,
      `INSERT INTO activation_codes (
        license_key, plan, credits_total, expires_at, max_activations,
        activations, created_at, package_id, activation_kind
      ) VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?)`,
      [
        licenseKey,
        input.plan,
        input.creditsTotal,
        toMysqlDateTime(input.expiresAt || null),
        input.maxActivations ?? 1,
        toMysqlDateTime(now),
        input.packageId || null,
        input.activationKind || 'subscription',
      ],
    )
    return licenseKey
  }

  async issueActivationCodeForPackage(packageId: GatewayPackageId, input: {
    licenseKey?: string
    expiresAt?: string | null
    maxActivations?: number
  } = {}): Promise<string> {
    const pkg = getGatewayPackage(packageId)
    if (!pkg) throw new Error(`Unknown package: ${packageId}`)
    return this.issueActivationCode({
      licenseKey: input.licenseKey,
      plan: pkg.plan,
      creditsTotal: pkg.credits,
      expiresAt: input.expiresAt ?? packageExpiresAt(pkg.id),
      maxActivations: input.maxActivations ?? pkg.maxActivations,
      packageId: pkg.id,
      activationKind: pkg.kind,
    })
  }

  async disableActivationCode(licenseKey: string): Promise<void> {
    await this.execute(
      this.pool,
      'UPDATE activation_codes SET disabled_at = ? WHERE license_key = ?',
      [toMysqlDateTime(nowIso()), licenseKey.trim()],
    )
  }

  async getDeviceSummary(input: { deviceToken?: string; deviceId?: string }): Promise<GatewayDeviceSummary | null> {
    const row = input.deviceToken
      ? await this.queryOne<DeviceRow>(this.pool, 'SELECT * FROM devices WHERE device_token = ?', [input.deviceToken.trim()])
      : input.deviceId
        ? await this.getDeviceById(input.deviceId)
        : null
    return row ? this.toDeviceSummary(row) : null
  }

  async listUsageEvents(input: {
    deviceToken?: string
    deviceId?: string
    limit?: number
    cursor?: number
  } = {}): Promise<GatewayUsageEvent[]> {
    const limit = normalizeLimit(input.limit)
    const deviceId = input.deviceToken
      ? (await this.requireDeviceByToken(input.deviceToken)).device_id
      : normalizeId(input.deviceId)
    const cursor = normalizeCursor(input.cursor)

    const rows = deviceId
      ? await this.query<UsageEventRow>(
        this.pool,
        `SELECT * FROM usage_events
         WHERE device_id = ?
         ${cursor ? 'AND id < ?' : ''}
         ORDER BY id DESC
         LIMIT ?`,
        cursor ? [deviceId, cursor, limit] : [deviceId, limit],
      )
      : await this.query<UsageEventRow>(
        this.pool,
        `SELECT * FROM usage_events
         ${cursor ? 'WHERE id < ?' : ''}
         ORDER BY id DESC
         LIMIT ?`,
        cursor ? [cursor, limit] : [limit],
      )
    return rows.map(toUsageEvent)
  }

  async listDevices(input: {
    plan?: GatewayPlan | ''
    status?: GatewayEntitlement['status'] | ''
    q?: string
    limit?: number
    cursor?: number
  } = {}): Promise<GatewayListResponse<GatewayDeviceSummary>> {
    const limit = normalizeLimit(input.limit)
    const filters: string[] = []
    const values: unknown[] = []

    if (input.plan) {
      filters.push('plan = ?')
      values.push(input.plan)
    }
    if (input.q?.trim()) {
      filters.push('(device_id LIKE ? OR app_version LIKE ? OR platform LIKE ? OR license_key LIKE ?)')
      const q = `%${input.q.trim()}%`
      values.push(q, q, q, q)
    }

    const rows = await this.query<DeviceRow>(
      this.pool,
      `SELECT * FROM devices
       ${filters.length ? `WHERE ${filters.join(' AND ')}` : ''}
       ORDER BY created_at DESC, device_id DESC
       LIMIT ?`,
      [...values, limit],
    )
    const data = rows
      .map((row) => this.toDeviceSummary(row))
      .filter((device) => !input.status || device.entitlement.status === input.status)

    return {
      data,
      pagination: {
        limit,
        nextCursor: null,
      },
    }
  }

  async createOrder(input: { packageId: string; contact?: string | null }): Promise<GatewayOrder> {
    const pkg = getGatewayPackage(input.packageId)
    if (!pkg || !isPurchasablePackageId(pkg.id)) throw new Error('Package is not available for purchase.')

    const now = nowIso()
    const orderId = createOrderId()
    const orderToken = createOrderToken()
    await this.execute(
      this.pool,
      `INSERT INTO orders (
        order_id, package_id, package_name, package_kind, plan, credits,
        amount_cents, currency, status, contact, order_token, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending_payment', ?, ?, ?, ?)`,
      [
        orderId,
        pkg.id,
        pkg.name,
        pkg.kind,
        pkg.plan,
        pkg.credits,
        pkg.amountCents,
        pkg.currency,
        normalizeContact(input.contact),
        orderToken,
        toMysqlDateTime(now),
        toMysqlDateTime(now),
      ],
    )
    return toOrder(await this.requireOrder(orderId))
  }

  async getOrderToken(orderId: string): Promise<string> {
    const order = await this.requireOrder(orderId)
    if (!order.order_token) throw new Error('Order token is not available.')
    return order.order_token
  }

  async listOrders(input: {
    status?: GatewayOrderStatus | ''
    q?: string
    limit?: number
    cursor?: number
  } = {}): Promise<GatewayListResponse<GatewayOrder>> {
    const limit = normalizeLimit(input.limit)
    const cursor = normalizeCursor(input.cursor)
    const filters: string[] = []
    const values: unknown[] = []

    if (cursor) {
      filters.push('id < ?')
      values.push(cursor)
    }
    if (input.status) {
      filters.push('status = ?')
      values.push(input.status)
    }
    const q = normalizeSearch(input.q)
    if (q) {
      filters.push('(order_id LIKE ? OR contact LIKE ? OR license_key LIKE ? OR package_name LIKE ?)')
      const like = `%${q}%`
      values.push(like, like, like, like)
    }

    const rows = await this.query<OrderRow>(
      this.pool,
      `SELECT * FROM orders
       ${filters.length ? `WHERE ${filters.join(' AND ')}` : ''}
       ORDER BY id DESC
       LIMIT ?`,
      [...values, limit],
    )

    return {
      data: rows.map(toOrder),
      pagination: {
        limit,
        nextCursor: rows.length === limit ? rows[rows.length - 1].id : null,
      },
    }
  }

  async attachOrderPayment(orderId: string, input: {
    provider: GatewayPaymentProvider
    codeUrl: string
    expiresAt: string
    payload?: Record<string, unknown> | null
  }): Promise<GatewayOrder> {
    const order = await this.requireOrder(orderId)
    if (order.status !== 'pending_payment') return toOrder(order)

    const now = nowIso()
    await this.execute(
      this.pool,
      `UPDATE orders
       SET payment_provider = ?,
           payment_code_url = ?,
           payment_expires_at = ?,
           payment_payload = ?,
           updated_at = ?
       WHERE order_id = ?`,
      [
        input.provider,
        input.codeUrl,
        toMysqlDateTime(input.expiresAt),
        stringifyPaymentPayload(input.payload ?? undefined),
        toMysqlDateTime(now),
        order.order_id,
      ],
    )
    return toOrder(await this.requireOrder(order.order_id))
  }

  async getOrderStatus(orderId: string, orderToken: string | null | undefined): Promise<GatewayOrderStatusResponse> {
    const row = await this.requireOrder(orderId)
    if (!row.order_token || row.order_token !== orderToken?.trim()) {
      throw new GatewayAuthError('Invalid order token.')
    }
    const order = toOrder(row)
    return {
      order,
      licenseKey: order.status === 'fulfilled' ? order.licenseKey : null,
    }
  }

  async beginPaymentNotification(input: {
    provider: GatewayPaymentProvider
    notificationId?: string | null
    transactionId?: string | null
    orderId?: string | null
    payload?: Record<string, unknown> | null
  }): Promise<GatewayPaymentNotificationClaim> {
    const notificationId = normalizePaymentNotificationId(input.notificationId || input.transactionId)
    const now = nowIso()
    const existing = await this.queryOne<PaymentNotificationRow>(
      this.pool,
      'SELECT status FROM payment_notifications WHERE provider = ? AND notification_id = ?',
      [input.provider, notificationId],
    )

    if (existing?.status === 'processed') return { notificationId, alreadyProcessed: true }

    const transactionId = normalizeTransactionId(input.transactionId || '')
    const orderId = normalizeOrderId(input.orderId)
    const payload = stringifyPaymentPayload(input.payload ?? undefined)
    if (existing) {
      await this.execute(
        this.pool,
        `UPDATE payment_notifications
         SET transaction_id = COALESCE(?, transaction_id),
             order_id = COALESCE(?, order_id),
             status = 'processing',
             error_message = NULL,
             payload = COALESCE(?, payload),
             updated_at = ?
         WHERE provider = ? AND notification_id = ?`,
        [transactionId, orderId, payload, toMysqlDateTime(now), input.provider, notificationId],
      )
      return { notificationId, alreadyProcessed: false }
    }

    await this.execute(
      this.pool,
      `INSERT INTO payment_notifications (
        provider, notification_id, transaction_id, order_id, status,
        payload, created_at, updated_at
      ) VALUES (?, ?, ?, ?, 'processing', ?, ?, ?)`,
      [
        input.provider,
        notificationId,
        transactionId,
        orderId,
        payload,
        toMysqlDateTime(now),
        toMysqlDateTime(now),
      ],
    )
    return { notificationId, alreadyProcessed: false }
  }

  async markPaymentNotificationProcessed(
    provider: GatewayPaymentProvider,
    notificationId: string,
  ): Promise<void> {
    const now = nowIso()
    await this.execute(
      this.pool,
      `UPDATE payment_notifications
       SET status = 'processed',
           error_message = NULL,
           processed_at = COALESCE(processed_at, ?),
           updated_at = ?
       WHERE provider = ? AND notification_id = ?`,
      [toMysqlDateTime(now), toMysqlDateTime(now), provider, notificationId],
    )
  }

  async markPaymentNotificationFailed(
    provider: GatewayPaymentProvider,
    notificationId: string,
    message: string,
  ): Promise<void> {
    await this.execute(
      this.pool,
      `UPDATE payment_notifications
       SET status = 'failed',
           error_message = ?,
           updated_at = ?
       WHERE provider = ? AND notification_id = ?`,
      [message.slice(0, 500), toMysqlDateTime(nowIso()), provider, notificationId],
    )
  }

  async getPaymentNotificationStatus(
    provider: GatewayPaymentProvider,
    notificationId: string,
  ): Promise<string | null> {
    const normalized = normalizePaymentNotificationId(notificationId)
    const row = await this.queryOne<RowDataPacket & { status: string }>(
      this.pool,
      'SELECT status FROM payment_notifications WHERE provider = ? AND notification_id = ?',
      [provider, normalized],
    )
    return row?.status ?? null
  }

  async completeWechatPayment(input: {
    orderId: string
    notificationId?: string | null
    transactionId: string
    tradeState: string
    successTime: string | null
    amountCents: number
    payload: Record<string, unknown>
  }): Promise<GatewayOrder> {
    return this.completeProviderPayment('wechat', input)
  }

  async completeAlipayPayment(input: {
    orderId: string
    notificationId?: string | null
    transactionId: string
    tradeState: string
    successTime: string | null
    amountCents: number
    payload: Record<string, unknown>
  }): Promise<GatewayOrder> {
    return this.completeProviderPayment('alipay', input)
  }

  async markOrderPaid(orderId: string): Promise<GatewayOrder> {
    const order = await this.requireOrder(orderId)
    if (order.status === 'cancelled') throw new Error('Order has been cancelled.')
    if (order.status === 'fulfilled') return toOrder(order)
    if (order.status === 'paid') return toOrder(order)

    const now = nowIso()
    await this.execute(
      this.pool,
      `UPDATE orders
       SET status = 'paid',
           paid_at = COALESCE(paid_at, ?),
           updated_at = ?
       WHERE order_id = ?`,
      [toMysqlDateTime(now), toMysqlDateTime(now), order.order_id],
    )
    return toOrder(await this.requireOrder(order.order_id))
  }

  async fulfillOrder(orderId: string): Promise<GatewayOrder> {
    return this.withTransaction((connection) => this.fulfillOrderInTransaction(connection, orderId))
  }

  async cancelOrder(orderId: string): Promise<GatewayOrder> {
    const order = await this.requireOrder(orderId)
    if (order.status === 'fulfilled') throw new Error('Fulfilled orders cannot be cancelled.')
    if (order.status === 'cancelled') return toOrder(order)

    const now = nowIso()
    await this.execute(
      this.pool,
      `UPDATE orders
       SET status = 'cancelled',
           cancelled_at = COALESCE(cancelled_at, ?),
           updated_at = ?
       WHERE order_id = ?`,
      [toMysqlDateTime(now), toMysqlDateTime(now), order.order_id],
    )
    return toOrder(await this.requireOrder(order.order_id))
  }

  async getDashboardSummary(range: '7d' | '30d' | 'all' = '7d'): Promise<GatewayDashboardSummary> {
    const since = rangeToSince(range)
    const sinceValue = since ? toMysqlDateTime(since) : null
    const rangeFilter = since ? 'WHERE created_at >= ?' : ''
    const rangeValues = sinceValue ? [sinceValue] : []
    const generatedAt = nowIso()
    const devicesTotal = await this.scalar('SELECT COUNT(*) AS value FROM devices')
    const active7d = await this.scalar('SELECT COUNT(*) AS value FROM devices WHERE last_seen_at >= ?', [toMysqlDateTime(daysAgo(7))])
    const active30d = await this.scalar('SELECT COUNT(*) AS value FROM devices WHERE last_seen_at >= ?', [toMysqlDateTime(daysAgo(30))])
    const creditRow = await this.queryOne<RowDataPacket & { total: number; remaining: number }>(
      this.pool,
      'SELECT COALESCE(SUM(credits_total), 0) AS total, COALESCE(SUM(credits_remaining), 0) AS remaining FROM devices',
    ) ?? { total: 0, remaining: 0 } as RowDataPacket & { total: number; remaining: number }
    const usageRow = await this.queryOne<RowDataPacket & {
      events: number
      credits: number
      inputTokens: number
      outputTokens: number
    }>(
      this.pool,
      `SELECT COUNT(*) AS events,
              COALESCE(SUM(credits), 0) AS credits,
              COALESCE(SUM(input_tokens), 0) AS inputTokens,
              COALESCE(SUM(output_tokens), 0) AS outputTokens
       FROM usage_events ${rangeFilter}`,
      rangeValues,
    ) ?? { events: 0, credits: 0, inputTokens: 0, outputTokens: 0 } as RowDataPacket & {
      events: number
      credits: number
      inputTokens: number
      outputTokens: number
    }

    const byPlan = await this.query<RowDataPacket & { plan: GatewayPlan; count: number }>(
      this.pool,
      'SELECT plan, COUNT(*) AS count FROM devices GROUP BY plan ORDER BY count DESC',
    )
    const byKind = await this.query<RowDataPacket & {
      kind: string
      events: number
      credits: number
      inputTokens: number
      outputTokens: number
    }>(
      this.pool,
      `SELECT kind,
              COUNT(*) AS events,
              COALESCE(SUM(credits), 0) AS credits,
              COALESCE(SUM(input_tokens), 0) AS inputTokens,
              COALESCE(SUM(output_tokens), 0) AS outputTokens
       FROM usage_events ${rangeFilter}
       GROUP BY kind
       ORDER BY credits DESC`,
      rangeValues,
    )
    const byModel = await this.query<RowDataPacket & {
      model: string
      events: number
      credits: number
      inputTokens: number
      outputTokens: number
    }>(
      this.pool,
      `SELECT model,
              COUNT(*) AS events,
              COALESCE(SUM(credits), 0) AS credits,
              COALESCE(SUM(input_tokens), 0) AS inputTokens,
              COALESCE(SUM(output_tokens), 0) AS outputTokens
       FROM usage_events ${rangeFilter}
       GROUP BY model
       ORDER BY credits DESC
       LIMIT 20`,
      rangeValues,
    )
    const daily = await this.query<RowDataPacket & {
      date: string
      events: number
      credits: number
      inputTokens: number
      outputTokens: number
    }>(
      this.pool,
      `SELECT DATE_FORMAT(created_at, '%Y-%m-%d') AS date,
              COUNT(*) AS events,
              COALESCE(SUM(credits), 0) AS credits,
              COALESCE(SUM(input_tokens), 0) AS inputTokens,
              COALESCE(SUM(output_tokens), 0) AS outputTokens
       FROM usage_events ${rangeFilter}
       GROUP BY date
       ORDER BY date DESC
       LIMIT 30`,
      rangeValues,
    )
    const topDevices = await this.query<RowDataPacket & {
      deviceId: string
      plan: GatewayPlan
      credits: number
      inputTokens: number
      outputTokens: number
      lastSeenAt: string | Date
    }>(
      this.pool,
      `SELECT d.device_id AS deviceId,
              d.plan AS plan,
              d.last_seen_at AS lastSeenAt,
              COALESCE(SUM(u.credits), 0) AS credits,
              COALESCE(SUM(u.input_tokens), 0) AS inputTokens,
              COALESCE(SUM(u.output_tokens), 0) AS outputTokens
       FROM usage_events u
       JOIN devices d ON d.device_id = u.device_id
       ${since ? 'WHERE u.created_at >= ?' : ''}
       GROUP BY d.device_id, d.plan, d.last_seen_at
       ORDER BY credits DESC
       LIMIT 10`,
      rangeValues,
    )
    const recentOrders = (await this.listOrders({ limit: 10 })).data

    return {
      range,
      generatedAt,
      devices: {
        total: devicesTotal,
        active7d,
        active30d,
        byPlan: byPlan.map((row) => ({ plan: row.plan, count: Number(row.count || 0) })),
      },
      credits: {
        total: Number(creditRow.total || 0),
        remaining: Number(creditRow.remaining || 0),
        used: Math.max(0, Number(creditRow.total || 0) - Number(creditRow.remaining || 0)),
        estimatedRemainingTokens: this.config.dashboardTokenPerCredit
          ? Number(creditRow.remaining || 0) * this.config.dashboardTokenPerCredit
          : null,
      },
      usage: {
        events: Number(usageRow.events || 0),
        credits: Number(usageRow.credits || 0),
        inputTokens: Number(usageRow.inputTokens || 0),
        outputTokens: Number(usageRow.outputTokens || 0),
        byKind: byKind.map(toAggregateRow),
        byModel: byModel.map(toAggregateRow),
        daily: daily.map((row) => ({
          date: row.date,
          events: Number(row.events || 0),
          credits: Number(row.credits || 0),
          inputTokens: Number(row.inputTokens || 0),
          outputTokens: Number(row.outputTokens || 0),
        })),
        topDevices: topDevices.map((row) => ({
          deviceId: row.deviceId,
          plan: row.plan,
          credits: Number(row.credits || 0),
          inputTokens: Number(row.inputTokens || 0),
          outputTokens: Number(row.outputTokens || 0),
          lastSeenAt: toIsoRequired(row.lastSeenAt),
        })),
      },
      orders: {
        pending: await this.countOrdersByStatus('pending_payment'),
        paid: await this.countOrdersByStatus('paid'),
        fulfilled: await this.countOrdersByStatus('fulfilled'),
        cancelled: await this.countOrdersByStatus('cancelled'),
        recent: recentOrders,
      },
    }
  }

  async setDeviceCredits(deviceToken: string, creditsRemaining: number, creditsTotal?: number): Promise<GatewayEntitlement> {
    const now = nowIso()
    if (creditsTotal === undefined) {
      await this.execute(
        this.pool,
        'UPDATE devices SET credits_remaining = ?, updated_at = ? WHERE device_token = ?',
        [creditsRemaining, toMysqlDateTime(now), deviceToken],
      )
    } else {
      await this.execute(
        this.pool,
        'UPDATE devices SET credits_remaining = ?, credits_total = ?, updated_at = ? WHERE device_token = ?',
        [creditsRemaining, creditsTotal, toMysqlDateTime(now), deviceToken],
      )
    }
    return this.getEntitlement(deviceToken)
  }

  async setDeviceCreditsByDeviceId(deviceId: string, creditsRemaining: number, creditsTotal?: number): Promise<GatewayEntitlement> {
    const device = await this.getDeviceById(deviceId)
    if (!device) throw new GatewayAuthError('Device id is invalid.')
    return this.setDeviceCredits(device.device_token, creditsRemaining, creditsTotal)
  }

  async consumeCredit(
    deviceToken: string,
    kind: string,
    model: string,
    credits = 1,
  ): Promise<GatewayEntitlement> {
    return (await this.consumeUsage(deviceToken, kind, model, credits)).entitlement
  }

  async consumeUsage(
    deviceToken: string,
    kind: string,
    model: string,
    credits = 1,
    metadata?: Record<string, unknown>,
  ): Promise<GatewayUsageReservation> {
    return this.withTransaction(async (connection) => {
      const now = nowIso()
      const creditCost = normalizeCreditCost(credits)
      const device = await this.requireDeviceByToken(deviceToken, connection, true)
      const entitlement = this.toEntitlement(device)
      if (entitlement.status !== 'active') throw new GatewayQuotaError(entitlement.message, entitlement)

      const result = await this.execute(
        connection,
        `UPDATE devices
         SET credits_remaining = credits_remaining - ?,
             updated_at = ?,
             last_seen_at = ?
         WHERE device_token = ? AND credits_remaining >= ?`,
        [creditCost, toMysqlDateTime(now), toMysqlDateTime(now), deviceToken, creditCost],
      )

      if (result.affectedRows !== 1) {
        const exhausted = this.toEntitlement(await this.requireDeviceByToken(deviceToken, connection, true))
        throw new GatewayQuotaError(exhausted.message, exhausted)
      }

      const event = await this.execute(
        connection,
        `INSERT INTO usage_events (
          device_id, kind, model, credits, created_at, metadata
        ) VALUES (?, ?, ?, ?, ?, ?)`,
        [
          device.device_id,
          kind,
          model,
          creditCost,
          toMysqlDateTime(now),
          metadata ? JSON.stringify(metadata) : null,
        ],
      )

      return {
        entitlement: this.toEntitlement(await this.requireDeviceByToken(deviceToken, connection, true)),
        usageEventId: event.insertId,
        credits: creditCost,
      }
    })
  }

  async recordUsageTokens(
    usageEventId: number,
    tokens: GatewayUsageTokens,
    metadata?: Record<string, unknown>,
  ): Promise<void> {
    const event = await this.queryOne<UsageEventRow>(this.pool, 'SELECT * FROM usage_events WHERE id = ?', [usageEventId])
    if (!event) return

    const inputTokens = normalizeNullableToken(tokens.inputTokens)
    const outputTokens = normalizeNullableToken(tokens.outputTokens)
    const mergedMetadata = {
      ...parseMetadata(event.metadata),
      ...(metadata ?? {}),
    }

    await this.execute(
      this.pool,
      `UPDATE usage_events
       SET input_tokens = COALESCE(?, input_tokens),
           output_tokens = COALESCE(?, output_tokens),
           metadata = ?
       WHERE id = ?`,
      [
        inputTokens,
        outputTokens,
        Object.keys(mergedMetadata).length ? JSON.stringify(mergedMetadata) : null,
        usageEventId,
      ],
    )
  }

  async refundCredit(deviceToken: string, credits = 1): Promise<GatewayEntitlement> {
    const now = nowIso()
    const creditCost = normalizeCreditCost(credits)
    await this.execute(
      this.pool,
      `UPDATE devices
       SET credits_remaining = LEAST(credits_total, credits_remaining + ?),
           updated_at = ?
       WHERE device_token = ?`,
      [creditCost, toMysqlDateTime(now), deviceToken],
    )
    return this.getEntitlement(deviceToken)
  }

  private async completeProviderPayment(
    provider: GatewayPaymentProvider,
    input: {
      orderId: string
      transactionId: string
      tradeState: string
      successTime: string | null
      amountCents: number
      payload: Record<string, unknown>
    },
  ): Promise<GatewayOrder> {
    return this.withTransaction(async (connection) => {
      const order = await this.requireOrder(input.orderId, connection, true)
      if (order.status === 'cancelled') throw new Error('Order has been cancelled.')
      if (provider === 'wechat' && input.tradeState !== 'SUCCESS') {
        throw new Error(`Unsupported WeChat trade state: ${input.tradeState}`)
      }
      if (provider === 'alipay' && input.tradeState !== 'TRADE_SUCCESS' && input.tradeState !== 'TRADE_FINISHED') {
        throw new Error(`Unsupported Alipay trade status: ${input.tradeState}`)
      }
      if (order.amount_cents !== input.amountCents) {
        throw new Error(`${provider === 'wechat' ? 'WeChat' : 'Alipay'} paid amount does not match the order amount.`)
      }

      const now = nowIso()
      const paidAt = input.successTime || now
      if (provider === 'wechat') {
        await this.execute(
          connection,
          `UPDATE orders
           SET status = CASE WHEN status = 'fulfilled' THEN status ELSE 'paid' END,
               payment_provider = 'wechat',
               wechat_transaction_id = COALESCE(wechat_transaction_id, ?),
               wechat_trade_state = ?,
               wechat_success_time = COALESCE(wechat_success_time, ?),
               paid_amount_cents = COALESCE(paid_amount_cents, ?),
               payment_payload = ?,
               paid_at = COALESCE(paid_at, ?),
               updated_at = ?
           WHERE order_id = ?`,
          [
            normalizeTransactionId(input.transactionId),
            input.tradeState,
            toMysqlDateTime(input.successTime),
            input.amountCents,
            stringifyPaymentPayload(input.payload),
            toMysqlDateTime(paidAt),
            toMysqlDateTime(now),
            order.order_id,
          ],
        )
      } else {
        await this.execute(
          connection,
          `UPDATE orders
           SET status = CASE WHEN status = 'fulfilled' THEN status ELSE 'paid' END,
               payment_provider = 'alipay',
               alipay_trade_no = COALESCE(alipay_trade_no, ?),
               alipay_trade_status = ?,
               alipay_success_time = COALESCE(alipay_success_time, ?),
               paid_amount_cents = COALESCE(paid_amount_cents, ?),
               payment_payload = ?,
               paid_at = COALESCE(paid_at, ?),
               updated_at = ?
           WHERE order_id = ?`,
          [
            normalizeTransactionId(input.transactionId),
            input.tradeState,
            toMysqlDateTime(input.successTime),
            input.amountCents,
            stringifyPaymentPayload(input.payload),
            toMysqlDateTime(paidAt),
            toMysqlDateTime(now),
            order.order_id,
          ],
        )
      }

      const updated = await this.requireOrder(order.order_id, connection, true)
      if (updated.status === 'fulfilled') return toOrder(updated)
      return this.fulfillOrderInTransaction(connection, order.order_id)
    })
  }

  private async fulfillOrderInTransaction(connection: PoolConnection, orderId: string): Promise<GatewayOrder> {
    const order = await this.requireOrder(orderId, connection, true)
    if (order.status === 'cancelled') throw new Error('Order has been cancelled.')
    if (order.status === 'fulfilled') return toOrder(order)

    const pkg = getGatewayPackage(order.package_id)
    if (!pkg) throw new Error(`Unknown package: ${order.package_id}`)

    const now = nowIso()
    const paidAt = toIso(order.paid_at) || now
    const licenseKey = order.license_key || await this.issueActivationCodeForPackageInTransaction(connection, pkg.id)
    await this.execute(
      connection,
      `UPDATE orders
       SET status = 'fulfilled',
           license_key = ?,
           paid_at = COALESCE(paid_at, ?),
           fulfilled_at = COALESCE(fulfilled_at, ?),
           updated_at = ?
       WHERE order_id = ?`,
      [licenseKey, toMysqlDateTime(paidAt), toMysqlDateTime(now), toMysqlDateTime(now), order.order_id],
    )
    return toOrder(await this.requireOrder(order.order_id, connection, true))
  }

  private async issueActivationCodeForPackageInTransaction(
    connection: PoolConnection,
    packageId: GatewayPackageId,
  ): Promise<string> {
    const pkg = getGatewayPackage(packageId)
    if (!pkg) throw new Error(`Unknown package: ${packageId}`)
    const licenseKey = `GUGU-${randomBytes(12).toString('hex').toUpperCase()}`
    const now = nowIso()
    await this.execute(
      connection,
      `INSERT INTO activation_codes (
        license_key, plan, credits_total, expires_at, max_activations,
        activations, created_at, package_id, activation_kind
      ) VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?)`,
      [
        licenseKey,
        pkg.plan,
        pkg.credits,
        toMysqlDateTime(packageExpiresAt(pkg.id)),
        pkg.maxActivations,
        toMysqlDateTime(now),
        pkg.id,
        pkg.kind,
      ],
    )
    return licenseKey
  }

  private async getDeviceById(deviceId: string, client: DbClient = this.pool): Promise<DeviceRow | null> {
    return this.queryOne<DeviceRow>(client, 'SELECT * FROM devices WHERE device_id = ?', [deviceId])
  }

  private async requireDeviceByToken(
    deviceToken: string,
    client: DbClient = this.pool,
    lock = false,
  ): Promise<DeviceRow> {
    const row = await this.queryOne<DeviceRow>(
      client,
      `SELECT * FROM devices WHERE device_token = ?${lock ? ' FOR UPDATE' : ''}`,
      [deviceToken.trim()],
    )
    if (!row) throw new GatewayAuthError('Device token is invalid. Restart Gugu Agent and try again.')
    return row
  }

  private async requireOrder(
    orderId: string,
    client: DbClient = this.pool,
    lock = false,
  ): Promise<OrderRow> {
    const normalized = orderId.trim()
    if (!normalized) throw new Error('orderId is required')
    const row = await this.queryOne<OrderRow>(
      client,
      `SELECT * FROM orders WHERE order_id = ?${lock ? ' FOR UPDATE' : ''}`,
      [normalized],
    )
    if (!row) throw new Error('Order not found.')
    return row
  }

  private toEntitlement(row: DeviceRow): GatewayEntitlement {
    const createdAt = toIsoRequired(row.created_at)
    const expiresAt = toIso(row.expires_at) || (row.plan === 'free' ? packageExpiresAt('trial', new Date(createdAt)) : null)
    const expired = Boolean(expiresAt && Date.parse(expiresAt) < Date.now())
    const exhausted = Number(row.credits_remaining) <= 0
    const status = expired
      ? 'expired'
      : exhausted
        ? 'quota_exhausted'
        : 'active'
    const reason = expired ? 'expired' : exhausted ? 'quota_exhausted' : undefined

    return {
      status,
      plan: row.plan,
      expiresAt,
      creditsTotal: Number(row.credits_total),
      creditsRemaining: Math.max(0, Number(row.credits_remaining)),
      isTrial: row.plan === 'free',
      purchaseUrl: this.config.purchaseUrl,
      message: getEntitlementMessage(status),
      ...(reason ? { reason } : {}),
    }
  }

  private toDeviceSummary(row: DeviceRow): GatewayDeviceSummary {
    return {
      deviceId: row.device_id,
      deviceToken: row.device_token,
      plan: row.plan,
      licenseKey: row.license_key,
      appVersion: row.app_version,
      platform: row.platform,
      createdAt: toIsoRequired(row.created_at),
      updatedAt: toIsoRequired(row.updated_at),
      lastSeenAt: toIsoRequired(row.last_seen_at),
      entitlement: this.toEntitlement(row),
    }
  }

  private async countOrdersByStatus(status: GatewayOrderStatus): Promise<number> {
    return this.scalar('SELECT COUNT(*) AS value FROM orders WHERE status = ?', [status])
  }

  private async scalar(sql: string, params: unknown[] = []): Promise<number> {
    const row = await this.queryOne<ScalarRow>(this.pool, sql, params)
    return Number(row?.value ?? 0)
  }

  private async query<T extends RowDataPacket>(
    client: DbClient,
    sql: string,
    params: unknown[] = [],
  ): Promise<T[]> {
    const [rows] = await client.query<T[]>(sql, params)
    return rows
  }

  private async queryOne<T extends RowDataPacket>(
    client: DbClient,
    sql: string,
    params: unknown[] = [],
  ): Promise<T | null> {
    const rows = await this.query<T>(client, sql, params)
    return rows[0] ?? null
  }

  private async execute(
    client: DbClient,
    sql: string,
    params: unknown[] = [],
  ): Promise<ResultSetHeader> {
    const [result] = await client.execute<ResultSetHeader>(sql, params)
    return result
  }

  private async withTransaction<T>(fn: (connection: PoolConnection) => Promise<T>): Promise<T> {
    const connection = await this.pool.getConnection()
    try {
      await connection.beginTransaction()
      const result = await fn(connection)
      await connection.commit()
      return result
    } catch (error) {
      await connection.rollback()
      throw error
    } finally {
      connection.release()
    }
  }
}

function normalizeCreditCost(credits: number): number {
  return Number.isFinite(credits) && credits > 0 ? Math.max(1, Math.trunc(credits)) : 1
}

function createDeviceToken(): string {
  return `gugu_${randomUUID()}_${randomBytes(16).toString('hex')}`
}

function normalizeId(value: string | undefined): string | null {
  const trimmed = value?.trim()
  if (!trimmed) return null
  return trimmed.length <= 128 ? trimmed : trimmed.slice(0, 128)
}

function normalizeLimit(value: number | undefined): number {
  if (typeof value !== 'number' || !Number.isFinite(value)) return 50
  return Math.min(500, Math.max(1, Math.trunc(value)))
}

function normalizeCursor(value: number | undefined): number | null {
  if (typeof value !== 'number' || !Number.isFinite(value) || value <= 0) return null
  return Math.trunc(value)
}

function normalizeContact(value: string | null | undefined): string | null {
  const trimmed = value?.trim()
  if (!trimmed) return null
  return trimmed.length <= 256 ? trimmed : trimmed.slice(0, 256)
}

function normalizeSearch(value: string | null | undefined): string | null {
  const trimmed = value?.trim()
  if (!trimmed) return null
  return trimmed.length <= 128 ? trimmed : trimmed.slice(0, 128)
}

function createOrderId(): string {
  const date = new Date()
  const ymd = [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, '0'),
    String(date.getDate()).padStart(2, '0'),
  ].join('')
  return `GUGU-${ymd}-${randomBytes(4).toString('hex').toUpperCase()}`
}

function createOrderToken(): string {
  return `ord_${randomBytes(24).toString('base64url')}`
}

function normalizeTransactionId(value: string): string | null {
  const trimmed = value.trim()
  if (!trimmed) return null
  return trimmed.length <= 64 ? trimmed : trimmed.slice(0, 64)
}

function normalizePaymentNotificationId(value: string | null | undefined): string {
  const trimmed = value?.trim()
  if (!trimmed) throw new Error('Payment notification id is required.')
  return trimmed.length <= 128 ? trimmed : trimmed.slice(0, 128)
}

function normalizeOrderId(value: string | null | undefined): string | null {
  const trimmed = value?.trim()
  if (!trimmed) return null
  return trimmed.length <= 64 ? trimmed : trimmed.slice(0, 64)
}

function stringifyPaymentPayload(value: Record<string, unknown> | undefined): string | null {
  if (!value) return null
  return JSON.stringify(value).slice(0, 4096)
}

function nowIso(): string {
  return new Date().toISOString()
}

function toMysqlDateTime(value: string | null | undefined): string | null {
  if (!value) return null
  const date = new Date(value)
  if (Number.isFinite(date.getTime())) {
    return date.toISOString().replace('T', ' ').replace('Z', '').slice(0, 23)
  }
  return value.replace('T', ' ').replace(/Z$/, '').slice(0, 23)
}

function toIso(value: string | Date | null | undefined): string | null {
  if (!value) return null
  if (value instanceof Date) return value.toISOString()
  const text = String(value).trim()
  if (!text) return null
  if (text.includes('T')) return text.endsWith('Z') ? text : `${text}Z`
  return `${text.replace(' ', 'T')}Z`
}

function toIsoRequired(value: string | Date): string {
  return toIso(value) || new Date(0).toISOString()
}

function rangeToSince(range: '7d' | '30d' | 'all'): string | null {
  if (range === '7d') return daysAgo(7)
  if (range === '30d') return daysAgo(30)
  return null
}

function daysAgo(days: number): string {
  const date = new Date()
  date.setDate(date.getDate() - days)
  return date.toISOString()
}

function normalizeNullableToken(value: number | null | undefined): number | null {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) return null
  return Math.trunc(value)
}

function parseMetadata(value: string | null): Record<string, unknown> {
  if (!value) return {}
  try {
    const parsed = JSON.parse(value)
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed)
      ? parsed as Record<string, unknown>
      : {}
  } catch {
    return {}
  }
}

function toUsageEvent(row: UsageEventRow): GatewayUsageEvent {
  return {
    id: Number(row.id),
    deviceId: row.device_id,
    kind: row.kind,
    model: row.model,
    credits: Number(row.credits),
    inputTokens: row.input_tokens === null ? null : Number(row.input_tokens),
    outputTokens: row.output_tokens === null ? null : Number(row.output_tokens),
    createdAt: toIsoRequired(row.created_at),
    metadata: row.metadata,
  }
}

function toOrder(row: OrderRow): GatewayOrder {
  return {
    id: Number(row.id),
    orderId: row.order_id,
    packageId: row.package_id,
    packageName: row.package_name,
    kind: row.package_kind,
    plan: row.plan,
    credits: Number(row.credits),
    amountCents: Number(row.amount_cents),
    currency: row.currency,
    status: row.status,
    contact: row.contact,
    licenseKey: row.license_key,
    createdAt: toIsoRequired(row.created_at),
    updatedAt: toIsoRequired(row.updated_at),
    paidAt: toIso(row.paid_at),
    fulfilledAt: toIso(row.fulfilled_at),
    cancelledAt: toIso(row.cancelled_at),
    paymentProvider: row.payment_provider,
    paymentCodeUrl: row.payment_code_url,
    paymentExpiresAt: toIso(row.payment_expires_at),
    wechatTransactionId: row.wechat_transaction_id,
    wechatTradeState: row.wechat_trade_state,
    wechatSuccessTime: toIso(row.wechat_success_time),
    alipayTradeNo: row.alipay_trade_no,
    alipayTradeStatus: row.alipay_trade_status,
    alipaySuccessTime: toIso(row.alipay_success_time),
    paidAmountCents: row.paid_amount_cents === null ? null : Number(row.paid_amount_cents),
    paymentPayload: row.payment_payload,
  }
}

function toAggregateRow(row: {
  kind?: string
  model?: string
  events: number
  credits: number
  inputTokens: number
  outputTokens: number
}): { kind: string; events: number; credits: number; inputTokens: number; outputTokens: number }
  | { model: string; events: number; credits: number; inputTokens: number; outputTokens: number } {
  const base = {
    events: Number(row.events || 0),
    credits: Number(row.credits || 0),
    inputTokens: Number(row.inputTokens || 0),
    outputTokens: Number(row.outputTokens || 0),
  }
  return row.model
    ? { model: row.model, ...base }
    : { kind: row.kind || '', ...base }
}
