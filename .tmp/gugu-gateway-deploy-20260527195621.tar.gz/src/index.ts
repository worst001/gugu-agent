import { createHash, randomUUID } from 'node:crypto'
import { loadGatewayConfig } from './config.js'
import { createBuyPageHtml, createCheckoutPageHtml } from './buyPage.js'
import { createDashboardPageHtml } from './dashboardPage.js'
import { createDownloadConfigResolver } from './downloadRelease.js'
import { createDownloadPageHtml, createHomePageHtml } from './sitePages.js'
import { isPurchasablePackageId } from './packages.js'
import {
  createAlipayPagePayment,
  isAlipayReady,
  parseAlipayPaymentNotify,
} from './alipayPay.js'
import {
  GatewayAuthError,
  GatewayQuotaError,
} from './store.js'
import type { GatewayStorage } from './store.js'
import { createGatewayStorage } from './storageFactory.js'
import {
  createWechatNativePayment,
  isWechatPayReady,
  parseWechatPaymentNotify,
} from './wechatPay.js'
import type {
  GatewayConfig,
  GatewayEntitlement,
  GatewayErrorBody,
  GatewayOrder,
  GatewayOrderStatusResponse,
  GatewayOrderStatus,
  GatewayPaymentProvider,
  GatewayPlan,
} from './types.js'

type JsonRecord = Record<string, unknown>

const JSON_HEADERS = { 'Content-Type': 'application/json' }
const HTML_HEADERS = {
  'Content-Type': 'text/html; charset=utf-8',
  'Cache-Control': 'no-store',
}
const TEXT_DECODER = new TextDecoder()
const SUPPORTED_GLM_IMAGE_MIME_TYPES = new Set([
  'image/jpeg',
  'image/jpg',
  'image/png',
])
const SUPPORTED_GLM_DOCUMENT_MIME_TYPES = new Set([
  'application/pdf',
  'application/msword',
  'application/vnd.ms-excel',
  'application/vnd.ms-powerpoint',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
])

class PayloadTooLargeError extends Error {
  constructor(
    readonly code: string,
    readonly requestBytes: number,
    readonly maxBytes: number,
    message: string,
  ) {
    super(message)
    this.name = 'PayloadTooLargeError'
  }
}

type QueueEntry = {
  start: () => void
  timeout: ReturnType<typeof setTimeout>
}

type TokenBucket = {
  tokens: number
  updatedAt: number
}

type RateLimitResult = {
  allowed: boolean
  retryAfterSeconds: number
  limitPerMinute: number
}

type QueueSnapshot = {
  label: string
  active: number
  waiting: number
  maxConcurrency: number
  queueLimit: number
  queueTimeoutMs: number
}

type CircuitCheck = {
  allowed: boolean
  retryAfterMs: number
}

type CircuitSnapshot = {
  label: string
  state: 'closed' | 'open' | 'half_open'
  consecutiveFailures: number
  retryAfterMs: number
  openedUntil: string | null
  halfOpenInFlight: boolean
  failureThreshold: number
  openMs: number
}

type GatewayRequestLog = {
  ts: string
  event: 'gateway_request'
  requestId: string
  method: string
  path: string
  status: number
  durationMs: number
  statusClass: string
  errorCode?: string
  retryAfter?: string
  contentLength?: number
  deviceHash?: string
  upstream?: string
  operation?: string
  model?: string
}

class GatewayRequestQueue {
  private active = 0
  private waiting: QueueEntry[] = []

  constructor(
    private readonly label: string,
    private readonly maxConcurrency: number,
    private readonly queueLimit: number,
    private readonly queueTimeoutMs: number,
  ) {}

  run(task: () => Promise<Response>): Promise<Response> {
    if (this.active < this.maxConcurrency) {
      return this.runNow(task)
    }

    if (this.queueLimit <= 0 || this.waiting.length >= this.queueLimit) {
      return Promise.resolve(this.busyResponse('queue is full'))
    }

    return new Promise<Response>((resolve, reject) => {
      let settled = false
      const entry: QueueEntry = {
        start: () => {
          if (settled) return
          settled = true
          clearTimeout(entry.timeout)
          this.runNow(task).then(resolve, reject)
        },
        timeout: setTimeout(() => {
          if (settled) return
          settled = true
          this.removeWaitingEntry(entry)
          resolve(this.busyResponse(`waited longer than ${this.queueTimeoutMs}ms`))
        }, this.queueTimeoutMs),
      }
      this.waiting.push(entry)
    })
  }

  private async runNow(task: () => Promise<Response>): Promise<Response> {
    this.active += 1
    try {
      return this.holdSlotUntilBodyCloses(await task())
    } catch (error) {
      this.release()
      throw error
    }
  }

  private holdSlotUntilBodyCloses(response: Response): Response {
    if (!response.body) {
      this.release()
      return response
    }

    const source = response.body
    const release = this.createReleaseOnce()
    let reader: ReadableStreamDefaultReader<Uint8Array> | null = null
    const body = new ReadableStream<Uint8Array>({
      start() {
        reader = source.getReader()
      },
      async pull(controller) {
        try {
          const next = await reader!.read()
          if (next.done) {
            release()
            controller.close()
            return
          }
          if (next.value) controller.enqueue(next.value)
        } catch (error) {
          release()
          controller.error(error)
        }
      },
      async cancel(reason) {
        release()
        await reader?.cancel(reason).catch(() => {})
      },
    })

    return new Response(body, {
      status: response.status,
      statusText: response.statusText,
      headers: response.headers,
    })
  }

  private createReleaseOnce(): () => void {
    let released = false
    return () => {
      if (released) return
      released = true
      this.release()
    }
  }

  private release(): void {
    this.active = Math.max(0, this.active - 1)
    this.drain()
  }

  private drain(): void {
    while (this.active < this.maxConcurrency && this.waiting.length > 0) {
      const entry = this.waiting.shift()
      entry?.start()
    }
  }

  private removeWaitingEntry(entry: QueueEntry): void {
    const index = this.waiting.indexOf(entry)
    if (index >= 0) this.waiting.splice(index, 1)
  }

  private busyResponse(reason: string): Response {
    const response = errorJson(
      429,
      'GATEWAY_BUSY',
      `${this.label} is busy (${reason}). Please retry shortly.`,
    )
    response.headers.set('Retry-After', String(Math.max(1, Math.ceil(this.queueTimeoutMs / 1000))))
    return response
  }

  snapshot(): QueueSnapshot {
    return {
      label: this.label,
      active: this.active,
      waiting: this.waiting.length,
      maxConcurrency: this.maxConcurrency,
      queueLimit: this.queueLimit,
      queueTimeoutMs: this.queueTimeoutMs,
    }
  }
}

class TokenBucketRateLimiter {
  private buckets = new Map<string, TokenBucket>()
  private operations = 0

  consume(key: string, limitPerMinute: number): RateLimitResult {
    if (limitPerMinute <= 0) {
      return { allowed: true, retryAfterSeconds: 0, limitPerMinute }
    }

    const now = Date.now()
    const capacity = Math.max(1, limitPerMinute)
    const refillPerMs = limitPerMinute / 60_000
    const bucket = this.buckets.get(key) ?? { tokens: capacity, updatedAt: now }
    const elapsedMs = Math.max(0, now - bucket.updatedAt)
    bucket.tokens = Math.min(capacity, bucket.tokens + elapsedMs * refillPerMs)
    bucket.updatedAt = now

    if (bucket.tokens >= 1) {
      bucket.tokens -= 1
      this.buckets.set(key, bucket)
      this.pruneOccasionally(now)
      return { allowed: true, retryAfterSeconds: 0, limitPerMinute }
    }

    this.buckets.set(key, bucket)
    this.pruneOccasionally(now)
    const retryAfterSeconds = Math.max(1, Math.ceil((1 - bucket.tokens) / refillPerMs / 1000))
    return { allowed: false, retryAfterSeconds, limitPerMinute }
  }

  private pruneOccasionally(now: number): void {
    this.operations += 1
    if (this.operations % 500 !== 0) return
    for (const [key, bucket] of this.buckets) {
      if (now - bucket.updatedAt > 10 * 60_000) {
        this.buckets.delete(key)
      }
    }
  }
}

class UpstreamCircuitBreaker {
  private consecutiveFailures = 0
  private openedUntil = 0
  private halfOpenInFlight = false

  constructor(
    private readonly label: string,
    private readonly failureThreshold: number,
    private readonly openMs: number,
  ) {}

  beforeRequest(): CircuitCheck {
    const now = Date.now()
    if (this.openedUntil > now) {
      return { allowed: false, retryAfterMs: this.openedUntil - now }
    }

    if (this.openedUntil > 0) {
      if (this.halfOpenInFlight) {
        return { allowed: false, retryAfterMs: Math.max(1_000, this.openMs) }
      }
      this.halfOpenInFlight = true
      return { allowed: true, retryAfterMs: 0 }
    }

    return { allowed: true, retryAfterMs: 0 }
  }

  recordSuccess(): void {
    this.consecutiveFailures = 0
    this.openedUntil = 0
    this.halfOpenInFlight = false
  }

  recordFailure(): void {
    this.halfOpenInFlight = false
    this.consecutiveFailures += 1
    if (this.consecutiveFailures >= this.failureThreshold) {
      this.openedUntil = Date.now() + this.openMs
      console.warn('[gugu-gateway] upstream circuit opened:', {
        upstream: this.label,
        failureThreshold: this.failureThreshold,
        openMs: this.openMs,
      })
    }
  }

  snapshot(): CircuitSnapshot {
    const now = Date.now()
    const isOpen = this.openedUntil > now
    const state = isOpen
      ? 'open'
      : this.openedUntil > 0 && this.halfOpenInFlight
        ? 'half_open'
        : 'closed'
    return {
      label: this.label,
      state,
      consecutiveFailures: this.consecutiveFailures,
      retryAfterMs: isOpen ? this.openedUntil - now : 0,
      openedUntil: isOpen ? new Date(this.openedUntil).toISOString() : null,
      halfOpenInFlight: this.halfOpenInFlight,
      failureThreshold: this.failureThreshold,
      openMs: this.openMs,
    }
  }
}

class GatewayMetrics {
  private readonly startedAt = new Date()
  private totalRequests = 0
  private statusCounts = new Map<string, number>()
  private errorCounts = new Map<string, number>()
  private recentRequests: GatewayRequestLog[] = []

  record(entry: GatewayRequestLog): void {
    this.totalRequests += 1
    this.increment(this.statusCounts, entry.statusClass)
    if (entry.errorCode) this.increment(this.errorCounts, entry.errorCode)
    this.recentRequests.push(entry)
    if (this.recentRequests.length > 50) {
      this.recentRequests.splice(0, this.recentRequests.length - 50)
    }
  }

  snapshot(options: {
    queues: Record<string, QueueSnapshot>
    circuits: Record<string, CircuitSnapshot>
  }): Record<string, unknown> {
    return {
      generatedAt: new Date().toISOString(),
      startedAt: this.startedAt.toISOString(),
      uptimeSeconds: Math.max(0, Math.floor((Date.now() - this.startedAt.getTime()) / 1000)),
      requests: {
        total: this.totalRequests,
        byStatusClass: Object.fromEntries(this.statusCounts),
        byErrorCode: Object.fromEntries(this.errorCounts),
        recent: [...this.recentRequests].reverse(),
      },
      queues: options.queues,
      circuits: options.circuits,
    }
  }

  private increment(map: Map<string, number>, key: string): void {
    map.set(key, (map.get(key) ?? 0) + 1)
  }
}

export function createGatewayHandler(config: GatewayConfig, store: GatewayStorage = createGatewayStorage(config)) {
  const resolveDownloadConfig = createDownloadConfigResolver(config)
  const rateLimiter = new TokenBucketRateLimiter()
  const metrics = new GatewayMetrics()
  const messageQueue = new GatewayRequestQueue(
    'Gugu Managed message gateway',
    config.messageMaxConcurrency,
    config.messageQueueLimit,
    config.messageQueueTimeoutMs,
  )
  const glmQueue = new GatewayRequestQueue(
    'GLM attachment gateway',
    config.glmMaxConcurrency,
    config.glmQueueLimit,
    config.glmQueueTimeoutMs,
  )
  const deepseekCircuit = new UpstreamCircuitBreaker(
    'deepseek',
    config.deepseekCircuitFailureThreshold,
    config.deepseekCircuitOpenMs,
  )
  const glmCircuit = new UpstreamCircuitBreaker(
    'glm',
    config.glmCircuitFailureThreshold,
    config.glmCircuitOpenMs,
  )

  async function routeGatewayRequest(req: Request): Promise<Response> {
    const url = new URL(req.url)

    if (req.method === 'OPTIONS' && url.pathname.startsWith('/admin/api/')) {
      return new Response(null, {
        status: 204,
        headers: {
          'Access-Control-Allow-Headers': 'authorization, content-type',
          'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        },
      })
    }

    if (req.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: corsHeaders() })
    }

    try {
      if (req.method === 'GET' && url.pathname === '/health') {
        return json({ ok: true })
      }

      if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '')) {
        return html(createHomePageHtml(await resolveDownloadConfig()))
      }

      if (req.method === 'GET' && (url.pathname === '/download' || url.pathname === '/download/')) {
        return html(createDownloadPageHtml(await resolveDownloadConfig()))
      }

      if (req.method === 'GET' && (url.pathname === '/buy' || url.pathname === '/buy/')) {
        return html(createBuyPageHtml({
          wechatPayEnabled: isWechatPayReady(config),
          alipayPayEnabled: isAlipayReady(config),
          icpRecord: config.icpRecord,
          icpUrl: config.icpUrl,
          maintenanceMode: config.maintenanceMode,
          maintenanceDisableOrders: config.maintenanceDisableOrders,
          maintenanceMessage: config.maintenanceMessage,
        }))
      }

      if (req.method === 'GET' && (url.pathname === '/checkout' || url.pathname === '/checkout/')) {
        return html(createCheckoutPageHtml({
          packageId: url.searchParams.get('packageId'),
          wechatPayEnabled: isWechatPayReady(config),
          alipayPayEnabled: isAlipayReady(config),
          icpRecord: config.icpRecord,
          icpUrl: config.icpUrl,
          maintenanceMode: config.maintenanceMode,
          maintenanceDisableOrders: config.maintenanceDisableOrders,
          maintenanceMessage: config.maintenanceMessage,
        }))
      }

      if (req.method === 'GET' && (url.pathname === '/admin/dashboard' || url.pathname === '/admin/dashboard/')) {
        if (!config.adminToken) return adminErrorJson(404, 'ADMIN_DISABLED', 'Admin dashboard is not enabled.')
        return html(createDashboardPageHtml())
      }

      if (req.method === 'POST' && url.pathname === '/v1/devices') {
        const limited = rateLimitIpRequest(
          req,
          rateLimiter,
          config.deviceRegisterRateLimitPerMinute,
          'Device registration',
          'device-register',
        )
        if (limited) return limited
        const body = await readJson(req)
        return json(await store.registerDevice({
          deviceId: asString(body.deviceId),
          appVersion: asString(body.appVersion),
          platform: asString(body.platform),
        }))
      }

      if (req.method === 'GET' && url.pathname === '/v1/entitlement') {
        return json(await store.getEntitlement(readDeviceToken(req)))
      }

      if (req.method === 'POST' && url.pathname === '/v1/activate') {
        const body = await readJson(req)
        const licenseKey = asString(body.licenseKey)
        if (!licenseKey) return errorJson(400, 'BAD_REQUEST', 'licenseKey is required')
        return json({ entitlement: await store.activate(readDeviceToken(req), licenseKey) })
      }

      if (req.method === 'POST' && url.pathname === '/v1/orders') {
        if (isOrderMaintenanceEnabled(config)) {
          return errorJson(503, 'MAINTENANCE', config.maintenanceMessage)
        }
        const limited = rateLimitIpRequest(
          req,
          rateLimiter,
          config.orderCreateRateLimitPerMinute,
          'Order creation',
          'order-create',
        )
        if (limited) return limited
        const body = await readJson(req)
        const packageId = asString(body.packageId)
        const paymentProvider = asString(body.paymentProvider)
        if (!packageId) return errorJson(400, 'BAD_REQUEST', 'packageId is required')
        if (!isPurchasablePackageId(packageId)) return errorJson(400, 'BAD_REQUEST', 'Package is not available for purchase.')
        if (paymentProvider && paymentProvider !== 'wechat' && paymentProvider !== 'alipay') {
          return errorJson(400, 'BAD_REQUEST', 'Unsupported payment provider.')
        }
        return await createOrderResponse(
          config,
          store,
          packageId,
          asString(body.contact),
          paymentProvider as GatewayPaymentProvider | undefined,
          asString(body.orderId),
          asString(body.orderToken),
        )
      }

      const orderStatus = url.pathname.match(/^\/v1\/orders\/([^/]+)\/status$/)
      if (req.method === 'GET' && orderStatus) {
        const orderId = decodeURIComponent(orderStatus[1]!)
        return json(await store.getOrderStatus(orderId, req.headers.get('x-gugu-order-token')))
      }

      if (req.method === 'POST' && url.pathname === '/v1/payments/wechat/notify') {
        return await handleWechatNotify(req, config, store)
      }

      if (req.method === 'POST' && url.pathname === '/v1/payments/alipay/notify') {
        return await handleAlipayNotify(req, config, store)
      }

      if (req.method === 'GET' && url.pathname === '/v1/payments/alipay/checkout') {
        return await handleAlipayCheckout(url, store)
      }

      if (req.method === 'POST' && url.pathname === '/v1/messages') {
        const limited = await rateLimitDeviceRequest(req, config, store, rateLimiter, 'message')
        if (limited) return limited
        return await messageQueue.run(() => forwardMessage(req, config, store, deepseekCircuit))
      }

      if (req.method === 'POST' && url.pathname === '/v1/attachments/parse') {
        const limited = await rateLimitDeviceRequest(req, config, store, rateLimiter, 'attachment')
        if (limited) return limited
        return await glmQueue.run(() => forwardAttachment(req, config, store, glmCircuit))
      }

      if (url.pathname.startsWith('/admin/api/')) {
        return await handleAdminApi(req, url, config, store, resolveDownloadConfig, {
          metrics,
          messageQueue,
          glmQueue,
          deepseekCircuit,
          glmCircuit,
        })
      }

      return errorJson(404, 'NOT_FOUND', `Unknown gateway endpoint: ${url.pathname}`)
    } catch (error) {
      return handleGatewayError(error)
    }
  }

  return async function handleGatewayRequest(req: Request): Promise<Response> {
    const startedAt = Date.now()
    const url = new URL(req.url)
    const requestId = readRequestId(req)
    const response = await routeGatewayRequest(req)
    return finalizeGatewayResponse(response, {
      requestId,
      method: req.method,
      path: url.pathname,
      startedAt,
      contentLength: readContentLength(req),
      deviceHash: readDeviceHash(req),
    }, metrics, config)
  }
}

export function startGateway(): void {
  const config = loadGatewayConfig()
  const port = Number.parseInt(process.env.GUGU_GATEWAY_PORT || '8787', 10)
  const host = process.env.GUGU_GATEWAY_HOST || '127.0.0.1'
  const fetch = createGatewayHandler(config)
  Bun.serve({ port, hostname: host, fetch })
  console.log(`[gugu-gateway] listening on http://${host}:${port}`)
}

async function createOrderResponse(
  config: GatewayConfig,
  store: GatewayStorage,
  packageId: string,
  contact?: string,
  paymentProvider: GatewayPaymentProvider = 'wechat',
  existingOrderId?: string,
  existingOrderToken?: string,
): Promise<Response> {
  const { order, orderToken } = await resolvePaymentOrder(store, packageId, contact, existingOrderId, existingOrderToken)
  if (paymentProvider === 'alipay') {
    return await createAlipayOrderResponse(config, store, order, orderToken)
  }
  return await createWechatOrderResponse(config, store, order, orderToken)
}

async function resolvePaymentOrder(
  store: GatewayStorage,
  packageId: string,
  contact?: string,
  existingOrderId?: string,
  existingOrderToken?: string,
): Promise<{ order: GatewayOrder; orderToken: string }> {
  if (!existingOrderId && !existingOrderToken) {
    const order = await store.createOrder({ packageId, contact })
    return { order, orderToken: await store.getOrderToken(order.orderId) }
  }
  if (!existingOrderId || !existingOrderToken) {
    throw new Error('Both orderId and orderToken are required to reuse an order.')
  }
  const status = await store.getOrderStatus(existingOrderId, existingOrderToken)
  if (status.order.packageId !== packageId) {
    throw new Error('Order package does not match the requested package.')
  }
  if (status.order.status !== 'pending_payment') {
    throw new Error('Only pending orders can switch payment methods.')
  }
  return { order: status.order, orderToken: existingOrderToken }
}

function isOrderMaintenanceEnabled(config: GatewayConfig): boolean {
  return config.maintenanceMode && config.maintenanceDisableOrders
}

async function createWechatOrderResponse(
  config: GatewayConfig,
  store: GatewayStorage,
  order: GatewayOrder,
  orderToken: string,
): Promise<Response> {
  if (!isWechatPayReady(config)) {
    return json({ order, orderToken, payment: null })
  }

  try {
    const payment = await createWechatNativePayment(config, order)
    const updatedOrder = await store.attachOrderPayment(order.orderId, {
      provider: payment.provider,
      codeUrl: payment.codeUrl,
      expiresAt: payment.expiresAt,
      payload: payment.payload,
    })
    return json({
      order: updatedOrder,
      orderToken,
      payment: {
        provider: payment.provider,
        codeUrl: payment.codeUrl,
        qrDataUrl: payment.qrDataUrl,
        expiresAt: payment.expiresAt,
      },
    })
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to create payment.'
    console.error('[gugu-gateway] WeChat payment creation failed; falling back to manual order:', error)
    return json({
      order,
      orderToken,
      payment: null,
      paymentError: message,
    })
  }
}

async function createAlipayOrderResponse(
  config: GatewayConfig,
  store: GatewayStorage,
  order: GatewayOrder,
  orderToken: string,
): Promise<Response> {
  if (!isAlipayReady(config)) {
    return json({ order, orderToken, payment: null })
  }

  try {
    const payment = await createAlipayPagePayment(config, order)
    const updatedOrder = await store.attachOrderPayment(order.orderId, {
      provider: payment.provider,
      codeUrl: payment.codeUrl,
      expiresAt: payment.expiresAt,
      payload: payment.payload,
    })
    return json({
      order: updatedOrder,
      orderToken,
      payment: {
        provider: payment.provider,
        codeUrl: payment.codeUrl,
        qrDataUrl: payment.qrDataUrl,
        expiresAt: payment.expiresAt,
      },
    })
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to create payment.'
    console.error('[gugu-gateway] Alipay payment creation failed; falling back to manual order:', error)
    return json({
      order,
      orderToken,
      payment: null,
      paymentError: message,
    })
  }
}

async function handleAlipayCheckout(
  url: URL,
  store: GatewayStorage,
): Promise<Response> {
  const orderId = url.searchParams.get('orderId')?.trim() || ''
  const orderToken = url.searchParams.get('orderToken')?.trim() || ''
  if (!orderId || !orderToken) {
    return html(alipayCheckoutMessageHtml('支付链接无效', '缺少订单信息，请回到结算页重新生成支付宝二维码。'), { status: 400 })
  }

  let status: GatewayOrderStatusResponse
  try {
    status = await store.getOrderStatus(orderId, orderToken)
  } catch {
    return html(alipayCheckoutMessageHtml('支付链接无效', '订单验证失败，请回到结算页重新生成支付宝二维码。'), { status: 400 })
  }
  const order = status.order
  if (order.status !== 'pending_payment') {
    return html(alipayCheckoutMessageHtml('订单状态已更新', '这笔订单已经不是待付款状态，请回到结算页查看最新结果。'), { status: 409 })
  }
  if (order.paymentProvider !== 'alipay') {
    return html(alipayCheckoutMessageHtml('支付方式已切换', '这笔订单当前不是支付宝支付，请回到结算页重新选择支付方式。'), { status: 409 })
  }

  const payload = parseJson(order.paymentPayload || '{}')
  const cashierUrl = typeof payload === 'object' && payload && 'cashierUrl' in payload
    ? asString((payload as { cashierUrl?: unknown }).cashierUrl)
    : undefined
  if (!cashierUrl) {
    return html(alipayCheckoutMessageHtml('支付宝收银台未生成', '请回到结算页重新生成支付宝二维码。'), { status: 409 })
  }

  return html(alipayCheckoutRedirectHtml(cashierUrl))
}

async function handleWechatNotify(
  req: Request,
  config: GatewayConfig,
  store: GatewayStorage,
): Promise<Response> {
  try {
    const rawBody = await req.text()
    const paidOrder = parseWechatPaymentNotify(config, req.headers, rawBody)
    const claim = await store.beginPaymentNotification({
      provider: 'wechat',
      notificationId: paidOrder.notificationId,
      transactionId: paidOrder.transactionId,
      orderId: paidOrder.orderId,
      payload: paidOrder.payload,
    })
    if (claim.alreadyProcessed) {
      return new Response(null, { status: 204 })
    }
    try {
      await store.completeWechatPayment(paidOrder)
      await store.markPaymentNotificationProcessed('wechat', claim.notificationId)
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      await store.markPaymentNotificationFailed('wechat', claim.notificationId, message)
      throw error
    }
    return new Response(null, { status: 204 })
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error)
    console.warn('[gugu-gateway] WeChat notify rejected:', message)
    return json({ code: 'FAIL', message }, { status: 400 })
  }
}

async function handleAlipayNotify(
  req: Request,
  config: GatewayConfig,
  store: GatewayStorage,
): Promise<Response> {
  try {
    const rawBody = await req.text()
    const paidOrder = parseAlipayPaymentNotify(config, rawBody)
    const claim = await store.beginPaymentNotification({
      provider: 'alipay',
      notificationId: paidOrder.notificationId,
      transactionId: paidOrder.transactionId,
      orderId: paidOrder.orderId,
      payload: paidOrder.payload,
    })
    if (claim.alreadyProcessed) {
      return new Response('success', {
        headers: { 'Content-Type': 'text/plain; charset=utf-8' },
      })
    }
    try {
      await store.completeAlipayPayment(paidOrder)
      await store.markPaymentNotificationProcessed('alipay', claim.notificationId)
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      await store.markPaymentNotificationFailed('alipay', claim.notificationId, message)
      throw error
    }
    return new Response('success', {
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
    })
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error)
    console.warn('[gugu-gateway] Alipay notify rejected:', message)
    return new Response('fail', {
      status: 400,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
    })
  }
}

async function forwardMessage(
  req: Request,
  config: GatewayConfig,
  store: GatewayStorage,
  circuit: UpstreamCircuitBreaker,
): Promise<Response> {
  if (!config.deepseekApiKey) {
    return errorJson(503, 'UPSTREAM_NOT_CONFIGURED', 'GUGU_DEEPSEEK_API_KEY is not configured')
  }

  const deviceToken = readDeviceToken(req)
  const body = await readJson(req)
  const entitlement = await store.getEntitlement(deviceToken)
  const upstreamModel = resolveDeepSeekModel(config, asString(body.model), entitlement.plan)
  const creditCost = config.messageCreditCost
  body.model = upstreamModel
  const upstreamBody = JSON.stringify(body)
  const requestBytes = new TextEncoder().encode(upstreamBody).byteLength
  if (requestBytes > config.messageMaxRequestBytes) {
    return errorJson(
      413,
      'PAYLOAD_TOO_LARGE',
      messageRequestTooLargeMessage(requestBytes, config.messageMaxRequestBytes),
      entitlement,
    )
  }

  const circuitCheck = circuit.beforeRequest()
  if (!circuitCheck.allowed) {
    return upstreamCircuitOpenResponse('DeepSeek', circuitCheck.retryAfterMs, entitlement)
  }

  const reservation = await store.consumeUsage(deviceToken, 'message', upstreamModel, creditCost, {
    upstream: 'deepseek',
  })
  let upstream: Response
  const startedAt = Date.now()
  const abortController = new AbortController()
  let requestTimedOut = false
  const requestTimeout = setTimeout(() => {
    requestTimedOut = true
    abortController.abort()
  }, config.deepseekTimeoutMs)
  try {
    upstream = await fetch(`${config.deepseekBaseUrl.replace(/\/+$/, '')}/v1/messages`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': config.deepseekApiKey,
        'anthropic-version': req.headers.get('anthropic-version') || '2023-06-01',
        ...(req.headers.get('anthropic-beta')
          ? { 'anthropic-beta': req.headers.get('anthropic-beta')! }
          : {}),
      },
      body: upstreamBody,
      signal: abortController.signal,
    })
  } catch (error) {
    circuit.recordFailure()
    const refunded = await store.refundCredit(deviceToken, creditCost)
    const timedOut = requestTimedOut || isTimeoutError(error)
    await store.recordUsageTokens(reservation.usageEventId, {}, {
      upstreamError: timedOut ? 'timeout' : 'network',
      timeoutMs: config.deepseekTimeoutMs,
      durationMs: Date.now() - startedAt,
      refundedCredits: creditCost,
    })
    console.warn('[gugu-gateway] DeepSeek message request failed:', {
      model: upstreamModel,
      error: timedOut ? 'timeout' : 'network',
      durationMs: Date.now() - startedAt,
      timeoutMs: config.deepseekTimeoutMs,
    })
    if (timedOut) {
      return errorJson(
        504,
        'UPSTREAM_TIMEOUT',
        'Gugu managed model timed out before responding. Please try again.',
        refunded,
      )
    }
    return errorJson(
      502,
      'UPSTREAM_NETWORK_ERROR',
      'Gugu managed model request failed. Please try again.',
      refunded,
    )
  } finally {
    clearTimeout(requestTimeout)
  }

  const headers = new Headers(upstream.headers)
  headers.set('x-gugu-credits-remaining', String(reservation.entitlement.creditsRemaining))
  headers.set('access-control-expose-headers', 'x-gugu-credits-remaining')

  if (!upstream.ok) {
    const refunded = await store.refundCredit(deviceToken, creditCost)
    const text = await upstream.text().catch(() => '')
    if (isCircuitFailureStatus(upstream.status)) {
      circuit.recordFailure()
    } else {
      circuit.recordSuccess()
    }
    await store.recordUsageTokens(reservation.usageEventId, {}, {
      upstreamStatus: upstream.status,
      durationMs: Date.now() - startedAt,
      refundedCredits: creditCost,
    })
    return errorJson(
      upstream.status,
      upstream.status === 401 ? 'UPSTREAM_AUTH_FAILED' : 'UPSTREAM_ERROR',
      text || `DeepSeek returned HTTP ${upstream.status}`,
      refunded,
    )
  }

  const contentType = upstream.headers.get('content-type') || ''
  if (contentType.includes('application/json')) {
    const raw = await upstream.text()
    const parsed = parseJson(raw)
    circuit.recordSuccess()
    await store.recordUsageTokens(reservation.usageEventId, extractUsageTokens(parsed), {
      upstreamStatus: upstream.status,
      stream: false,
      durationMs: Date.now() - startedAt,
    })
    return new Response(raw, {
      status: upstream.status,
      headers,
    })
  }

  const bodyStream = upstream.body
    ? trackUsageStream(upstream.body, store, reservation.usageEventId, {
        idleTimeoutMs: config.deepseekStreamIdleTimeoutMs,
        onComplete: () => circuit.recordSuccess(),
        onCancel: () => circuit.recordSuccess(),
        onFailure: async (reason) => {
          circuit.recordFailure()
          await store.refundCredit(deviceToken, creditCost)
          return {
            upstreamError: reason,
            idleTimeoutMs: config.deepseekStreamIdleTimeoutMs,
            refundedCredits: creditCost,
          }
        },
      })
    : upstream.body
  if (!upstream.body) {
    circuit.recordSuccess()
  }

  return new Response(bodyStream, {
    status: upstream.status,
    headers,
  })
}

function isTimeoutError(error: unknown): boolean {
  if (!(error instanceof Error)) return false
  const name = error.name.toLowerCase()
  const message = error.message.toLowerCase()
  return name === 'timeouterror' || name === 'aborterror' || message.includes('aborted')
}

function isCircuitFailureStatus(status: number): boolean {
  return status === 429 || status >= 500
}

function upstreamCircuitOpenResponse(
  upstream: string,
  retryAfterMs: number,
  entitlement?: GatewayEntitlement,
): Response {
  const retryAfterSeconds = Math.max(1, Math.ceil(retryAfterMs / 1000))
  const response = errorJson(
    503,
    'UPSTREAM_CIRCUIT_OPEN',
    `${upstream} is recovering after recent failures. Please retry shortly.`,
    entitlement,
  )
  response.headers.set('Retry-After', String(retryAfterSeconds))
  return response
}

function rateLimitIpRequest(
  req: Request,
  rateLimiter: TokenBucketRateLimiter,
  limitPerMinute: number,
  label: string,
  namespace: string,
): Response | null {
  const ip = readClientIp(req)
  return rateLimitResponse(
    rateLimiter.consume(`${namespace}:ip:${ip}`, limitPerMinute),
    `${label} is rate limited for this IP. Please retry shortly.`,
  )
}

async function rateLimitDeviceRequest(
  req: Request,
  config: GatewayConfig,
  store: GatewayStorage,
  rateLimiter: TokenBucketRateLimiter,
  operation: 'message' | 'attachment',
): Promise<Response | null> {
  const deviceToken = readDeviceToken(req)
  const entitlement = await store.getEntitlement(deviceToken)
  if (entitlement.status !== 'active') return null

  const limit = operation === 'message'
    ? messageRateLimitForPlan(config, entitlement.plan)
    : attachmentRateLimitForPlan(config, entitlement.plan)
  const result = rateLimiter.consume(`${operation}:plan:${entitlement.plan}:device:${deviceToken}`, limit)
  const label = operation === 'message' ? 'Gugu Managed message' : 'GLM attachment parsing'
  return rateLimitResponse(
    result,
    `${label} is rate limited for the ${entitlement.plan} plan. Please retry shortly.`,
    entitlement,
  )
}

function rateLimitResponse(
  result: RateLimitResult,
  message: string,
  entitlement?: GatewayEntitlement,
): Response | null {
  if (result.allowed) return null
  const response = errorJson(429, 'RATE_LIMITED', message, entitlement)
  response.headers.set('Retry-After', String(result.retryAfterSeconds))
  response.headers.set('X-Gugu-RateLimit-Limit', String(result.limitPerMinute))
  return response
}

async function forwardAttachment(
  req: Request,
  config: GatewayConfig,
  store: GatewayStorage,
  circuit: UpstreamCircuitBreaker,
): Promise<Response> {
  if (!config.glmApiKey) {
    return errorJson(503, 'UPSTREAM_NOT_CONFIGURED', 'GUGU_GLM_API_KEY is not configured')
  }

  const deviceToken = readDeviceToken(req)
  const body = await readJson(req, config.glmJsonMaxRequestBytes, 'GLM attachment request')
  const operation = asString(body.operation)

  let consumedCredits = 0
  let usageEventId: number | null = null
  try {
    if (operation === 'chat_completions' || operation === 'layout_parsing') {
      const validation = validateGlmJsonAttachmentBody(config, operation, body.body)
      if (validation) return validation

      const usage = resolveAttachmentUsage(config, operation, body.body)
      const circuitCheck = circuit.beforeRequest()
      if (!circuitCheck.allowed) {
        return upstreamCircuitOpenResponse('GLM', circuitCheck.retryAfterMs, await store.getEntitlement(deviceToken))
      }
      const reservation = await store.consumeUsage(deviceToken, usage.kind, usage.model, usage.credits, {
        operation,
        upstream: 'glm',
      })
      consumedCredits = usage.credits
      usageEventId = reservation.usageEventId
      const endpoint = operation === 'chat_completions' ? '/chat/completions' : '/layout_parsing'
      let upstream: Response
      const startedAt = Date.now()
      try {
        upstream = await fetch(`${config.glmBaseUrl.replace(/\/+$/, '')}${endpoint}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${config.glmApiKey}`,
          },
          body: JSON.stringify(body.body ?? {}),
          signal: AbortSignal.timeout(config.glmRequestTimeoutMs),
        })
      } catch (error) {
        circuit.recordFailure()
        const refunded = await store.refundCredit(deviceToken, usage.credits)
        const timedOut = isTimeoutError(error)
        await store.recordUsageTokens(reservation.usageEventId, {}, {
          operation,
          upstream: 'glm',
          upstreamError: timedOut ? 'timeout' : 'network',
          timeoutMs: config.glmRequestTimeoutMs,
          durationMs: Date.now() - startedAt,
          refundedCredits: usage.credits,
        })
        return errorJson(
          timedOut ? 504 : 502,
          timedOut ? 'UPSTREAM_TIMEOUT' : 'UPSTREAM_NETWORK_ERROR',
          timedOut
            ? 'GLM attachment parsing timed out before responding. Please try again.'
            : 'GLM attachment parsing request failed. Please try again.',
          refunded,
        )
      }
      if (isCircuitFailureStatus(upstream.status)) {
        circuit.recordFailure()
      } else {
        circuit.recordSuccess()
      }
      return proxyJsonResponse(
        upstream,
        upstream.ok ? reservation.entitlement : await store.refundCredit(deviceToken, usage.credits),
        store,
        reservation.usageEventId,
        { operation, upstream: 'glm' },
      )
    }

    if (operation === 'file_parser') {
      const name = asString(body.name) || 'attachment.bin'
      const mimeType = asString(body.mimeType) || 'application/octet-stream'
      const dataBase64 = asString(body.dataBase64)
      if (!dataBase64) return errorJson(400, 'BAD_REQUEST', 'dataBase64 is required')
      const decoded = validateGlmFileParserPayload(config, name, mimeType, dataBase64)
      if (decoded instanceof Response) return decoded

      const usage = resolveAttachmentUsage(config, operation, body.body)
      const circuitCheck = circuit.beforeRequest()
      if (!circuitCheck.allowed) {
        return upstreamCircuitOpenResponse('GLM', circuitCheck.retryAfterMs, await store.getEntitlement(deviceToken))
      }
      const reservation = await store.consumeUsage(deviceToken, usage.kind, usage.model, usage.credits, {
        operation,
        upstream: 'glm',
        fileName: name,
        mimeType,
      })
      consumedCredits = usage.credits
      usageEventId = reservation.usageEventId
      const form = new FormData()
      form.append('tool_type', 'prime-sync')
      form.append('file', new Blob([decoded], { type: mimeType }), name)
      let upstream: Response
      const startedAt = Date.now()
      try {
        upstream = await fetch(`${config.glmBaseUrl.replace(/\/+$/, '')}/files/parser/sync`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${config.glmApiKey}` },
          body: form,
          signal: AbortSignal.timeout(config.glmRequestTimeoutMs),
        })
      } catch (error) {
        circuit.recordFailure()
        const refunded = await store.refundCredit(deviceToken, usage.credits)
        const timedOut = isTimeoutError(error)
        await store.recordUsageTokens(reservation.usageEventId, {}, {
          operation,
          upstream: 'glm',
          fileName: name,
          mimeType,
          upstreamError: timedOut ? 'timeout' : 'network',
          timeoutMs: config.glmRequestTimeoutMs,
          durationMs: Date.now() - startedAt,
          refundedCredits: usage.credits,
        })
        return errorJson(
          timedOut ? 504 : 502,
          timedOut ? 'UPSTREAM_TIMEOUT' : 'UPSTREAM_NETWORK_ERROR',
          timedOut
            ? 'GLM file parsing timed out before responding. Please try again.'
            : 'GLM file parsing request failed. Please try again.',
          refunded,
        )
      }
      if (isCircuitFailureStatus(upstream.status)) {
        circuit.recordFailure()
      } else {
        circuit.recordSuccess()
      }
      return proxyJsonResponse(
        upstream,
        upstream.ok ? reservation.entitlement : await store.refundCredit(deviceToken, usage.credits),
        store,
        reservation.usageEventId,
        { operation, upstream: 'glm', fileName: name, mimeType },
      )
    }

    return errorJson(400, 'BAD_REQUEST', 'Unsupported attachment parse operation')
  } catch (error) {
    if (consumedCredits > 0 && !(error instanceof GatewayQuotaError) && !(error instanceof GatewayAuthError)) {
      circuit.recordFailure()
      await store.refundCredit(deviceToken, consumedCredits)
      if (usageEventId) await store.recordUsageTokens(usageEventId, {}, { upstreamError: 'network' })
    }
    throw error
  }
}

async function proxyJsonResponse(
  upstream: Response,
  entitlement: GatewayEntitlement,
  store?: GatewayStorage,
  usageEventId?: number,
  metadata?: Record<string, unknown>,
): Promise<Response> {
  const raw = await upstream.text()
  if (store && usageEventId) {
    const parsed = parseJson(raw)
    await store.recordUsageTokens(usageEventId, extractUsageTokens(parsed), {
      ...(metadata ?? {}),
      upstreamStatus: upstream.status,
      ...(upstream.ok ? {} : { refundedCredits: true }),
    })
  }
  const headers = new Headers({
    ...JSON_HEADERS,
    'x-gugu-credits-remaining': String(entitlement.creditsRemaining),
    'access-control-expose-headers': 'x-gugu-credits-remaining',
  })
  return new Response(raw, { status: upstream.status, headers })
}

async function handleAdminApi(
  req: Request,
  url: URL,
  config: GatewayConfig,
  store: GatewayStorage,
  resolveDownloadConfig: () => Promise<GatewayConfig>,
  runtime: {
    metrics: GatewayMetrics
    messageQueue: GatewayRequestQueue
    glmQueue: GatewayRequestQueue
    deepseekCircuit: UpstreamCircuitBreaker
    glmCircuit: UpstreamCircuitBreaker
  },
): Promise<Response> {
  try {
    const authError = requireAdmin(config, req)
    if (authError) return authError

    if (req.method === 'GET' && url.pathname === '/admin/api/metrics') {
      return adminJson(runtime.metrics.snapshot({
        queues: {
          message: runtime.messageQueue.snapshot(),
          glm: runtime.glmQueue.snapshot(),
        },
        circuits: {
          deepseek: runtime.deepseekCircuit.snapshot(),
          glm: runtime.glmCircuit.snapshot(),
        },
      }))
    }

    if (req.method === 'GET' && url.pathname === '/admin/api/summary') {
      const range = asDashboardRange(url.searchParams.get('range') || '7d')
      return adminJson(await store.getDashboardSummary(range))
    }

    if (req.method === 'GET' && url.pathname === '/admin/api/devices') {
      const devices = await store.listDevices({
        plan: asString(url.searchParams.get('plan')) as GatewayPlan | undefined,
        status: asString(url.searchParams.get('status')) as GatewayEntitlement['status'] | undefined,
        q: asString(url.searchParams.get('q')),
        limit: asPositiveInt(url.searchParams.get('limit')),
        cursor: asPositiveInt(url.searchParams.get('cursor')),
      })
      return adminJson({
        ...devices,
        data: devices.data.map((device) => ({
          ...device,
          deviceToken: maskSecret(device.deviceToken),
          licenseKey: device.licenseKey ? maskSecret(device.licenseKey) : null,
        })),
      })
    }

    if (req.method === 'GET' && url.pathname === '/admin/api/usage') {
      const limit = asPositiveInt(url.searchParams.get('limit')) || 50
      const data = await store.listUsageEvents({
        deviceId: asString(url.searchParams.get('deviceId')),
        limit,
        cursor: asPositiveInt(url.searchParams.get('cursor')),
      })
      return adminJson({
        data,
        pagination: {
          limit,
          nextCursor: data.length === limit ? data[data.length - 1]?.id ?? null : null,
        },
      })
    }

    if (req.method === 'GET' && url.pathname === '/admin/api/orders') {
      return adminJson(await store.listOrders({
        status: asString(url.searchParams.get('status')) as GatewayOrderStatus | undefined,
        q: asString(url.searchParams.get('q')),
        limit: asPositiveInt(url.searchParams.get('limit')),
        cursor: asPositiveInt(url.searchParams.get('cursor')),
      }))
    }

    if (req.method === 'GET' && url.pathname === '/admin/api/download') {
      const downloadConfig = await resolveDownloadConfig()
      return adminJson({
        downloadUrl: downloadConfig.downloadUrl,
        downloadReleaseJsonUrl: config.downloadReleaseJsonUrl,
        downloadWindowsUrl: downloadConfig.downloadWindowsUrl,
        downloadMacosUrl: downloadConfig.downloadMacosUrl,
        downloadVersion: downloadConfig.downloadVersion,
        downloadSha256: downloadConfig.downloadSha256,
        downloadWindowsSha256: downloadConfig.downloadWindowsSha256,
        downloadMacosSha256: downloadConfig.downloadMacosSha256,
        publicBaseUrl: downloadConfig.publicBaseUrl,
      })
    }

    const orderAction = url.pathname.match(/^\/admin\/api\/orders\/([^/]+)\/(pay|fulfill|cancel)$/)
    if (req.method === 'POST' && orderAction) {
      const orderId = decodeURIComponent(orderAction[1]!)
      const action = orderAction[2]
      const order = action === 'pay'
        ? await store.markOrderPaid(orderId)
        : action === 'fulfill'
          ? await store.fulfillOrder(orderId)
          : await store.cancelOrder(orderId)
      return adminJson({ order })
    }

    return adminErrorJson(404, 'NOT_FOUND', `Unknown admin endpoint: ${url.pathname}`)
  } catch (error) {
    return adminErrorJson(400, 'ADMIN_REQUEST_FAILED', error instanceof Error ? error.message : String(error))
  }
}

function resolveDeepSeekModel(config: GatewayConfig, requested: string | undefined, plan: GatewayPlan): string {
  if (plan === 'free') return config.deepseekFastModel
  if (requested === 'gugu-managed-fast') return config.deepseekFastModel
  if (requested === 'gugu-managed-main' || requested === 'gugu-managed-strong') return config.deepseekMainModel
  return requested?.trim() || config.deepseekMainModel
}

async function readJson(req: Request, maxBytes?: number, label = 'JSON request'): Promise<JsonRecord> {
  try {
    const raw = maxBytes ? await readRequestText(req, maxBytes, label) : await req.text()
    const body = raw ? JSON.parse(raw) : {}
    return body && typeof body === 'object' ? body as JsonRecord : {}
  } catch (error) {
    if (errorIsPayloadTooLarge(error)) throw error
    throw new Error('Invalid JSON body')
  }
}

async function readRequestText(req: Request, maxBytes: number, label: string): Promise<string> {
  const contentLength = req.headers.get('content-length')
  const contentLengthBytes = contentLength ? Number.parseInt(contentLength, 10) : Number.NaN
  if (Number.isFinite(contentLengthBytes) && contentLengthBytes > maxBytes) {
    throw new PayloadTooLargeError(
      'PAYLOAD_TOO_LARGE',
      contentLengthBytes,
      maxBytes,
      `${label} is too large (${formatByteCount(contentLengthBytes)} > ${formatByteCount(maxBytes)}).`,
    )
  }

  if (!req.body) return ''
  const reader = req.body.getReader()
  const chunks: Uint8Array[] = []
  let totalBytes = 0
  while (true) {
    const { done, value } = await reader.read()
    if (done) break
    if (!value) continue
    totalBytes += value.byteLength
    if (totalBytes > maxBytes) {
      throw new PayloadTooLargeError(
        'PAYLOAD_TOO_LARGE',
        totalBytes,
        maxBytes,
        `${label} is too large (${formatByteCount(totalBytes)} > ${formatByteCount(maxBytes)}).`,
      )
    }
    chunks.push(value)
  }

  if (chunks.length === 0) return ''
  if (chunks.length === 1) return TEXT_DECODER.decode(chunks[0])
  const bytes = new Uint8Array(totalBytes)
  let offset = 0
  for (const chunk of chunks) {
    bytes.set(chunk, offset)
    offset += chunk.byteLength
  }
  return TEXT_DECODER.decode(bytes)
}

function errorIsPayloadTooLarge(error: unknown): error is PayloadTooLargeError {
  return error instanceof PayloadTooLargeError
}

function readDeviceToken(req: Request): string {
  const auth = req.headers.get('authorization') || ''
  const bearer = auth.match(/^Bearer\s+(.+)$/i)?.[1]?.trim()
  const token = bearer || req.headers.get('x-gugu-device-token')?.trim()
  if (!token) {
    throw new GatewayAuthError('Missing Gugu device token')
  }
  return token
}

function readClientIp(req: Request): string {
  const forwarded = req.headers.get('x-forwarded-for')
    ?.split(',')
    .map((part) => part.trim())
    .find(Boolean)
  const raw = forwarded
    || req.headers.get('x-real-ip')?.trim()
    || req.headers.get('cf-connecting-ip')?.trim()
    || 'unknown'
  return raw.replace(/[^a-zA-Z0-9.:_\-]/g, '').slice(0, 128) || 'unknown'
}

function asString(value: unknown): string | undefined {
  return typeof value === 'string' && value.trim() ? value.trim() : undefined
}

function messageRateLimitForPlan(config: GatewayConfig, plan: GatewayPlan): number {
  if (plan === 'free') return config.freeMessageRateLimitPerMinute
  if (plan === 'light') return config.lightMessageRateLimitPerMinute
  if (plan === 'pro') return config.proMessageRateLimitPerMinute
  return config.maxMessageRateLimitPerMinute
}

function attachmentRateLimitForPlan(config: GatewayConfig, plan: GatewayPlan): number {
  if (plan === 'free') return config.freeAttachmentRateLimitPerMinute
  if (plan === 'light') return config.lightAttachmentRateLimitPerMinute
  if (plan === 'pro') return config.proAttachmentRateLimitPerMinute
  return config.maxAttachmentRateLimitPerMinute
}

function validateGlmJsonAttachmentBody(
  config: GatewayConfig,
  operation: string,
  payload: unknown,
): Response | null {
  const bodyBytes = Buffer.byteLength(JSON.stringify(payload ?? {}), 'utf8')
  if (bodyBytes > config.glmJsonMaxRequestBytes) {
    return attachmentTooLargeJson(
      bodyBytes,
      config.glmJsonMaxRequestBytes,
      'GLM attachment JSON body',
    )
  }

  if (operation === 'layout_parsing') {
    const file = payload && typeof payload === 'object'
      ? (payload as { file?: unknown }).file
      : undefined
    if (typeof file !== 'string') return null
    const dataUrl = parseDataUrl(file)
    if (!dataUrl) {
      return looksLikeDataUrl(file)
        ? errorJson(400, 'BAD_REQUEST', 'layout_parsing file must be a valid base64 data URL')
        : null
    }
    const mimeType = normalizeMimeType(dataUrl.mimeType)
    if (!isSupportedGlmLayoutMimeType(mimeType)) {
      return unsupportedMimeTypeJson(mimeType, 'layout_parsing')
    }
    const decodedBytes = estimateBase64DecodedBytes(dataUrl.base64)
    const limit = mimeType.startsWith('image/')
      ? config.glmImageMaxBytes
      : config.glmFileParseMaxBytes
    if (decodedBytes > limit) {
      return attachmentTooLargeJson(decodedBytes, limit, 'GLM layout file')
    }
    return null
  }

  if (operation === 'chat_completions') {
    for (const imageUrl of collectChatImageDataUrls(payload)) {
      const dataUrl = parseDataUrl(imageUrl)
      if (!dataUrl) {
        if (looksLikeDataUrl(imageUrl)) {
          return errorJson(400, 'BAD_REQUEST', 'chat_completions image URL must be valid base64 data URL')
        }
        continue
      }
      const mimeType = normalizeMimeType(dataUrl.mimeType)
      if (!isSupportedGlmImageMimeType(mimeType)) {
        return unsupportedMimeTypeJson(mimeType, 'chat_completions image')
      }
      const decodedBytes = estimateBase64DecodedBytes(dataUrl.base64)
      if (decodedBytes > config.glmImageMaxBytes) {
        return attachmentTooLargeJson(decodedBytes, config.glmImageMaxBytes, 'GLM image')
      }
    }
  }

  return null
}

function validateGlmFileParserPayload(
  config: GatewayConfig,
  name: string,
  mimeType: string,
  dataBase64: string,
): Buffer | Response {
  const base64 = parseBase64Input(dataBase64)
  if (!base64) {
    return errorJson(400, 'BAD_REQUEST', 'dataBase64 must be valid base64')
  }

  const effectiveMimeType = normalizeMimeType(
    base64.mimeType || mimeType || 'application/octet-stream',
  )
  if (!isSupportedGlmFileParserMimeType(effectiveMimeType)) {
    return unsupportedMimeTypeJson(effectiveMimeType, name)
  }

  const estimatedBytes = estimateBase64DecodedBytes(base64.base64)
  if (estimatedBytes > config.glmFileParseMaxBytes) {
    return attachmentTooLargeJson(estimatedBytes, config.glmFileParseMaxBytes, name)
  }

  const decoded = Buffer.from(base64.base64, 'base64')
  if (decoded.length === 0) {
    return errorJson(400, 'BAD_REQUEST', 'dataBase64 must not be empty')
  }
  if (decoded.length > config.glmFileParseMaxBytes) {
    return attachmentTooLargeJson(decoded.length, config.glmFileParseMaxBytes, name)
  }
  return decoded
}

function attachmentTooLargeJson(requestBytes: number, maxBytes: number, label: string): Response {
  return errorJson(
    413,
    'PAYLOAD_TOO_LARGE',
    `${label} is too large (${formatByteCount(requestBytes)} > ${formatByteCount(maxBytes)}).`,
  )
}

function unsupportedMimeTypeJson(mimeType: string, label: string): Response {
  return errorJson(
    400,
    'UNSUPPORTED_FILE_TYPE',
    `${label} uses unsupported MIME type: ${mimeType || 'unknown'}.`,
  )
}

function collectChatImageDataUrls(value: unknown): string[] {
  const urls: string[] = []
  const visit = (current: unknown): void => {
    if (!current || typeof current !== 'object') return
    if (Array.isArray(current)) {
      for (const item of current) visit(item)
      return
    }

    const record = current as Record<string, unknown>
    if (record.type === 'image_url') {
      const imageUrl = record.image_url
      if (typeof imageUrl === 'string') {
        urls.push(imageUrl)
      } else if (imageUrl && typeof imageUrl === 'object') {
        const url = (imageUrl as { url?: unknown }).url
        if (typeof url === 'string') urls.push(url)
      }
    }

    for (const item of Object.values(record)) visit(item)
  }
  visit(value)
  return urls
}

function parseBase64Input(value: string): { mimeType: string | null; base64: string } | null {
  const dataUrl = parseDataUrl(value)
  const base64 = (dataUrl?.base64 ?? value).replace(/\s+/g, '')
  if (!isStrictBase64(base64)) return null
  return { mimeType: dataUrl?.mimeType ?? null, base64 }
}

function parseDataUrl(value: string): { mimeType: string; base64: string } | null {
  const match = value.match(/^data:([^;,]+)(?:;[^,]*)?;base64,(.*)$/is)
  if (!match) return null
  const mimeType = normalizeMimeType(match[1] || '')
  const base64 = (match[2] || '').replace(/\s+/g, '')
  if (!mimeType || !isStrictBase64(base64)) return null
  return { mimeType, base64 }
}

function looksLikeDataUrl(value: string): boolean {
  return /^data:/i.test(value.trim())
}

function isStrictBase64(value: string): boolean {
  if (!value) return false
  if (value.length % 4 === 1) return false
  return /^[A-Za-z0-9+/]*={0,2}$/.test(value)
}

function estimateBase64DecodedBytes(value: string): number {
  const normalized = value.replace(/\s+/g, '')
  const padding = normalized.endsWith('==') ? 2 : normalized.endsWith('=') ? 1 : 0
  return Math.max(0, Math.floor((normalized.length * 3) / 4) - padding)
}

function normalizeMimeType(value: string): string {
  return value.split(';')[0]?.trim().toLowerCase() || ''
}

function isSupportedGlmImageMimeType(mimeType: string): boolean {
  return SUPPORTED_GLM_IMAGE_MIME_TYPES.has(mimeType)
}

function isSupportedGlmLayoutMimeType(mimeType: string): boolean {
  return mimeType === 'application/pdf' || isSupportedGlmImageMimeType(mimeType)
}

function isSupportedGlmFileParserMimeType(mimeType: string): boolean {
  return SUPPORTED_GLM_DOCUMENT_MIME_TYPES.has(mimeType)
}

function asPositiveInt(value: unknown): number | undefined {
  const raw = typeof value === 'string' ? value.trim() : ''
  if (!raw) return undefined
  const parsed = Number.parseInt(raw, 10)
  return Number.isFinite(parsed) && parsed > 0 ? Math.trunc(parsed) : undefined
}

function formatByteCount(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KiB`
  return `${(bytes / 1024 / 1024).toFixed(1)} MiB`
}

function messageRequestTooLargeMessage(
  requestBytes: number,
  maxBytes: number,
): string {
  return `Gugu Managed request is too large (${formatByteCount(requestBytes)} > ${formatByteCount(maxBytes)}). Split very large file writes into smaller turns or compact the conversation before retrying.`
}

function asDashboardRange(value: string): '7d' | '30d' | 'all' {
  return value === '30d' || value === 'all' ? value : '7d'
}

function finalizeGatewayResponse(
  response: Response,
  request: {
    requestId: string
    method: string
    path: string
    startedAt: number
    contentLength: number | null
    deviceHash: string | null
  },
  metrics: GatewayMetrics,
  config: GatewayConfig,
): Response {
  const headers = new Headers(response.headers)
  headers.set('x-gugu-request-id', request.requestId)
  const durationMs = Date.now() - request.startedAt
  const entry: GatewayRequestLog = {
    ts: new Date().toISOString(),
    event: 'gateway_request',
    requestId: request.requestId,
    method: request.method,
    path: request.path,
    status: response.status,
    durationMs,
    statusClass: `${Math.floor(response.status / 100)}xx`,
    ...(headers.get('x-gugu-error-code')
      ? { errorCode: headers.get('x-gugu-error-code')! }
      : {}),
    ...(headers.get('retry-after') ? { retryAfter: headers.get('retry-after')! } : {}),
    ...(request.contentLength !== null ? { contentLength: request.contentLength } : {}),
    ...(request.deviceHash ? { deviceHash: request.deviceHash } : {}),
    ...(headers.get('x-gugu-upstream')
      ? { upstream: headers.get('x-gugu-upstream')! }
      : inferUpstreamFromPath(request.path)
        ? { upstream: inferUpstreamFromPath(request.path)! }
        : {}),
    ...(headers.get('x-gugu-operation') ? { operation: headers.get('x-gugu-operation')! } : {}),
    ...(headers.get('x-gugu-model') ? { model: headers.get('x-gugu-model')! } : {}),
  }
  metrics.record(entry)
  if (config.requestLogEnabled) {
    console.info(JSON.stringify(entry))
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers,
  })
}

function readRequestId(req: Request): string {
  const raw = req.headers.get('x-gugu-request-id') || req.headers.get('x-request-id') || ''
  const trimmed = raw.trim()
  if (/^[A-Za-z0-9._:-]{1,80}$/.test(trimmed)) return trimmed
  return randomUUID()
}

function readContentLength(req: Request): number | null {
  const value = Number.parseInt(req.headers.get('content-length') || '', 10)
  return Number.isFinite(value) && value >= 0 ? value : null
}

function readDeviceHash(req: Request): string | null {
  const token = readOptionalDeviceToken(req)
  if (!token) return null
  return createHash('sha256').update(token).digest('hex').slice(0, 16)
}

function readOptionalDeviceToken(req: Request): string | null {
  const auth = req.headers.get('authorization') || ''
  const bearer = auth.match(/^Bearer\s+(.+)$/i)?.[1]?.trim()
  return bearer || req.headers.get('x-gugu-device-token')?.trim() || null
}

function inferUpstreamFromPath(pathname: string): 'deepseek' | 'glm' | undefined {
  if (pathname === '/v1/messages') return 'deepseek'
  if (pathname === '/v1/attachments/parse') return 'glm'
  return undefined
}

function handleGatewayError(error: unknown): Response {
  if (error instanceof GatewayQuotaError) {
    return errorJson(error.statusCode, 'GUGU_QUOTA_EXHAUSTED', error.message, error.entitlement)
  }
  if (error instanceof GatewayAuthError) {
    return errorJson(401, 'UNAUTHORIZED', error.message)
  }
  if (error instanceof PayloadTooLargeError) {
    return errorJson(413, error.code, error.message)
  }
  if (error instanceof Error && error.message === 'Invalid JSON body') {
    return errorJson(400, 'BAD_REQUEST', error.message)
  }
  if (error instanceof Error && (
    error.message === 'Both orderId and orderToken are required to reuse an order.' ||
    error.message === 'Order package does not match the requested package.' ||
    error.message === 'Only pending orders can switch payment methods.'
  )) {
    return errorJson(400, 'BAD_REQUEST', error.message)
  }
  console.error('[gugu-gateway] unexpected error:', error)
  return errorJson(500, 'INTERNAL_ERROR', 'Gateway internal error')
}

function json(body: unknown, init?: ResponseInit): Response {
  return new Response(JSON.stringify(body), {
    status: init?.status ?? 200,
    headers: {
      ...JSON_HEADERS,
      ...corsHeaders(),
      ...(init?.headers ?? {}),
    },
  })
}

function adminJson(body: unknown, init?: ResponseInit): Response {
  return new Response(JSON.stringify(body), {
    status: init?.status ?? 200,
    headers: {
      ...JSON_HEADERS,
      'Cache-Control': 'no-store',
      ...(init?.headers ?? {}),
    },
  })
}

function adminErrorJson(status: number, code: string, message: string): Response {
  return adminJson({ error: { code, message } }, {
    status,
    headers: { 'x-gugu-error-code': code },
  })
}

function requireAdmin(config: GatewayConfig, req: Request): Response | null {
  if (!config.adminToken) return adminErrorJson(404, 'ADMIN_DISABLED', 'Admin dashboard is not enabled.')
  const auth = req.headers.get('authorization') || ''
  const token = auth.match(/^Bearer\s+(.+)$/i)?.[1]?.trim()
  if (!token || token !== config.adminToken) {
    return adminErrorJson(401, 'UNAUTHORIZED', 'Admin token is required.')
  }
  return null
}

function resolveAttachmentUsage(
  config: GatewayConfig,
  operation: string | undefined,
  payload: unknown,
): { kind: string; model: string; credits: number } {
  const model = extractPayloadModel(payload)
  if (operation === 'file_parser') {
    return { kind: 'file_parser', model: model || 'glm-file-parser', credits: config.fileParseCreditCost }
  }
  if (operation === 'layout_parsing') {
    return { kind: 'ocr', model: model || 'glm-ocr', credits: config.fileParseCreditCost }
  }
  if (model.includes('glm-5.1')) {
    return { kind: 'summarize', model, credits: config.summarizeCreditCost }
  }
  if (model.includes('glm-5v') || payloadHasImage(payload)) {
    return { kind: 'vision', model: model || 'glm-5v-turbo', credits: config.attachmentCreditCost }
  }
  return { kind: 'glm_text', model: model || 'glm-chat', credits: config.messageCreditCost }
}

function extractPayloadModel(payload: unknown): string {
  if (!payload || typeof payload !== 'object') return ''
  const model = (payload as { model?: unknown }).model
  return typeof model === 'string' ? model.trim() : ''
}

function payloadHasImage(payload: unknown): boolean {
  return (JSON.stringify(payload ?? {}) || '').includes('image_url')
}

function parseJson(raw: string): unknown {
  try {
    return JSON.parse(raw)
  } catch {
    return null
  }
}

function extractUsageTokens(value: unknown): { inputTokens?: number | null; outputTokens?: number | null } {
  const usage = findUsageObject(value)
  if (!usage) return {}
  return {
    inputTokens: readTokenNumber(usage.input_tokens)
      ?? readTokenNumber(usage.inputTokens)
      ?? readTokenNumber(usage.prompt_tokens)
      ?? readTokenNumber(usage.promptTokens),
    outputTokens: readTokenNumber(usage.output_tokens)
      ?? readTokenNumber(usage.outputTokens)
      ?? readTokenNumber(usage.completion_tokens)
      ?? readTokenNumber(usage.completionTokens),
  }
}

function findUsageObject(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== 'object') return null
  const record = value as Record<string, unknown>
  if (
    'input_tokens' in record ||
    'output_tokens' in record ||
    'prompt_tokens' in record ||
    'completion_tokens' in record
  ) {
    return record
  }
  if (record.usage && typeof record.usage === 'object') return record.usage as Record<string, unknown>
  if (record.message && typeof record.message === 'object') {
    const usage = findUsageObject(record.message)
    if (usage) return usage
  }
  if (record.response && typeof record.response === 'object') {
    const usage = findUsageObject(record.response)
    if (usage) return usage
  }
  return null
}

function readTokenNumber(value: unknown): number | null {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) return null
  return Math.trunc(value)
}

function maskSecret(value: string): string {
  if (value.length <= 12) return '••••'
  return `${value.slice(0, 6)}...${value.slice(-4)}`
}

function mergeUsage(
  current: { inputTokens: number | null; outputTokens: number | null },
  next: { inputTokens?: number | null; outputTokens?: number | null },
): void {
  if (typeof next.inputTokens === 'number') {
    current.inputTokens = Math.max(current.inputTokens ?? 0, next.inputTokens)
  }
  if (typeof next.outputTokens === 'number') {
    current.outputTokens = Math.max(current.outputTokens ?? 0, next.outputTokens)
  }
}

function trackUsageStream(
  body: ReadableStream<Uint8Array>,
  store: GatewayStorage,
  usageEventId: number,
  options: {
    idleTimeoutMs?: number
    onComplete?: () => void | Promise<void>
    onCancel?: () => void | Promise<void>
    onFailure?: (reason: string) => Record<string, unknown> | void | Promise<Record<string, unknown> | void>
  } = {},
): ReadableStream<Uint8Array> {
  const decoder = new TextDecoder()
  const encoder = new TextEncoder()
  let buffer = ''
  let finished = false
  const tokens = { inputTokens: null as number | null, outputTokens: null as number | null }

  const parseChunk = (text: string) => {
    buffer += text
    const lines = buffer.split(/\r?\n/)
    buffer = lines.pop() ?? ''
    for (const line of lines) {
      const trimmed = line.trim()
      if (!trimmed.startsWith('data:')) continue
      const data = trimmed.slice(5).trim()
      if (!data || data === '[DONE]') continue
      mergeUsage(tokens, extractUsageTokens(parseJson(data)))
    }
  }

  const persist = async (metadata?: Record<string, unknown>) => {
    if (finished) return
    finished = true
    await store.recordUsageTokens(usageEventId, tokens, {
      stream: true,
      usageCaptured: tokens.inputTokens !== null || tokens.outputTokens !== null,
      ...(metadata ?? {}),
    })
  }

  return new ReadableStream<Uint8Array>({
    async start(controller) {
      const reader = body.getReader()
      try {
        while (true) {
          let timeout: ReturnType<typeof setTimeout> | null = null
          const readResult = await Promise.race([
            reader.read().then((result) => ({ kind: 'read' as const, result })),
            ...(options.idleTimeoutMs
              ? [new Promise<{ kind: 'timeout' }>((resolve) => {
                  timeout = setTimeout(() => resolve({ kind: 'timeout' }), options.idleTimeoutMs)
                })]
              : []),
          ])
          if (timeout) clearTimeout(timeout)

          if (readResult.kind === 'timeout') {
            const reason = 'stream_idle_timeout'
            const message = 'Gugu managed model stream was idle for too long. Please retry.'
            const extra = await options.onFailure?.(reason) ?? {}
            await persist({ streamError: reason, ...extra })
            await reader.cancel(reason).catch(() => {})
            controller.enqueue(encoder.encode(`event: error\ndata: ${JSON.stringify({
              type: 'error',
              error: {
                type: 'api_error',
                message,
              },
            })}\n\n`))
            controller.close()
            return
          }

          const { done, value } = readResult.result
          if (done) break
          if (value) {
            parseChunk(decoder.decode(value, { stream: true }))
            controller.enqueue(value)
          }
        }
        const tail = decoder.decode()
        if (tail) parseChunk(tail)
        if (buffer.trim()) {
          const line = buffer.trim()
          if (line.startsWith('data:')) mergeUsage(tokens, extractUsageTokens(parseJson(line.slice(5).trim())))
        }
        await persist()
        await options.onComplete?.()
        controller.close()
      } catch (error) {
        const reason = error instanceof Error ? error.message : String(error)
        const extra = await options.onFailure?.(reason) ?? {}
        await persist({ streamError: reason, ...extra })
        controller.error(error)
      } finally {
        reader.releaseLock()
      }
    },
    async cancel(reason) {
      await persist({ streamCancelled: String(reason ?? '') })
      await options.onCancel?.()
    },
  })
}

function alipayCheckoutRedirectHtml(cashierUrl: string): string {
  const scriptUrl = JSON.stringify(cashierUrl).replace(/</g, '\\u003c')
  const href = escapeHtml(cashierUrl)
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex">
  <title>打开支付宝收银台 - Gugu Agent</title>
  <style>
    body { margin: 0; font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; background: #f7f3eb; color: #211914; }
    main { min-height: 100vh; display: grid; place-items: center; padding: 24px; box-sizing: border-box; }
    section { width: min(440px, 100%); padding: 28px; border: 1px solid #dfc7a7; border-radius: 8px; background: #fffdf8; box-shadow: 0 20px 46px rgba(75, 48, 22, .12); }
    h1 { margin: 0 0 12px; font-size: 24px; }
    p { margin: 0 0 18px; color: #6b5c50; line-height: 1.7; }
    a { display: inline-flex; align-items: center; justify-content: center; width: 100%; min-height: 44px; border-radius: 8px; background: #1677ff; color: white; text-decoration: none; font-weight: 700; }
  </style>
</head>
<body>
  <main>
    <section>
      <h1>正在打开支付宝收银台</h1>
      <p>如果没有自动跳转，请点下面的按钮继续付款。</p>
      <a href="${href}" rel="noreferrer">打开支付宝付款</a>
    </section>
  </main>
  <script>window.location.replace(${scriptUrl})</script>
</body>
</html>`
}

function alipayCheckoutMessageHtml(title: string, message: string): string {
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex">
  <title>${escapeHtml(title)} - Gugu Agent</title>
  <style>
    body { margin: 0; font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; background: #f7f3eb; color: #211914; }
    main { min-height: 100vh; display: grid; place-items: center; padding: 24px; box-sizing: border-box; }
    section { width: min(440px, 100%); padding: 28px; border: 1px solid #dfc7a7; border-radius: 8px; background: #fffdf8; }
    h1 { margin: 0 0 12px; font-size: 24px; }
    p { margin: 0; color: #6b5c50; line-height: 1.7; }
  </style>
</head>
<body>
  <main>
    <section>
      <h1>${escapeHtml(title)}</h1>
      <p>${escapeHtml(message)}</p>
    </section>
  </main>
</body>
</html>`
}

function html(body: string, init?: ResponseInit): Response {
  return new Response(body, {
    status: init?.status ?? 200,
    headers: {
      ...HTML_HEADERS,
      ...(init?.headers ?? {}),
    },
  })
}

function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, (char) => {
    switch (char) {
      case '&': return '&amp;'
      case '<': return '&lt;'
      case '>': return '&gt;'
      case '"': return '&quot;'
      case "'": return '&#39;'
      default: return char
    }
  })
}

function errorJson(
  status: number,
  code: string,
  message: string,
  entitlement?: GatewayEntitlement,
): Response {
  const body: GatewayErrorBody = {
    error: {
      code,
      message,
      ...(entitlement ? { entitlement } : {}),
    },
  }
  return json(body, {
    status,
    headers: { 'x-gugu-error-code': code },
  })
}

function corsHeaders(): Record<string, string> {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'content-type, authorization, x-gugu-device-token, x-gugu-order-token, anthropic-version, anthropic-beta',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Expose-Headers': 'x-gugu-request-id, x-gugu-error-code, x-gugu-credits-remaining, retry-after',
  }
}

if (import.meta.main) {
  startGateway()
}
