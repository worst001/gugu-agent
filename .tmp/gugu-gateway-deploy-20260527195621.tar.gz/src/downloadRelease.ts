import type { GatewayConfig } from './types.js'

type DownloadPlatformJson = {
  url?: unknown
  sha256?: unknown
}

type DownloadReleaseJson = {
  version?: unknown
  windows?: DownloadPlatformJson
  macos?: DownloadPlatformJson
}

type DownloadReleasePlatform = {
  url: string
  sha256: string | null
}

type DownloadRelease = {
  version: string
  windows: DownloadReleasePlatform | null
  macos: DownloadReleasePlatform | null
}

type ResolverOptions = {
  cacheTtlMs?: number
  failureCacheTtlMs?: number
  fetch?: typeof globalThis.fetch
  timeoutMs?: number
}

const DEFAULT_CACHE_TTL_MS = 5 * 60 * 1000
const DEFAULT_FAILURE_CACHE_TTL_MS = 60 * 1000
const DEFAULT_TIMEOUT_MS = 3_000

export function createDownloadConfigResolver(
  config: GatewayConfig,
  options: ResolverOptions = {},
): () => Promise<GatewayConfig> {
  const releaseJsonUrl = config.downloadReleaseJsonUrl
  if (!releaseJsonUrl) {
    return async () => config
  }

  const fetcher = options.fetch ?? globalThis.fetch
  const cacheTtlMs = options.cacheTtlMs ?? DEFAULT_CACHE_TTL_MS
  const failureCacheTtlMs = options.failureCacheTtlMs ?? DEFAULT_FAILURE_CACHE_TTL_MS
  const timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS
  let cache: { expiresAt: number; value: GatewayConfig } | null = null

  return async () => {
    const now = Date.now()
    if (cache && cache.expiresAt > now) {
      return cache.value
    }

    try {
      const release = await fetchDownloadReleaseJson(releaseJsonUrl, fetcher, timeoutMs)
      const value = mergeDownloadRelease(config, release)
      cache = { expiresAt: now + cacheTtlMs, value }
      return value
    } catch (error) {
      console.warn(
        `[gugu-gateway] failed to load download release.json: ${error instanceof Error ? error.message : String(error)}`,
      )
      cache = { expiresAt: now + failureCacheTtlMs, value: config }
      return config
    }
  }
}

async function fetchDownloadReleaseJson(
  url: string,
  fetcher: typeof globalThis.fetch,
  timeoutMs: number,
): Promise<DownloadRelease> {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)

  try {
    const response = await fetcher(url, {
      headers: { Accept: 'application/json' },
      signal: controller.signal,
    })
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`)
    }
    const raw = await response.json()
    return parseDownloadReleaseJson(raw)
  } finally {
    clearTimeout(timer)
  }
}

function parseDownloadReleaseJson(raw: unknown): DownloadRelease {
  if (!raw || typeof raw !== 'object') {
    throw new Error('release.json must be an object')
  }

  const record = raw as DownloadReleaseJson
  const version = asNonEmptyString(record.version)
  if (!version) {
    throw new Error('release.json is missing version')
  }

  const windows = parsePlatform(record.windows, 'windows')
  const macos = parsePlatform(record.macos, 'macos')
  if (!windows && !macos) {
    throw new Error('release.json has no usable platform downloads')
  }

  return { version, windows, macos }
}

function parsePlatform(raw: DownloadPlatformJson | undefined, name: string): DownloadReleasePlatform | null {
  if (!raw || typeof raw !== 'object') return null

  const url = asHttpUrl(raw.url)
  if (!url) {
    throw new Error(`release.json ${name}.url must be an http(s) URL`)
  }

  const sha256 = asSha256(raw.sha256)
  return { url, sha256 }
}

function mergeDownloadRelease(config: GatewayConfig, release: DownloadRelease): GatewayConfig {
  return {
    ...config,
    downloadWindowsUrl: release.windows?.url ?? config.downloadWindowsUrl,
    downloadMacosUrl: release.macos?.url ?? config.downloadMacosUrl,
    downloadVersion: release.version || config.downloadVersion,
    downloadWindowsSha256: release.windows?.sha256 ?? config.downloadWindowsSha256,
    downloadMacosSha256: release.macos?.sha256 ?? config.downloadMacosSha256,
    downloadUrl: release.windows?.url ?? config.downloadUrl,
    downloadSha256: release.windows?.sha256 ?? config.downloadSha256,
  }
}

function asNonEmptyString(value: unknown): string | null {
  return typeof value === 'string' && value.trim() ? value.trim() : null
}

function asHttpUrl(value: unknown): string | null {
  const raw = asNonEmptyString(value)
  if (!raw) return null

  try {
    const url = new URL(raw)
    if (url.protocol !== 'http:' && url.protocol !== 'https:') return null
    return url.toString()
  } catch {
    return null
  }
}

function asSha256(value: unknown): string | null {
  const raw = asNonEmptyString(value)?.toLowerCase()
  if (!raw) return null
  return /^[a-f0-9]{64}$/.test(raw) ? raw : null
}
