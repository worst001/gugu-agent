import { loadGatewayConfig } from '../src/config.js'
import { MysqlGatewayStore } from '../src/mysqlStore.js'

async function main(): Promise<void> {
  const store = new MysqlGatewayStore(loadGatewayConfig())
  try {
    await store.ping()
    const report = await store.checkSchema()
    console.log(JSON.stringify(report, null, 2))
    if (!report.ok) {
      process.exitCode = 1
    }
  } finally {
    await store.close()
  }
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error))
  process.exit(1)
})
