import mysql from 'mysql2/promise'
import * as fs from 'node:fs'
import * as fsp from 'node:fs/promises'
import * as path from 'node:path'
import { loadGatewayConfig } from '../src/config.js'
import { MysqlGatewayStore } from '../src/mysqlStore.js'
import type { GatewayConfig } from '../src/types.js'

const args = process.argv.slice(2)
const REHEARSAL_CONFIRMATION = 'I_UNDERSTAND_THIS_FREEZES_WRITES'
const CUTOVER_CONFIRMATION = 'I_UNDERSTAND_THIS_SWITCHES_PRODUCTION_TO_MYSQL'
const TABLES = [
  'payment_notifications',
  'usage_events',
  'orders',
  'activation_codes',
  'devices',
  'gateway_schema_migrations',
]

type Options = {
  appDir: string
  envFile: string
  mysqlEnvFile: string
  dbPath: string
  backupDir: string
  serviceName: string
  healthUrl: string
  baseUrl: string
  rehearsalDb: string
  planOnly: boolean
  skipService: boolean
  allowDaytime: boolean
  commitMysql: boolean
  confirm: string
}

type CommandResult = {
  stdout: string
  stderr: string
}

async function main(): Promise<void> {
  if (hasFlag('--help') || hasFlag('-h')) {
    printHelp()
    return
  }

  const options = readOptions()
  const timestamp = formatTimestamp(new Date())
  const runDir = path.join(options.backupDir, `mysql-cutover-rehearsal-${timestamp}`)
  const importSqlPath = path.join(runDir, 'mysql-data.sql')
  const manifestPath = `${importSqlPath}.manifest.json`
  const verifySqlPath = path.join(runDir, 'mysql-verify.sql')
  const envBackupPath = path.join(runDir, 'gateway.env.before-rehearsal')

  const plan = {
    mode: options.commitMysql ? 'commit-mysql' : 'rehearsal',
    appDir: options.appDir,
    envFile: options.envFile,
    mysqlEnvFile: options.mysqlEnvFile,
    sqlite: options.dbPath,
    backupDir: options.backupDir,
    runDir,
    serviceName: options.serviceName,
    healthUrl: options.healthUrl,
    baseUrl: options.baseUrl,
    rehearsalDb: options.rehearsalDb,
    phases: [
      'preflight health check',
      'backup gateway env',
      'enable maintenance mode, disable orders, and freeze public writes',
      'backup and restore-check SQLite',
      'run migration-report --fail-on-issues',
      'export SQLite data to MySQL data-only SQL',
      'reset rehearsal MySQL tables and import schema/data',
      'verify imported row counts and business totals',
      'temporarily point gateway at MySQL while writes stay frozen',
      options.commitMysql
        ? 'open writes on MySQL and keep gateway on MySQL'
        : 'restore the original env, restarting back to SQLite',
    ],
  }

  if (options.planOnly) {
    console.log(JSON.stringify({ ok: true, mode: 'plan-only', plan }, null, 2))
    return
  }

  const expectedConfirmation = options.commitMysql
    ? CUTOVER_CONFIRMATION
    : REHEARSAL_CONFIRMATION
  if (options.confirm !== expectedConfirmation) {
    throw new Error(`Refusing to run without --confirm ${expectedConfirmation}`)
  }
  if (!options.allowDaytime) {
    assertNightWindow()
  }
  assertIdentifier(options.rehearsalDb, '--rehearsal-db')
  assertReadableFile(options.envFile, 'gateway env file')
  assertReadableFile(options.mysqlEnvFile, 'MySQL env file')
  assertReadableFile(options.dbPath, 'SQLite database')
  assertReadableFile(path.join(options.appDir, 'deploy/mysql/schema.sql'), 'MySQL schema')

  await fsp.mkdir(runDir, { recursive: true })
  await fsp.copyFile(options.envFile, envBackupPath)

  let restored = false
  let committedMysql = false
  const restoreOriginalEnv = async () => {
    if (committedMysql) return
    if (restored) return
    await fsp.copyFile(envBackupPath, options.envFile)
    if (!options.skipService) {
      await runCommand('systemctl', ['restart', options.serviceName])
      await waitForHealth(options.healthUrl)
    }
    restored = true
  }

  try {
    if (!options.skipService) {
      await waitForHealth(options.healthUrl)
    }

    logStep('Enable maintenance write freeze')
    await upsertEnvValues(options.envFile, {
      GUGU_MAINTENANCE_MODE: '1',
      GUGU_MAINTENANCE_DISABLE_ORDERS: '1',
      GUGU_MAINTENANCE_DISABLE_WRITES: '1',
      GUGU_STORE_DRIVER: 'sqlite',
    })
    if (!options.skipService) {
      await runCommand('systemctl', ['restart', options.serviceName])
      await waitForHealth(options.healthUrl)
      await assertWriteFreeze(options.baseUrl)
    }

    logStep('Backup and validate SQLite')
    await runBun(options, ['run', 'scripts/backup.ts', '--db', options.dbPath, '--out-dir', options.backupDir, '--no-prune'])
    await runBun(options, ['run', 'scripts/restore-check.ts'])
    await runBun(options, ['run', 'scripts/migration-report.ts', '--db', options.dbPath, '--fail-on-issues'])

    logStep('Export SQLite data for MySQL')
    await runBun(options, ['run', 'scripts/export-mysql.ts', '--db', options.dbPath, '--out', importSqlPath])
    await runBun(options, ['run', 'scripts/mysql-verify-sql.ts', '--manifest', manifestPath, '--out', verifySqlPath])

    const mysqlEnv = await readEnvFile(options.mysqlEnvFile)
    const mysqlUrl = buildMysqlUrl(mysqlEnv, options.rehearsalDb)

    logStep('Reset and import rehearsal MySQL database')
    await executeSqlFile(mysqlUrl, path.join(options.appDir, 'deploy/mysql/schema.sql'))
    await resetMysqlTables(mysqlUrl)
    await executeSqlFile(mysqlUrl, importSqlPath)
    const verifySummary = await executeVerificationSql(mysqlUrl, verifySqlPath)
    if (verifySummary.verification_status !== 'ok' || Number(verifySummary.mismatches) !== 0) {
      throw new Error(`MySQL verification failed: ${JSON.stringify(verifySummary)}`)
    }

    logStep('Check MySQL schema through gateway storage')
    const schemaCheck = await checkMysqlSchema(mysqlUrl)
    if (!schemaCheck.ok) {
      throw new Error(`MySQL schema check failed: ${JSON.stringify(schemaCheck)}`)
    }

    if (!options.skipService) {
      logStep('Temporarily switch frozen gateway to MySQL')
      await upsertEnvValues(options.envFile, {
        GUGU_STORE_DRIVER: 'mysql',
        GUGU_MYSQL_URL: mysqlUrl,
        GUGU_MAINTENANCE_MODE: '1',
        GUGU_MAINTENANCE_DISABLE_ORDERS: '1',
        GUGU_MAINTENANCE_DISABLE_WRITES: '1',
      })
      await runCommand('systemctl', ['restart', options.serviceName])
      await waitForHealth(options.healthUrl)
      await assertWriteFreeze(options.baseUrl)
    }

    if (options.commitMysql) {
      logStep('Open writes on MySQL')
      await upsertEnvValues(options.envFile, {
        GUGU_STORE_DRIVER: 'mysql',
        GUGU_MYSQL_URL: mysqlUrl,
        GUGU_MAINTENANCE_MODE: '0',
        GUGU_MAINTENANCE_DISABLE_ORDERS: '0',
        GUGU_MAINTENANCE_DISABLE_WRITES: '0',
      })
      await runCommand('systemctl', ['restart', options.serviceName])
      await waitForHealth(options.healthUrl)
      committedMysql = true
    } else {
      logStep('Restore original gateway env and return to SQLite')
      await restoreOriginalEnv()
    }

    console.log(JSON.stringify({
      ok: true,
      mode: options.commitMysql ? 'commit-mysql' : 'rehearsal',
      runDir,
      importSqlPath,
      manifestPath,
      verifySqlPath,
      verifySummary,
      schemaCheck,
      committedMysql,
      restoredOriginalEnv: restored,
    }, null, 2))
  } catch (error) {
    await restoreOriginalEnv().catch((restoreError) => {
      console.error(`Failed to restore original gateway env: ${formatError(restoreError)}`)
    })
    throw error
  }
}

function readOptions(): Options {
  const appDir = path.resolve(readArg('--app-dir', process.env.GUGU_GATEWAY_APP_DIR || path.resolve(import.meta.dir, '..')))
  return {
    appDir,
    envFile: path.resolve(readArg('--env-file', process.env.GUGU_GATEWAY_ENV_FILE || firstExistingPath([
      '/root/opt/gugu/.env',
      '/etc/gugu-gateway/gateway.env',
      path.join(appDir, '.env'),
    ]))),
    mysqlEnvFile: path.resolve(readArg('--mysql-env-file', process.env.GUGU_MYSQL_ENV_FILE || '/etc/gugu-gateway/mysql.env')),
    dbPath: path.resolve(readArg('--db', process.env.GUGU_GATEWAY_DB_PATH || '/var/lib/gugu-gateway/gateway.sqlite')),
    backupDir: path.resolve(readArg('--backup-dir', process.env.GUGU_GATEWAY_BACKUP_DIR || '/var/backups/gugu-gateway')),
    serviceName: readArg('--service', process.env.GUGU_GATEWAY_SERVICE || 'gugu-gateway'),
    healthUrl: readArg('--health-url', process.env.GUGU_GATEWAY_HEALTH_URL || 'http://127.0.0.1:18787/health'),
    baseUrl: readArg('--base-url', process.env.GUGU_GATEWAY_BASE_URL || 'http://127.0.0.1:18787'),
    rehearsalDb: readArg('--rehearsal-db', process.env.GUGU_MYSQL_REHEARSAL_DATABASE || 'gugu_gateway_dryrun'),
    planOnly: hasFlag('--plan-only'),
    skipService: hasFlag('--skip-service'),
    allowDaytime: hasFlag('--allow-daytime'),
    commitMysql: hasFlag('--commit-mysql'),
    confirm: readArg('--confirm', process.env.GUGU_MYSQL_REHEARSAL_CONFIRM || ''),
  }
}

async function runBun(options: Options, commandArgs: string[]): Promise<CommandResult> {
  return runCommand(resolveBunCommand(), commandArgs, {
    cwd: options.appDir,
    env: {
      ...process.env,
      GUGU_GATEWAY_DB_PATH: options.dbPath,
      GUGU_GATEWAY_BACKUP_DIR: options.backupDir,
    },
  })
}

async function runCommand(
  command: string,
  commandArgs: string[],
  options: { cwd?: string; env?: NodeJS.ProcessEnv } = {},
): Promise<CommandResult> {
  const proc = Bun.spawn([command, ...commandArgs], {
    cwd: options.cwd,
    env: options.env,
    stdout: 'pipe',
    stderr: 'pipe',
  })
  const [stdout, stderr, exitCode] = await Promise.all([
    new Response(proc.stdout).text(),
    new Response(proc.stderr).text(),
    proc.exited,
  ])
  if (exitCode !== 0) {
    throw new Error([
      `Command failed (${exitCode}): ${[command, ...commandArgs].join(' ')}`,
      stdout.trim() ? `stdout:\n${stdout}` : null,
      stderr.trim() ? `stderr:\n${stderr}` : null,
    ].filter(Boolean).join('\n'))
  }
  return { stdout, stderr }
}

async function resetMysqlTables(mysqlUrl: string): Promise<void> {
  const sql = [
    'SET FOREIGN_KEY_CHECKS = 0',
    ...TABLES.map((table) => `DELETE FROM ${quoteIdentifier(table)}`),
    'SET FOREIGN_KEY_CHECKS = 1',
  ].join(';\n')
  await executeSql(mysqlUrl, sql)
}

async function executeSqlFile(mysqlUrl: string, filePath: string): Promise<void> {
  await executeSql(mysqlUrl, await fsp.readFile(filePath, 'utf8'))
}

async function executeSql(mysqlUrl: string, sql: string): Promise<unknown> {
  const connection = await mysql.createConnection({
    uri: mysqlUrl,
    multipleStatements: true,
    dateStrings: true,
    supportBigNumbers: true,
  })
  try {
    const [rows] = await connection.query(sql)
    return rows
  } finally {
    await connection.end()
  }
}

async function executeVerificationSql(mysqlUrl: string, filePath: string): Promise<Record<string, unknown>> {
  const rows = await executeSql(mysqlUrl, await fsp.readFile(filePath, 'utf8'))
  const resultSets = Array.isArray(rows) ? rows : [rows]
  for (const resultSet of resultSets) {
    if (!Array.isArray(resultSet)) continue
    const summary = resultSet.find((row) => row && typeof row === 'object' && 'verification_status' in row)
    if (summary && typeof summary === 'object') {
      return summary as Record<string, unknown>
    }
  }
  throw new Error(`Verification SQL did not return a summary row: ${filePath}`)
}

async function checkMysqlSchema(mysqlUrl: string) {
  const config: GatewayConfig = {
    ...loadGatewayConfig(),
    storeDriver: 'mysql',
    mysqlUrl,
  }
  const store = new MysqlGatewayStore(config)
  try {
    await store.ping()
    return await store.checkSchema()
  } finally {
    await store.close()
  }
}

async function assertWriteFreeze(baseUrl: string): Promise<void> {
  const response = await runCommand('curl', [
    '-sS',
    '-o',
    '/dev/null',
    '-w',
    '%{http_code}',
    '-X',
    'POST',
    `${baseUrl.replace(/\/+$/, '')}/v1/devices`,
    '-H',
    'Content-Type: application/json',
    '-d',
    JSON.stringify({ deviceId: `mysql-rehearsal-${Date.now()}` }),
  ])
  const status = response.stdout.trim()
  if (status !== '503') {
    throw new Error(`Expected write freeze to return 503 for /v1/devices, got ${status}`)
  }
}

async function waitForHealth(url: string, timeoutMs = 20_000): Promise<void> {
  const startedAt = Date.now()
  let lastError = ''

  while (Date.now() - startedAt < timeoutMs) {
    try {
      const response = await fetch(url)
      const body = await response.text()
      if (response.ok) return
      lastError = `${response.status} ${body.slice(0, 200)}`
    } catch (error) {
      lastError = formatError(error)
    }
    await Bun.sleep(500)
  }

  throw new Error(`Health check did not pass within ${timeoutMs}ms: ${url}; last error: ${lastError}`)
}

async function upsertEnvValues(filePath: string, updates: Record<string, string>): Promise<void> {
  const lines = (await fsp.readFile(filePath, 'utf8')).split(/\r?\n/)
  const remaining = new Map(Object.entries(updates))
  const next = lines.map((line) => {
    const match = line.match(/^([A-Za-z_][A-Za-z0-9_]*)=/)
    if (!match || !remaining.has(match[1])) return line
    const value = remaining.get(match[1]) ?? ''
    remaining.delete(match[1])
    return `${match[1]}=${value}`
  })

  if (remaining.size > 0) {
    if (next[next.length - 1] !== '') next.push('')
    next.push('# Added by mysql-cutover-rehearsal.ts')
    for (const [key, value] of remaining) {
      next.push(`${key}=${value}`)
    }
  }

  await fsp.writeFile(filePath, `${next.join('\n').replace(/\n+$/, '')}\n`)
}

async function readEnvFile(filePath: string): Promise<Record<string, string>> {
  const values: Record<string, string> = {}
  const content = await fsp.readFile(filePath, 'utf8')
  for (const rawLine of content.split(/\r?\n/)) {
    const line = rawLine.trim()
    if (!line || line.startsWith('#')) continue
    const match = line.match(/^([A-Za-z_][A-Za-z0-9_]*)=(.*)$/)
    if (!match) continue
    values[match[1]] = stripOptionalQuotes(match[2].trim())
  }
  return values
}

function buildMysqlUrl(values: Record<string, string>, database: string): string {
  const user = values.GUGU_MYSQL_APP_USER || 'gugu_gateway_app'
  const password = values.GUGU_MYSQL_APP_PASSWORD || ''
  const host = values.GUGU_MYSQL_HOST || '127.0.0.1'
  const port = values.GUGU_MYSQL_PORT || '3306'
  const url = new URL('mysql://localhost')
  url.username = user
  url.password = password
  url.hostname = host
  url.port = port
  url.pathname = `/${database}`
  return url.toString()
}

function stripOptionalQuotes(value: string): string {
  if (
    (value.startsWith('"') && value.endsWith('"')) ||
    (value.startsWith("'") && value.endsWith("'"))
  ) {
    return value.slice(1, -1)
  }
  return value
}

function assertNightWindow(): void {
  const hour = new Date().getHours()
  if (hour >= 7 && hour < 23) {
    throw new Error('Refusing daytime rehearsal. Run at night or pass --allow-daytime intentionally.')
  }
}

function assertReadableFile(filePath: string, label: string): void {
  const stat = fs.statSync(filePath, { throwIfNoEntry: false })
  if (!stat?.isFile()) {
    throw new Error(`${label} not found: ${filePath}`)
  }
}

function assertIdentifier(value: string, label: string): void {
  if (!/^[A-Za-z0-9_]+$/.test(value)) {
    throw new Error(`${label} must contain only letters, numbers, and underscores: ${value}`)
  }
}

function resolveBunCommand(): string {
  const base = path.basename(process.execPath).replace(/\.exe$/i, '')
  return base === 'bun' ? process.execPath : 'bun'
}

function firstExistingPath(paths: string[]): string {
  return paths.find((candidate) => fs.existsSync(candidate)) || paths[0]
}

function readArg(name: string, fallback: string): string {
  const index = args.indexOf(name)
  if (index === -1) return fallback
  return args[index + 1] ?? fallback
}

function hasFlag(name: string): boolean {
  return args.includes(name)
}

function formatTimestamp(date: Date): string {
  const pad = (value: number) => String(value).padStart(2, '0')
  return [
    date.getFullYear(),
    pad(date.getMonth() + 1),
    pad(date.getDate()),
    '-',
    pad(date.getHours()),
    pad(date.getMinutes()),
    pad(date.getSeconds()),
  ].join('')
}

function quoteIdentifier(value: string): string {
  return `\`${value.replace(/`/g, '``')}\``
}

function logStep(message: string): void {
  console.log(`\n==> ${message}`)
}

function formatError(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

function printHelp(): void {
  console.log(`
Usage:
  bun run scripts/mysql-cutover-rehearsal.ts --plan-only
  bun run scripts/mysql-cutover-rehearsal.ts --confirm ${REHEARSAL_CONFIRMATION}
  bun run scripts/mysql-cutover-rehearsal.ts --commit-mysql --rehearsal-db gugu_gateway --confirm ${CUTOVER_CONFIRMATION}

This script rehearses switching the frozen gateway from SQLite to a MySQL
rehearsal database and then always restores the original gateway env.
With --commit-mysql it imports into the selected MySQL database, switches the
gateway to MySQL, opens writes, and keeps the gateway on MySQL.

Important options:
  --env-file PATH           Gateway env file. Defaults to current production paths.
  --mysql-env-file PATH     MySQL credential env file. Defaults to /etc/gugu-gateway/mysql.env.
  --db PATH                 SQLite source database. Defaults to /var/lib/gugu-gateway/gateway.sqlite.
  --backup-dir PATH         Artifact and backup directory. Defaults to /var/backups/gugu-gateway.
  --rehearsal-db NAME       MySQL database to reset/import. Defaults to gugu_gateway_dryrun.
  --allow-daytime           Override the night-window guard.
  --skip-service            Do not restart systemd or probe HTTP endpoints.
`)
}

main().catch((error) => {
  console.error(formatError(error))
  process.exit(1)
})
