import mysql from 'mysql2/promise'
import type { Connection, FieldPacket, RowDataPacket } from 'mysql2/promise'
import * as crypto from 'node:crypto'
import * as fs from 'node:fs'
import * as fsp from 'node:fs/promises'
import * as path from 'node:path'
import { loadGatewayConfig } from '../src/config.js'

const args = process.argv.slice(2)
const REQUIRED_TABLES = [
  'devices',
  'activation_codes',
  'usage_events',
  'orders',
  'payment_notifications',
]

type CountRow = RowDataPacket & {
  value: number
}

type DumpMethod = 'auto' | 'mysqldump' | 'js'

async function main(): Promise<void> {
  if (hasFlag('--help') || hasFlag('-h')) {
    printHelp()
    return
  }

  loadEnvFile(readArg('--env-file', ''))
  const config = loadGatewayConfig()
  const mysqlUrl = readArg('--mysql-url', config.mysqlUrl)
  const backupDir = path.resolve(readArg(
    '--out-dir',
    process.env.GUGU_GATEWAY_BACKUP_DIR?.trim() || '/var/backups/gugu-gateway',
  ))
  const retentionDays = readPositiveIntArg(
    '--retention-days',
    readPositiveIntEnv('GUGU_GATEWAY_BACKUP_RETENTION_DAYS', 7),
  )
  const mysqldumpBin = readArg('--mysqldump-bin', process.env.MYSQLDUMP_BIN?.trim() || 'mysqldump')
  const dumpMethod = readDumpMethod(readArg(
    '--dump-method',
    process.env.GUGU_MYSQL_BACKUP_METHOD?.trim() || 'auto',
  ))
  const shouldPrune = !hasFlag('--no-prune')

  if (!mysqlUrl) {
    throw new Error('GUGU_MYSQL_URL is required. Pass --mysql-url or --env-file.')
  }

  const target = parseMysqlUrl(mysqlUrl)
  await fsp.mkdir(backupDir, { recursive: true, mode: 0o700 })

  const timestamp = formatTimestamp(new Date())
  const backupPath = path.join(backupDir, `gateway-mysql-${timestamp}.sql`)
  const tmpPath = `${backupPath}.tmp.${process.pid}`
  const manifestPath = `${backupPath}.manifest.json`
  const sha256Path = `${backupPath}.sha256`

  await fsp.rm(tmpPath, { force: true }).catch(() => {})

  const tableCounts = await readTableCounts(mysqlUrl)
  const actualDumpMethod = await createDump({
    mysql: target,
    mysqlUrl,
    dumpMethod,
    mysqldumpBin,
    outputPath: tmpPath,
  })
  const dumpBytes = fs.statSync(tmpPath).size
  if (dumpBytes <= 0) {
    await fsp.rm(tmpPath, { force: true }).catch(() => {})
    throw new Error('mysqldump produced an empty file')
  }

  const sha256 = await hashFile(tmpPath)
  await fsp.rename(tmpPath, backupPath)

  const manifest = {
    ok: true,
    createdAt: new Date().toISOString(),
    database: target.database,
    backupPath,
    bytes: dumpBytes,
    sha256,
    dumpMethod: actualDumpMethod,
    tableCounts,
    retentionDays,
  }
  await fsp.writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, { mode: 0o600 })
  await fsp.writeFile(sha256Path, `${sha256}  ${backupPath}\n`, { mode: 0o600 })

  const pruned = shouldPrune
    ? await pruneOldBackups(backupDir, retentionDays, backupPath)
    : []

  console.log(JSON.stringify({
    ...manifest,
    manifestPath,
    sha256Path,
    pruned,
  }, null, 2))
}

async function createDump(input: {
  mysql: ParsedMysqlUrl
  mysqlUrl: string
  dumpMethod: DumpMethod
  mysqldumpBin: string
  outputPath: string
}): Promise<'mysqldump' | 'js'> {
  if (input.dumpMethod === 'js') {
    await createJsDump(input.mysqlUrl, input.mysql.database, input.outputPath)
    return 'js'
  }
  try {
    await runMysqlDump({
      mysql: input.mysql,
      mysqldumpBin: input.mysqldumpBin,
      outputPath: input.outputPath,
    })
    return 'mysqldump'
  } catch (error) {
    if (input.dumpMethod === 'mysqldump') throw error
    console.error(`mysqldump failed, falling back to JS logical dump: ${error instanceof Error ? error.message : String(error)}`)
    await createJsDump(input.mysqlUrl, input.mysql.database, input.outputPath)
    return 'js'
  }
}

async function readTableCounts(mysqlUrl: string): Promise<Record<string, number>> {
  const conn = await mysql.createConnection({ uri: mysqlUrl })
  try {
    await conn.ping()
    const counts: Record<string, number> = {}
    for (const table of REQUIRED_TABLES) {
      const [rows] = await conn.query<CountRow[]>(`SELECT COUNT(*) AS value FROM \`${table}\``)
      counts[table] = Number(rows[0]?.value ?? 0)
    }
    return counts
  } finally {
    await conn.end()
  }
}

async function createJsDump(mysqlUrl: string, database: string, outputPath: string): Promise<void> {
  const conn = await mysql.createConnection({ uri: mysqlUrl, dateStrings: true })
  try {
    await conn.query('SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ')
    await conn.query('START TRANSACTION WITH CONSISTENT SNAPSHOT')
    const [tableRows] = await conn.query<RowDataPacket[]>(
      `SELECT table_name AS name
       FROM information_schema.tables
       WHERE table_schema = DATABASE() AND table_type = 'BASE TABLE'
       ORDER BY table_name`,
    )
    const tables = tableRows.map((row) => String(row.name)).filter(Boolean)
    await fsp.writeFile(outputPath, [
      `-- Gugu Gateway MySQL logical backup`,
      `-- Created at ${new Date().toISOString()}`,
      `-- Database ${database}`,
      'SET NAMES utf8mb4;',
      'SET FOREIGN_KEY_CHECKS=0;',
      'START TRANSACTION;',
      '',
    ].join('\n'), { mode: 0o600 })

    for (const table of tables) {
      const [createRows] = await conn.query<RowDataPacket[]>(`SHOW CREATE TABLE ${quoteIdentifier(table)}`)
      const createSql = String(createRows[0]?.['Create Table'] ?? '')
      if (!createSql) {
        throw new Error(`Could not read CREATE TABLE for ${table}`)
      }
      await appendDump(outputPath, [
        '',
        `DROP TABLE IF EXISTS ${quoteIdentifier(table)};`,
        `${createSql};`,
      ].join('\n'))

      const orderBy = await tableHasColumn(conn, table, 'id') ? ' ORDER BY `id`' : ''
      const [rows, fields] = await conn.query<RowDataPacket[]>(
        `SELECT * FROM ${quoteIdentifier(table)}${orderBy}`,
      )
      await appendRows(outputPath, table, rows, fields)
    }

    await appendDump(outputPath, '\nSET FOREIGN_KEY_CHECKS=1;\nCOMMIT;\n')
    await conn.query('COMMIT')
  } catch (error) {
    await conn.query('ROLLBACK').catch(() => {})
    throw error
  } finally {
    await conn.end()
  }
}

async function appendRows(
  outputPath: string,
  table: string,
  rows: RowDataPacket[],
  fields: FieldPacket[],
): Promise<void> {
  if (rows.length === 0) return
  const columns = fields.map((field) => field.name)
  const columnSql = columns.map(quoteIdentifier).join(', ')
  const batchSize = 100
  for (let index = 0; index < rows.length; index += batchSize) {
    const batch = rows.slice(index, index + batchSize)
    const valuesSql = batch
      .map((row) => `(${columns.map((column) => sqlLiteral(row[column])).join(', ')})`)
      .join(',\n')
    await appendDump(outputPath, `\nINSERT INTO ${quoteIdentifier(table)} (${columnSql}) VALUES\n${valuesSql};\n`)
  }
}

async function tableHasColumn(conn: Connection, table: string, column: string): Promise<boolean> {
  const [rows] = await conn.query<RowDataPacket[]>(
    `SELECT COUNT(*) AS value
     FROM information_schema.columns
     WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?`,
    [table, column],
  )
  return Number(rows[0]?.value ?? 0) > 0
}

async function appendDump(outputPath: string, content: string): Promise<void> {
  await fsp.appendFile(outputPath, `${content}\n`)
}

function quoteIdentifier(value: string): string {
  return `\`${value.replace(/`/g, '``')}\``
}

function sqlLiteral(value: unknown): string {
  if (value === null || value === undefined) return 'NULL'
  if (typeof value === 'number') return Number.isFinite(value) ? String(value) : 'NULL'
  if (typeof value === 'bigint') return String(value)
  if (typeof value === 'boolean') return value ? '1' : '0'
  if (Buffer.isBuffer(value)) return `X'${value.toString('hex')}'`
  return `'${String(value)
    .replace(/\\/g, '\\\\')
    .replace(/\0/g, '\\0')
    .replace(/\n/g, '\\n')
    .replace(/\r/g, '\\r')
    .replace(/\x1a/g, '\\Z')
    .replace(/'/g, "''")}'`
}

async function runMysqlDump(input: {
  mysql: ParsedMysqlUrl
  mysqldumpBin: string
  outputPath: string
}): Promise<void> {
  const proc = Bun.spawn([
    input.mysqldumpBin,
    `--host=${assertArgumentValue(input.mysql.host, 'host')}`,
    `--port=${input.mysql.port}`,
    `--user=${assertArgumentValue(input.mysql.user, 'user')}`,
    '--single-transaction',
    '--quick',
    '--routines',
    '--triggers',
    '--events',
    '--hex-blob',
    '--no-tablespaces',
    `--result-file=${input.outputPath}`,
    input.mysql.database,
  ], {
    env: {
      ...process.env,
      MYSQL_PWD: input.mysql.password,
    },
    stdout: 'pipe',
    stderr: 'pipe',
  })
  const [stdout, stderr, exitCode] = await Promise.all([
    new Response(proc.stdout).text(),
    new Response(proc.stderr).text(),
    proc.exited,
  ])
  if (exitCode !== 0) {
    throw new Error(`mysqldump failed with code ${exitCode}: ${stderr.trim() || stdout.trim()}`)
  }
}

type ParsedMysqlUrl = {
  host: string
  port: number
  user: string
  password: string
  database: string
}

function parseMysqlUrl(mysqlUrl: string): ParsedMysqlUrl {
  const prefix = 'mysql://'
  if (!mysqlUrl.startsWith(prefix)) {
    throw new Error('Unsupported MySQL URL protocol. Expected mysql://')
  }
  const authAndTarget = mysqlUrl.slice(prefix.length)
  const atIndex = authAndTarget.lastIndexOf('@')
  if (atIndex <= 0) {
    throw new Error('MySQL URL must include user credentials')
  }
  const auth = authAndTarget.slice(0, atIndex)
  const target = authAndTarget.slice(atIndex + 1)
  const authColonIndex = auth.indexOf(':')
  if (authColonIndex <= 0) {
    throw new Error('MySQL URL must include a user and password')
  }

  const slashIndex = target.indexOf('/')
  if (slashIndex <= 0) {
    throw new Error('MySQL URL must include a host and database name')
  }
  const hostPort = target.slice(0, slashIndex)
  const pathAndQuery = target.slice(slashIndex + 1)
  const database = decodeUrlPart(pathAndQuery.split(/[?#]/)[0] || '')
  if (!database) {
    throw new Error('MySQL URL must include a database name')
  }
  const { host, port } = parseHostPort(hostPort)
  return {
    host,
    port,
    user: decodeUrlPart(auth.slice(0, authColonIndex)),
    password: decodeUrlPart(auth.slice(authColonIndex + 1)),
    database,
  }
}

function parseHostPort(value: string): { host: string; port: number } {
  if (value.startsWith('[')) {
    const end = value.indexOf(']')
    if (end === -1) throw new Error('Invalid IPv6 host in MySQL URL')
    const host = value.slice(1, end)
    const port = value.slice(end + 1).replace(/^:/, '')
    return { host, port: readPort(port) }
  }
  const colonIndex = value.lastIndexOf(':')
  if (colonIndex === -1) return { host: value || '127.0.0.1', port: 3306 }
  return {
    host: value.slice(0, colonIndex) || '127.0.0.1',
    port: readPort(value.slice(colonIndex + 1)),
  }
}

function readPort(value: string): number {
  const parsed = Number.parseInt(value || '3306', 10)
  if (!Number.isFinite(parsed) || parsed <= 0) {
    throw new Error(`Invalid MySQL port: ${value}`)
  }
  return parsed
}

function decodeUrlPart(value: string): string {
  try {
    return decodeURIComponent(value)
  } catch {
    return value
  }
}

function assertArgumentValue(value: string, label: string): string {
  if (/[\r\n]/.test(value)) {
    throw new Error(`MySQL ${label} must not contain newlines`)
  }
  return value
}

async function hashFile(filePath: string): Promise<string> {
  const hash = crypto.createHash('sha256')
  const stream = fs.createReadStream(filePath)
  for await (const chunk of stream) {
    hash.update(chunk)
  }
  return hash.digest('hex')
}

async function pruneOldBackups(
  backupDir: string,
  retentionDays: number,
  currentBackupPath: string,
): Promise<string[]> {
  const cutoff = Date.now() - retentionDays * 24 * 60 * 60 * 1000
  const entries = await fsp.readdir(backupDir, { withFileTypes: true }).catch(() => [])
  const currentPrefix = path.basename(currentBackupPath)
  const pruned: string[] = []
  for (const entry of entries) {
    if (!entry.isFile() || !/^gateway-mysql-\d{8}-\d{6}\.sql(\.manifest\.json|\.sha256)?$/.test(entry.name)) continue
    if (entry.name === currentPrefix || entry.name.startsWith(`${currentPrefix}.`)) continue
    const filePath = path.join(backupDir, entry.name)
    const stat = await fsp.stat(filePath).catch(() => null)
    if (!stat || stat.mtimeMs >= cutoff) continue
    await fsp.rm(filePath, { force: true })
    pruned.push(filePath)
  }
  return pruned
}

function loadEnvFile(filePath: string): void {
  if (!filePath) return
  const content = fs.readFileSync(filePath, 'utf8')
  for (const raw of content.split(/\r?\n/)) {
    const line = raw.trim()
    if (!line || line.startsWith('#')) continue
    const index = line.indexOf('=')
    if (index === -1) continue
    const key = line.slice(0, index)
    const value = stripOptionalQuotes(line.slice(index + 1).trim())
    process.env[key] = value
  }
}

function stripOptionalQuotes(value: string): string {
  if (
    (value.startsWith('"') && value.endsWith('"')) ||
    (value.startsWith("'") && value.endsWith("'"))
  ) {
    return value.slice(1, -1)
  }
  return value
}

function readArg(name: string, fallback: string): string {
  const index = args.indexOf(name)
  if (index === -1) return fallback
  return args[index + 1] ?? fallback
}

function readPositiveIntArg(name: string, fallback: number): number {
  const value = Number.parseInt(readArg(name, String(fallback)), 10)
  return Number.isFinite(value) && value > 0 ? Math.trunc(value) : fallback
}

function readPositiveIntEnv(name: string, fallback: number): number {
  const value = Number.parseInt(process.env[name]?.trim() || '', 10)
  return Number.isFinite(value) && value > 0 ? Math.trunc(value) : fallback
}

function readDumpMethod(value: string): DumpMethod {
  return value === 'mysqldump' || value === 'js' || value === 'auto' ? value : 'auto'
}

function hasFlag(name: string): boolean {
  return args.includes(name)
}

function formatTimestamp(date: Date): string {
  const pad = (value: number) => String(value).padStart(2, '0')
  return [
    date.getFullYear(),
    pad(date.getMonth() + 1),
    pad(date.getDate()),
    '-',
    pad(date.getHours()),
    pad(date.getMinutes()),
    pad(date.getSeconds()),
  ].join('')
}

function printHelp(): void {
  console.log(`
Usage:
  bun run scripts/mysql-backup.ts --env-file /root/opt/gugu/.env --out-dir /var/backups/gugu-gateway

Options:
  --env-file PATH       Load GUGU_MYSQL_URL from a gateway env file.
  --mysql-url URL       Override GUGU_MYSQL_URL.
  --out-dir PATH        Backup directory. Defaults to GUGU_GATEWAY_BACKUP_DIR or /var/backups/gugu-gateway.
  --retention-days N    Days to keep gateway-mysql-*.sql backups. Defaults to 7.
  --dump-method METHOD  auto, mysqldump, or js. Defaults to auto.
  --mysqldump-bin PATH  mysqldump executable. Defaults to mysqldump.
  --no-prune            Do not remove old MySQL backups.
`)
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error))
  process.exit(1)
})
