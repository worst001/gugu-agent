import { Database } from 'bun:sqlite'
import * as fs from 'node:fs'
import * as fsp from 'node:fs/promises'
import * as os from 'node:os'
import * as path from 'node:path'
import { loadGatewayConfig } from '../src/config.js'

const args = process.argv.slice(2)

async function main(): Promise<void> {
  const config = loadGatewayConfig()
  const dbPath = path.resolve(readArg('--db', config.dbPath))
  const backupDir = path.resolve(readArg(
    '--out-dir',
    process.env.GUGU_GATEWAY_BACKUP_DIR?.trim() || path.join(path.dirname(dbPath), 'backups'),
  ))
  const retentionDays = readPositiveIntArg(
    '--retention-days',
    readPositiveIntEnv('GUGU_GATEWAY_BACKUP_RETENTION_DAYS', 7),
  )
  const shouldPrune = !hasFlag('--no-prune')
  const shouldVerify = !hasFlag('--no-verify')

  assertReadableFile(dbPath)
  await fsp.mkdir(backupDir, { recursive: true })

  const timestamp = formatTimestamp(new Date())
  const backupPath = path.join(backupDir, `gateway-${timestamp}.sqlite`)
  const tmpPath = `${backupPath}.tmp.${process.pid}`

  await fsp.rm(tmpPath, { force: true }).catch(() => {})
  await createSqliteBackup(dbPath, tmpPath)

  let integrity = 'skipped'
  if (shouldVerify) {
    integrity = verifySqliteBackup(tmpPath)
    if (integrity !== 'ok') {
      await fsp.rm(tmpPath, { force: true }).catch(() => {})
      throw new Error(`Backup integrity_check failed: ${integrity}`)
    }
  }

  await fsp.rename(tmpPath, backupPath)
  const pruned = shouldPrune
    ? await pruneOldBackups(backupDir, retentionDays, backupPath)
    : []

  console.log(JSON.stringify({
    ok: true,
    dbPath,
    backupPath,
    bytes: fs.statSync(backupPath).size,
    integrity,
    retentionDays,
    pruned,
  }, null, 2))
}

async function createSqliteBackup(dbPath: string, backupPath: string): Promise<void> {
  const db = new Database(dbPath, { readonly: true })
  try {
    db.exec('PRAGMA busy_timeout = 10000')
    db.exec(`VACUUM main INTO ${sqliteStringLiteral(backupPath)}`)
  } finally {
    db.close()
  }
}

function verifySqliteBackup(backupPath: string): string {
  const db = new Database(backupPath, { readonly: true })
  try {
    const row = db.query('PRAGMA integrity_check').get() as Record<string, string> | null
    return Object.values(row ?? {})[0] ?? 'missing integrity_check result'
  } finally {
    db.close()
  }
}

async function pruneOldBackups(
  backupDir: string,
  retentionDays: number,
  currentBackupPath: string,
): Promise<string[]> {
  const cutoff = Date.now() - retentionDays * 24 * 60 * 60 * 1000
  const entries = await fsp.readdir(backupDir, { withFileTypes: true }).catch(() => [])
  const pruned: string[] = []
  for (const entry of entries) {
    if (!entry.isFile() || !/^gateway-\d{8}-\d{6}\.sqlite$/.test(entry.name)) continue
    const filePath = path.join(backupDir, entry.name)
    if (path.resolve(filePath) === path.resolve(currentBackupPath)) continue
    const stat = await fsp.stat(filePath).catch(() => null)
    if (!stat || stat.mtimeMs >= cutoff) continue
    await fsp.rm(filePath, { force: true })
    pruned.push(filePath)
  }
  return pruned
}

function assertReadableFile(filePath: string): void {
  const stat = fs.statSync(filePath, { throwIfNoEntry: false })
  if (!stat?.isFile()) {
    throw new Error(`SQLite database not found: ${filePath}`)
  }
}

function readArg(name: string, fallback: string): string {
  const index = args.indexOf(name)
  if (index === -1) return fallback
  return args[index + 1] ?? fallback
}

function readPositiveIntArg(name: string, fallback: number): number {
  const value = Number.parseInt(readArg(name, String(fallback)), 10)
  return Number.isFinite(value) && value > 0 ? Math.trunc(value) : fallback
}

function readPositiveIntEnv(name: string, fallback: number): number {
  const value = Number.parseInt(process.env[name]?.trim() || '', 10)
  return Number.isFinite(value) && value > 0 ? Math.trunc(value) : fallback
}

function hasFlag(name: string): boolean {
  return args.includes(name)
}

function formatTimestamp(date: Date): string {
  const pad = (value: number) => String(value).padStart(2, '0')
  return [
    date.getFullYear(),
    pad(date.getMonth() + 1),
    pad(date.getDate()),
    '-',
    pad(date.getHours()),
    pad(date.getMinutes()),
    pad(date.getSeconds()),
  ].join('')
}

function sqliteStringLiteral(value: string): string {
  return `'${value.replace(/'/g, "''")}'`
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error))
  process.exit(1)
})
