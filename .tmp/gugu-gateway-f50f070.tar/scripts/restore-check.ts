import { Database } from 'bun:sqlite'
import * as fs from 'node:fs'
import * as fsp from 'node:fs/promises'
import * as os from 'node:os'
import * as path from 'node:path'
import { loadGatewayConfig } from '../src/config.js'

const args = process.argv.slice(2)
const EXPECTED_TABLES = [
  'devices',
  'activation_codes',
  'usage_events',
  'orders',
  'payment_notifications',
] as const

async function main(): Promise<void> {
  const config = loadGatewayConfig()
  const backupPath = path.resolve(
    readArg('--backup', '') ||
    readArg('--file', '') ||
    await findLatestBackup(readArg(
      '--backup-dir',
      process.env.GUGU_GATEWAY_BACKUP_DIR?.trim() || path.join(path.dirname(config.dbPath), 'backups'),
    )),
  )
  const keepTemp = hasFlag('--keep-temp')

  assertReadableFile(backupPath)
  const tempDir = await fsp.mkdtemp(path.join(os.tmpdir(), 'gugu-gateway-restore-check-'))
  const restorePath = path.join(tempDir, 'gateway-restore-check.sqlite')

  try {
    await fsp.copyFile(backupPath, restorePath)
    const report = checkRestoredDatabase(restorePath)
    console.log(JSON.stringify({
      ok: report.integrity === 'ok' && report.foreignKeyViolations.length === 0 && report.missingTables.length === 0,
      backupPath,
      restorePath: keepTemp ? restorePath : null,
      checkedAt: new Date().toISOString(),
      ...report,
    }, null, 2))

    if (report.integrity !== 'ok' || report.foreignKeyViolations.length > 0 || report.missingTables.length > 0) {
      process.exitCode = 1
    }
  } finally {
    if (!keepTemp) {
      await fsp.rm(tempDir, { recursive: true, force: true }).catch(() => {})
    }
  }
}

function checkRestoredDatabase(dbPath: string): {
  integrity: string
  foreignKeyViolations: Array<Record<string, unknown>>
  missingTables: string[]
  tables: Record<string, number>
  fileBytes: number
} {
  const db = new Database(dbPath, { readonly: true })
  try {
    const integrityRow = db.query('PRAGMA integrity_check').get() as Record<string, string> | null
    const integrity = Object.values(integrityRow ?? {})[0] ?? 'missing integrity_check result'
    const foreignKeyViolations = db.query('PRAGMA foreign_key_check').all() as Array<Record<string, unknown>>
    const existingTables = new Set(
      (db.query("SELECT name FROM sqlite_master WHERE type = 'table'").all() as Array<{ name: string }>)
        .map((row) => row.name),
    )
    const missingTables = EXPECTED_TABLES.filter((table) => !existingTables.has(table))
    const tables: Record<string, number> = {}
    for (const table of EXPECTED_TABLES) {
      if (!existingTables.has(table)) continue
      const row = db.query(`SELECT COUNT(*) AS count FROM ${table}`).get() as { count: number }
      tables[table] = row.count
    }
    return {
      integrity,
      foreignKeyViolations,
      missingTables,
      tables,
      fileBytes: fs.statSync(dbPath).size,
    }
  } finally {
    db.close()
  }
}

async function findLatestBackup(backupDir: string): Promise<string> {
  const resolvedDir = path.resolve(backupDir)
  const entries = await fsp.readdir(resolvedDir, { withFileTypes: true }).catch(() => [])
  const backups: Array<{ path: string; mtimeMs: number }> = []
  for (const entry of entries) {
    if (!entry.isFile() || !/^gateway-\d{8}-\d{6}\.sqlite$/.test(entry.name)) continue
    const filePath = path.join(resolvedDir, entry.name)
    const stat = await fsp.stat(filePath).catch(() => null)
    if (stat) backups.push({ path: filePath, mtimeMs: stat.mtimeMs })
  }
  backups.sort((a, b) => b.mtimeMs - a.mtimeMs)
  const latest = backups[0]?.path
  if (!latest) {
    throw new Error(`No gateway backup found in ${resolvedDir}. Pass --backup <path> or run scripts/backup.ts first.`)
  }
  return latest
}

function assertReadableFile(filePath: string): void {
  const stat = fs.statSync(filePath, { throwIfNoEntry: false })
  if (!stat?.isFile()) {
    throw new Error(`Backup file not found: ${filePath}`)
  }
}

function readArg(name: string, fallback: string): string {
  const index = args.indexOf(name)
  if (index === -1) return fallback
  return args[index + 1] ?? fallback
}

function hasFlag(name: string): boolean {
  return args.includes(name)
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error))
  process.exit(1)
})
