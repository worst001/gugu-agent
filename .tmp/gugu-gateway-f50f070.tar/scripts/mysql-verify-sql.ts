import * as fs from 'node:fs'
import * as fsp from 'node:fs/promises'
import * as path from 'node:path'

const args = process.argv.slice(2)

type ManifestTable = {
  rows?: number
}

type ExportManifest = {
  generatedAt?: string
  outputPath?: string
  tables?: Record<string, ManifestTable>
  sourceTotals?: Record<string, number>
}

type CheckSpec = {
  name: string
  expected: number
  actualSql: string
}

const TABLES = [
  'devices',
  'activation_codes',
  'usage_events',
  'orders',
  'payment_notifications',
] as const

async function main(): Promise<void> {
  const manifestPath = path.resolve(readRequiredArg('--manifest'))
  const outPath = readArg('--out', '')
  const manifest = readManifest(manifestPath)
  const sql = buildVerificationSql(manifestPath, manifest)

  if (outPath) {
    const resolvedOut = path.resolve(outPath)
    await fsp.mkdir(path.dirname(resolvedOut), { recursive: true })
    await fsp.writeFile(resolvedOut, sql)
    console.log(JSON.stringify({
      ok: true,
      manifestPath,
      outputPath: resolvedOut,
      checks: buildChecks(manifest).length,
    }, null, 2))
    return
  }

  process.stdout.write(sql)
}

function readManifest(manifestPath: string): ExportManifest {
  const stat = fs.statSync(manifestPath, { throwIfNoEntry: false })
  if (!stat?.isFile()) {
    throw new Error(`Manifest file not found: ${manifestPath}`)
  }
  const parsed = JSON.parse(fs.readFileSync(manifestPath, 'utf8')) as ExportManifest
  if (!parsed.tables || !parsed.sourceTotals) {
    throw new Error(`Manifest is missing tables or sourceTotals: ${manifestPath}`)
  }
  return parsed
}

function buildVerificationSql(manifestPath: string, manifest: ExportManifest): string {
  const checks = buildChecks(manifest)
  const unionSql = checks
    .map((check) => [
      'SELECT',
      `  ${quoteString(check.name)} AS check_name,`,
      `  ${formatNumber(check.expected)} AS expected,`,
      `  (${check.actualSql}) AS actual`,
    ].join('\n'))
    .join('\nUNION ALL\n')

  return [
    '-- Gugu Gateway MySQL dry-run verification SQL.',
    `-- Manifest: ${manifestPath}`,
    manifest.generatedAt ? `-- Export generated at: ${manifest.generatedAt}` : null,
    manifest.outputPath ? `-- Import SQL: ${manifest.outputPath}` : null,
    '',
    "SET NAMES utf8mb4 COLLATE utf8mb4_0900_ai_ci;",
    "SET time_zone = '+00:00';",
    '',
    'WITH checks AS (',
    indent(unionSql, 2),
    ')',
    'SELECT',
    '  check_name,',
    '  expected,',
    '  actual,',
    "  CASE WHEN expected = actual THEN 'ok' ELSE 'mismatch' END AS result",
    'FROM checks',
    'ORDER BY result, check_name;',
    '',
    'WITH checks AS (',
    indent(unionSql, 2),
    ')',
    'SELECT',
    "  CASE WHEN SUM(CASE WHEN expected <> actual THEN 1 ELSE 0 END) = 0 THEN 'ok' ELSE 'mismatch' END AS verification_status,",
    '  SUM(CASE WHEN expected <> actual THEN 1 ELSE 0 END) AS mismatches,',
    '  COUNT(*) AS checks',
    'FROM checks;',
    '',
  ].filter((line): line is string => line !== null).join('\n')
}

function buildChecks(manifest: ExportManifest): CheckSpec[] {
  const checks: CheckSpec[] = []
  for (const table of TABLES) {
    checks.push({
      name: `table.${table}.rows`,
      expected: readTableRows(manifest, table),
      actualSql: `SELECT COUNT(*) FROM ${quoteIdentifier(table)}`,
    })
  }

  const totals = manifest.sourceTotals ?? {}
  checks.push(
    {
      name: 'total.devices.credits_total',
      expected: readTotal(totals, 'devicesCreditsTotal'),
      actualSql: 'SELECT COALESCE(SUM(credits_total), 0) FROM devices',
    },
    {
      name: 'total.devices.credits_remaining',
      expected: readTotal(totals, 'devicesCreditsRemaining'),
      actualSql: 'SELECT COALESCE(SUM(credits_remaining), 0) FROM devices',
    },
    {
      name: 'total.usage.credits',
      expected: readTotal(totals, 'usageCredits'),
      actualSql: 'SELECT COALESCE(SUM(credits), 0) FROM usage_events',
    },
    {
      name: 'total.usage.input_tokens',
      expected: readTotal(totals, 'usageInputTokens'),
      actualSql: 'SELECT COALESCE(SUM(input_tokens), 0) FROM usage_events',
    },
    {
      name: 'total.usage.output_tokens',
      expected: readTotal(totals, 'usageOutputTokens'),
      actualSql: 'SELECT COALESCE(SUM(output_tokens), 0) FROM usage_events',
    },
    {
      name: 'total.orders.amount_cents',
      expected: readTotal(totals, 'ordersAmountCents'),
      actualSql: 'SELECT COALESCE(SUM(amount_cents), 0) FROM orders',
    },
    {
      name: 'total.orders.paid_amount_cents',
      expected: readTotal(totals, 'ordersPaidAmountCents'),
      actualSql: 'SELECT COALESCE(SUM(paid_amount_cents), 0) FROM orders',
    },
    {
      name: 'constraint.devices.remaining_lte_total',
      expected: 0,
      actualSql: 'SELECT COUNT(*) FROM devices WHERE credits_remaining > credits_total',
    },
    {
      name: 'constraint.activation_counts.valid',
      expected: 0,
      actualSql: 'SELECT COUNT(*) FROM activation_codes WHERE activations > max_activations',
    },
    {
      name: 'constraint.usage.device_exists',
      expected: 0,
      actualSql: 'SELECT COUNT(*) FROM usage_events u LEFT JOIN devices d ON d.device_id = u.device_id WHERE d.device_id IS NULL',
    },
    {
      name: 'constraint.orders.fulfilled_has_license',
      expected: 0,
      actualSql: "SELECT COUNT(*) FROM orders WHERE status = 'fulfilled' AND (license_key IS NULL OR TRIM(license_key) = '')",
    },
    {
      name: 'constraint.orders.paid_amount_matches',
      expected: 0,
      actualSql: 'SELECT COUNT(*) FROM orders WHERE paid_amount_cents IS NOT NULL AND paid_amount_cents <> amount_cents',
    },
    {
      name: 'unique.orders.wechat_transaction_id',
      expected: 0,
      actualSql: "SELECT COUNT(*) FROM (SELECT wechat_transaction_id FROM orders WHERE wechat_transaction_id IS NOT NULL AND TRIM(wechat_transaction_id) <> '' GROUP BY wechat_transaction_id HAVING COUNT(*) > 1) duplicate_rows",
    },
    {
      name: 'unique.orders.alipay_trade_no',
      expected: 0,
      actualSql: "SELECT COUNT(*) FROM (SELECT alipay_trade_no FROM orders WHERE alipay_trade_no IS NOT NULL AND TRIM(alipay_trade_no) <> '' GROUP BY alipay_trade_no HAVING COUNT(*) > 1) duplicate_rows",
    },
    {
      name: 'unique.payment_notifications.provider_notification_id',
      expected: 0,
      actualSql: 'SELECT COUNT(*) FROM (SELECT provider, notification_id FROM payment_notifications GROUP BY provider, notification_id HAVING COUNT(*) > 1) duplicate_rows',
    },
  )

  return checks
}

function readTableRows(manifest: ExportManifest, table: string): number {
  const rows = manifest.tables?.[table]?.rows
  if (!Number.isFinite(rows)) {
    throw new Error(`Manifest is missing row count for table ${table}`)
  }
  return Number(rows)
}

function readTotal(totals: Record<string, number>, key: string): number {
  const value = totals[key]
  if (!Number.isFinite(value)) {
    throw new Error(`Manifest is missing source total ${key}`)
  }
  return Number(value)
}

function formatNumber(value: number): string {
  if (!Number.isFinite(value)) {
    throw new Error(`Cannot render non-numeric expected value: ${String(value)}`)
  }
  return String(Math.trunc(value))
}

function quoteString(value: string): string {
  return `'${value.replace(/\\/g, '\\\\').replace(/'/g, "''")}'`
}

function quoteIdentifier(value: string): string {
  return `\`${value.replace(/`/g, '``')}\``
}

function indent(value: string, spaces: number): string {
  const prefix = ' '.repeat(spaces)
  return value.split('\n').map((line) => `${prefix}${line}`).join('\n')
}

function readRequiredArg(name: string): string {
  const value = readArg(name, '')
  if (!value) {
    throw new Error(`Missing required argument ${name}`)
  }
  return value
}

function readArg(name: string, fallback: string): string {
  const index = args.indexOf(name)
  if (index === -1) return fallback
  return args[index + 1] ?? fallback
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error))
  process.exit(1)
})
