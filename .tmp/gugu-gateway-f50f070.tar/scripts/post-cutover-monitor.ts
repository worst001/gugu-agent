import mysql from 'mysql2/promise'
import type { Connection, RowDataPacket } from 'mysql2/promise'
import * as fs from 'node:fs'
import { loadGatewayConfig } from '../src/config.js'

const args = process.argv.slice(2)

type MonitorIssue = {
  severity: 'error' | 'warning'
  code: string
  message: string
  count?: number
}

type ScalarRow = RowDataPacket & {
  value: number | string | null
}

type GroupRow = RowDataPacket & {
  name: string | null
  status: string | null
  count: number
}

async function main(): Promise<void> {
  if (hasFlag('--help') || hasFlag('-h')) {
    printHelp()
    return
  }

  loadEnvFile(readArg('--env-file', ''))
  const config = loadGatewayConfig()
  const mysqlUrl = readArg('--mysql-url', config.mysqlUrl)
  const healthUrl = readArg('--health-url', process.env.GUGU_GATEWAY_HEALTH_URL || 'http://127.0.0.1:18787/health')
  const hours = readPositiveIntArg('--hours', 24)
  const recentLimit = readPositiveIntArg('--recent', 12)

  if (!mysqlUrl) {
    throw new Error('GUGU_MYSQL_URL is required. Pass --mysql-url or --env-file.')
  }

  const since = new Date(Date.now() - hours * 60 * 60 * 1000)
  const issues: MonitorIssue[] = []
  const health = await checkHealth(healthUrl)
  if (!health.ok) {
    issues.push({
      severity: 'error',
      code: 'HEALTH_FAILED',
      message: `Gateway health check failed: ${health.status ?? 'network error'} ${health.error ?? ''}`.trim(),
    })
  }

  const conn = await mysql.createConnection({ uri: mysqlUrl, dateStrings: true })
  try {
    await conn.ping()

    const [orderStatus] = await conn.query<GroupRow[]>(
      `SELECT COALESCE(payment_provider, 'none') AS name, status, COUNT(*) AS count
       FROM orders
       WHERE created_at >= ?
       GROUP BY COALESCE(payment_provider, 'none'), status
       ORDER BY name, status`,
      [toMysqlDateTime(since)],
    )
    const [notificationStatus] = await conn.query<GroupRow[]>(
      `SELECT provider AS name, status, COUNT(*) AS count
       FROM payment_notifications
       WHERE created_at >= ?
       GROUP BY provider, status
       ORDER BY provider, status`,
      [toMysqlDateTime(since)],
    )
    const [recentOrders] = await conn.query(
      `SELECT order_id, payment_provider, status,
              CASE WHEN license_key IS NULL OR TRIM(license_key) = '' THEN 'missing' ELSE 'present' END AS license,
              amount_cents, paid_amount_cents, created_at, paid_at, fulfilled_at
       FROM orders
       ORDER BY id DESC
       LIMIT ?`,
      [recentLimit],
    )
    const [recentNotifications] = await conn.query(
      `SELECT provider, status, order_id,
              CASE WHEN transaction_id IS NULL OR TRIM(transaction_id) = '' THEN 'missing' ELSE 'present' END AS transaction_id,
              processed_at, error_message
       FROM payment_notifications
       ORDER BY id DESC
       LIMIT ?`,
      [recentLimit],
    )

    await addCountIssue(conn, issues, {
      severity: 'error',
      code: 'FULFILLED_WITHOUT_LICENSE',
      message: 'Fulfilled orders without license_key.',
      sql: "SELECT COUNT(*) AS value FROM orders WHERE status = 'fulfilled' AND (license_key IS NULL OR TRIM(license_key) = '')",
    })
    await addCountIssue(conn, issues, {
      severity: 'error',
      code: 'PAID_AMOUNT_MISMATCH',
      message: 'Paid orders with paid_amount_cents different from amount_cents.',
      sql: "SELECT COUNT(*) AS value FROM orders WHERE paid_amount_cents IS NOT NULL AND paid_amount_cents <> amount_cents",
    })
    await addCountIssue(conn, issues, {
      severity: 'error',
      code: 'FAILED_PAYMENT_NOTIFICATIONS',
      message: `Failed payment notifications in the last ${hours} hours.`,
      sql: "SELECT COUNT(*) AS value FROM payment_notifications WHERE created_at >= ? AND status = 'failed'",
      params: [toMysqlDateTime(since)],
    })
    await addCountIssue(conn, issues, {
      severity: 'warning',
      code: 'PAID_NOT_FULFILLED',
      message: 'Orders marked paid but not fulfilled.',
      sql: "SELECT COUNT(*) AS value FROM orders WHERE status = 'paid'",
    })
    await addCountIssue(conn, issues, {
      severity: 'warning',
      code: 'PROCESSED_NOTIFICATION_WITHOUT_TX',
      message: 'Processed payment notifications without transaction_id.',
      sql: "SELECT COUNT(*) AS value FROM payment_notifications WHERE status = 'processed' AND (transaction_id IS NULL OR TRIM(transaction_id) = '')",
    })

    const errorCount = issues.filter((issue) => issue.severity === 'error').length
    console.log(JSON.stringify({
      ok: errorCount === 0,
      checkedAt: new Date().toISOString(),
      windowHours: hours,
      health,
      orderStatus,
      notificationStatus,
      recentOrders,
      recentNotifications,
      issues,
    }, null, 2))
    if (errorCount > 0) process.exitCode = 1
  } finally {
    await conn.end()
  }
}

async function addCountIssue(
  conn: Connection,
  issues: MonitorIssue[],
  input: {
    severity: 'error' | 'warning'
    code: string
    message: string
    sql: string
    params?: unknown[]
  },
): Promise<void> {
  const [rows] = await conn.query<ScalarRow[]>(input.sql, input.params ?? [])
  const count = Number(rows[0]?.value ?? 0)
  if (count <= 0) return
  issues.push({
    severity: input.severity,
    code: input.code,
    message: input.message,
    count,
  })
}

async function checkHealth(url: string): Promise<{
  ok: boolean
  url: string
  status?: number
  body?: string
  error?: string
}> {
  try {
    const response = await fetch(url)
    const body = await response.text()
    return {
      ok: response.ok,
      url,
      status: response.status,
      body: body.slice(0, 200),
    }
  } catch (error) {
    return {
      ok: false,
      url,
      error: error instanceof Error ? error.message : String(error),
    }
  }
}

function loadEnvFile(filePath: string): void {
  if (!filePath) return
  const content = fs.readFileSync(filePath, 'utf8')
  for (const raw of content.split(/\r?\n/)) {
    const line = raw.trim()
    if (!line || line.startsWith('#')) continue
    const index = line.indexOf('=')
    if (index === -1) continue
    const key = line.slice(0, index)
    const value = stripOptionalQuotes(line.slice(index + 1).trim())
    process.env[key] = value
  }
}

function stripOptionalQuotes(value: string): string {
  if (
    (value.startsWith('"') && value.endsWith('"')) ||
    (value.startsWith("'") && value.endsWith("'"))
  ) {
    return value.slice(1, -1)
  }
  return value
}

function toMysqlDateTime(date: Date): string {
  return date.toISOString().slice(0, 19).replace('T', ' ')
}

function readArg(name: string, fallback: string): string {
  const index = args.indexOf(name)
  if (index === -1) return fallback
  return args[index + 1] ?? fallback
}

function readPositiveIntArg(name: string, fallback: number): number {
  const value = Number.parseInt(readArg(name, String(fallback)), 10)
  return Number.isFinite(value) && value > 0 ? Math.trunc(value) : fallback
}

function hasFlag(name: string): boolean {
  return args.includes(name)
}

function printHelp(): void {
  console.log(`
Usage:
  bun run scripts/post-cutover-monitor.ts --env-file /root/opt/gugu/.env

Options:
  --env-file PATH       Load GUGU_MYSQL_URL from a gateway env file.
  --mysql-url URL       Override GUGU_MYSQL_URL.
  --health-url URL      Gateway health endpoint. Defaults to local production.
  --hours N             Reporting window. Defaults to 24.
  --recent N            Number of recent orders/notifications to show. Defaults to 12.
`)
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error))
  process.exit(1)
})
