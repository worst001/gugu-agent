import * as net from 'node:net'
import type { GatewayConfig } from './types.js'

export type RateLimitResult = {
  allowed: boolean
  retryAfterSeconds: number
  limitPerMinute: number
}

export type CircuitCheck = {
  allowed: boolean
  retryAfterMs: number
}

export type CircuitSnapshot = {
  label: string
  state: 'closed' | 'open' | 'half_open'
  consecutiveFailures: number
  retryAfterMs: number
  openedUntil: string | null
  halfOpenInFlight: boolean
  failureThreshold: number
  openMs: number
  backend: 'memory' | 'redis'
  fallbackActive: boolean
}

export type RateLimiterBackend = {
  consume(key: string, limitPerMinute: number): Promise<RateLimitResult>
}

export type CircuitBreakerBackend = {
  beforeRequest(): Promise<CircuitCheck>
  recordSuccess(): Promise<void>
  recordFailure(): Promise<void>
  snapshot(): CircuitSnapshot
}

type TokenBucket = {
  tokens: number
  updatedAt: number
}

export type RedisValue = string | number | null | RedisValue[]

export type RedisCommandClientLike = {
  eval(script: string, keys: string[], args: string[]): Promise<RedisValue>
  command(command: string[]): Promise<RedisValue>
}

const RATE_LIMIT_SCRIPT = `
local key = KEYS[1]
local capacity = tonumber(ARGV[1])
local refillPerMs = tonumber(ARGV[2])
local now = tonumber(ARGV[3])
local ttlMs = tonumber(ARGV[4])
local bucket = redis.call('HMGET', key, 'tokens', 'updatedAt')
local tokens = tonumber(bucket[1]) or capacity
local updatedAt = tonumber(bucket[2]) or now
local elapsedMs = math.max(0, now - updatedAt)
tokens = math.min(capacity, tokens + elapsedMs * refillPerMs)
local allowed = 0
if tokens >= 1 then
  tokens = tokens - 1
  allowed = 1
end
redis.call('HSET', key, 'tokens', tostring(tokens), 'updatedAt', tostring(now))
redis.call('PEXPIRE', key, ttlMs)
local retryAfterSeconds = 0
if allowed == 0 then
  retryAfterSeconds = math.max(1, math.ceil((1 - tokens) / refillPerMs / 1000))
end
return { allowed, retryAfterSeconds }
`

const CIRCUIT_BEFORE_SCRIPT = `
local stateKey = KEYS[1]
local halfOpenKey = KEYS[2]
local now = tonumber(ARGV[1])
local openMs = tonumber(ARGV[2])
local lockMs = tonumber(ARGV[3])
local openedUntil = tonumber(redis.call('HGET', stateKey, 'openedUntil') or '0')
local failures = tonumber(redis.call('HGET', stateKey, 'consecutiveFailures') or '0')
if openedUntil > now then
  return { 0, openedUntil - now, openedUntil, failures, 0 }
end
if openedUntil > 0 then
  local locked = redis.call('SET', halfOpenKey, '1', 'NX', 'PX', lockMs)
  if not locked then
    return { 0, math.max(1000, openMs), openedUntil, failures, 1 }
  end
  return { 1, 0, openedUntil, failures, 1 }
end
return { 1, 0, 0, failures, 0 }
`

const CIRCUIT_SUCCESS_SCRIPT = `
local stateKey = KEYS[1]
local halfOpenKey = KEYS[2]
local ttlMs = tonumber(ARGV[1])
redis.call('HSET', stateKey, 'consecutiveFailures', '0', 'openedUntil', '0')
redis.call('PEXPIRE', stateKey, ttlMs)
redis.call('DEL', halfOpenKey)
return { 1, 0, 0, 0, 0 }
`

const CIRCUIT_FAILURE_SCRIPT = `
local stateKey = KEYS[1]
local halfOpenKey = KEYS[2]
local now = tonumber(ARGV[1])
local threshold = tonumber(ARGV[2])
local openMs = tonumber(ARGV[3])
local ttlMs = tonumber(ARGV[4])
local failures = redis.call('HINCRBY', stateKey, 'consecutiveFailures', 1)
local openedUntil = tonumber(redis.call('HGET', stateKey, 'openedUntil') or '0')
local opened = 0
if failures >= threshold then
  openedUntil = now + openMs
  redis.call('HSET', stateKey, 'openedUntil', tostring(openedUntil))
  redis.call('DEL', halfOpenKey)
  opened = 1
end
redis.call('PEXPIRE', stateKey, ttlMs)
return { 1, 0, openedUntil, failures, 0, opened }
`

export function createRateLimiter(config: GatewayConfig): RateLimiterBackend {
  const memory = new InMemoryTokenBucketRateLimiter()
  if (!config.redisLimiterEnabled) return memory
  if (!config.redisUrl) {
    console.warn('[gugu-gateway] Redis limiter enabled but GUGU_REDIS_URL is empty; using in-memory limiter.')
    return memory
  }
  return new RedisTokenBucketRateLimiter(createRedisCommandClient(config), memory)
}

export function createCircuitBreaker(
  label: string,
  failureThreshold: number,
  openMs: number,
  config: GatewayConfig,
): CircuitBreakerBackend {
  const memory = new InMemoryCircuitBreaker(label, failureThreshold, openMs)
  if (!config.redisCircuitEnabled) return memory
  if (!config.redisUrl) {
    console.warn(`[gugu-gateway] Redis circuit enabled for ${label} but GUGU_REDIS_URL is empty; using in-memory circuit.`)
    return memory
  }
  return new RedisCircuitBreaker(label, failureThreshold, openMs, createRedisCommandClient(config), memory)
}

export function createRedisCommandClient(config: GatewayConfig): RedisCommandClientLike {
  return new RedisCommandClient(parseRedisUrl(config.redisUrl), config.redisCommandTimeoutMs)
}

export class InMemoryTokenBucketRateLimiter implements RateLimiterBackend {
  private buckets = new Map<string, TokenBucket>()
  private operations = 0

  async consume(key: string, limitPerMinute: number): Promise<RateLimitResult> {
    if (limitPerMinute <= 0) {
      return { allowed: true, retryAfterSeconds: 0, limitPerMinute }
    }

    const now = Date.now()
    const capacity = Math.max(1, limitPerMinute)
    const refillPerMs = limitPerMinute / 60_000
    const bucket = this.buckets.get(key) ?? { tokens: capacity, updatedAt: now }
    const elapsedMs = Math.max(0, now - bucket.updatedAt)
    bucket.tokens = Math.min(capacity, bucket.tokens + elapsedMs * refillPerMs)
    bucket.updatedAt = now

    if (bucket.tokens >= 1) {
      bucket.tokens -= 1
      this.buckets.set(key, bucket)
      this.pruneOccasionally(now)
      return { allowed: true, retryAfterSeconds: 0, limitPerMinute }
    }

    this.buckets.set(key, bucket)
    this.pruneOccasionally(now)
    const retryAfterSeconds = Math.max(1, Math.ceil((1 - bucket.tokens) / refillPerMs / 1000))
    return { allowed: false, retryAfterSeconds, limitPerMinute }
  }

  private pruneOccasionally(now: number): void {
    this.operations += 1
    if (this.operations % 500 !== 0) return
    for (const [key, bucket] of this.buckets) {
      if (now - bucket.updatedAt > 10 * 60_000) {
        this.buckets.delete(key)
      }
    }
  }
}

export class InMemoryCircuitBreaker implements CircuitBreakerBackend {
  private consecutiveFailures = 0
  private openedUntil = 0
  private halfOpenInFlight = false

  constructor(
    private readonly label: string,
    private readonly failureThreshold: number,
    private readonly openMs: number,
    private readonly fallbackActive = false,
  ) {}

  async beforeRequest(): Promise<CircuitCheck> {
    const now = Date.now()
    if (this.openedUntil > now) {
      return { allowed: false, retryAfterMs: this.openedUntil - now }
    }

    if (this.openedUntil > 0) {
      if (this.halfOpenInFlight) {
        return { allowed: false, retryAfterMs: Math.max(1_000, this.openMs) }
      }
      this.halfOpenInFlight = true
      return { allowed: true, retryAfterMs: 0 }
    }

    return { allowed: true, retryAfterMs: 0 }
  }

  async recordSuccess(): Promise<void> {
    this.consecutiveFailures = 0
    this.openedUntil = 0
    this.halfOpenInFlight = false
  }

  async recordFailure(): Promise<void> {
    this.halfOpenInFlight = false
    this.consecutiveFailures += 1
    if (this.consecutiveFailures >= this.failureThreshold) {
      this.openedUntil = Date.now() + this.openMs
      console.warn('[gugu-gateway] upstream circuit opened:', {
        upstream: this.label,
        failureThreshold: this.failureThreshold,
        openMs: this.openMs,
        backend: this.fallbackActive ? 'memory-fallback' : 'memory',
      })
    }
  }

  snapshot(): CircuitSnapshot {
    return circuitSnapshotFromState({
      label: this.label,
      failureThreshold: this.failureThreshold,
      openMs: this.openMs,
      consecutiveFailures: this.consecutiveFailures,
      openedUntil: this.openedUntil,
      halfOpenInFlight: this.halfOpenInFlight,
      backend: 'memory',
      fallbackActive: this.fallbackActive,
    })
  }
}

class RedisTokenBucketRateLimiter implements RateLimiterBackend {
  constructor(
    private readonly redis: RedisCommandClient,
    private readonly fallback: InMemoryTokenBucketRateLimiter,
  ) {}

  async consume(key: string, limitPerMinute: number): Promise<RateLimitResult> {
    if (limitPerMinute <= 0) {
      return { allowed: true, retryAfterSeconds: 0, limitPerMinute }
    }
    const capacity = Math.max(1, limitPerMinute)
    const refillPerMs = limitPerMinute / 60_000
    try {
      const result = await this.redis.eval(RATE_LIMIT_SCRIPT, [`gugu:ratelimit:${key}`], [
        String(capacity),
        String(refillPerMs),
        String(Date.now()),
        String(10 * 60_000),
      ])
      const values = expectArray(result)
      return {
        allowed: toNumber(values[0]) === 1,
        retryAfterSeconds: Math.max(0, toNumber(values[1])),
        limitPerMinute,
      }
    } catch (error) {
      console.warn('[gugu-gateway] Redis rate limiter failed; using in-memory fallback:', errorMessage(error))
      return this.fallback.consume(key, limitPerMinute)
    }
  }
}

class RedisCircuitBreaker implements CircuitBreakerBackend {
  private readonly fallbackCircuit: InMemoryCircuitBreaker
  private lastSnapshot: CircuitSnapshot

  constructor(
    private readonly label: string,
    private readonly failureThreshold: number,
    private readonly openMs: number,
    private readonly redis: RedisCommandClient,
    fallback: InMemoryCircuitBreaker,
  ) {
    this.fallbackCircuit = fallback
    this.lastSnapshot = circuitSnapshotFromState({
      label,
      failureThreshold,
      openMs,
      consecutiveFailures: 0,
      openedUntil: 0,
      halfOpenInFlight: false,
      backend: 'redis',
      fallbackActive: false,
    })
  }

  async beforeRequest(): Promise<CircuitCheck> {
    try {
      const result = await this.redis.eval(CIRCUIT_BEFORE_SCRIPT, this.keys(), [
        String(Date.now()),
        String(this.openMs),
        String(Math.max(1_000, this.openMs)),
      ])
      const values = expectArray(result)
      this.updateSnapshot(values, false)
      return {
        allowed: toNumber(values[0]) === 1,
        retryAfterMs: Math.max(0, toNumber(values[1])),
      }
    } catch (error) {
      return this.useFallback('beforeRequest', error)
    }
  }

  async recordSuccess(): Promise<void> {
    try {
      const result = await this.redis.eval(CIRCUIT_SUCCESS_SCRIPT, this.keys(), [String(this.ttlMs())])
      this.updateSnapshot(expectArray(result), false)
    } catch (error) {
      console.warn(`[gugu-gateway] Redis circuit success update failed for ${this.label}; using in-memory fallback:`, errorMessage(error))
      await this.fallbackCircuit.recordSuccess()
      this.lastSnapshot = this.fallbackCircuit.snapshot()
    }
  }

  async recordFailure(): Promise<void> {
    try {
      const result = await this.redis.eval(CIRCUIT_FAILURE_SCRIPT, this.keys(), [
        String(Date.now()),
        String(this.failureThreshold),
        String(this.openMs),
        String(this.ttlMs()),
      ])
      const values = expectArray(result)
      this.updateSnapshot(values, false)
      if (toNumber(values[5]) === 1) {
        console.warn('[gugu-gateway] upstream circuit opened:', {
          upstream: this.label,
          failureThreshold: this.failureThreshold,
          openMs: this.openMs,
          backend: 'redis',
        })
      }
    } catch (error) {
      console.warn(`[gugu-gateway] Redis circuit failure update failed for ${this.label}; using in-memory fallback:`, errorMessage(error))
      await this.fallbackCircuit.recordFailure()
      this.lastSnapshot = this.fallbackCircuit.snapshot()
    }
  }

  snapshot(): CircuitSnapshot {
    return this.lastSnapshot
  }

  private async useFallback(action: string, error: unknown): Promise<CircuitCheck> {
    console.warn(`[gugu-gateway] Redis circuit ${action} failed for ${this.label}; using in-memory fallback:`, errorMessage(error))
    const check = await this.fallbackCircuit.beforeRequest()
    this.lastSnapshot = this.fallbackCircuit.snapshot()
    return check
  }

  private updateSnapshot(values: RedisValue[], fallbackActive: boolean): void {
    this.lastSnapshot = circuitSnapshotFromState({
      label: this.label,
      failureThreshold: this.failureThreshold,
      openMs: this.openMs,
      consecutiveFailures: toNumber(values[3]),
      openedUntil: toNumber(values[2]),
      halfOpenInFlight: toNumber(values[4]) === 1,
      backend: 'redis',
      fallbackActive,
    })
  }

  private keys(): [string, string] {
    return [`gugu:circuit:${this.label}`, `gugu:circuit:${this.label}:half-open`]
  }

  private ttlMs(): number {
    return Math.max(60_000, this.openMs * 4)
  }
}

class RedisCommandClient {
  constructor(
    private readonly config: ParsedRedisUrl,
    private readonly timeoutMs: number,
  ) {}

  async eval(script: string, keys: string[], args: string[]): Promise<RedisValue> {
    return this.command(['EVAL', script, String(keys.length), ...keys, ...args])
  }

  async command(command: string[]): Promise<RedisValue> {
    const commands: string[][] = []
    if (this.config.password) {
      commands.push(this.config.username
        ? ['AUTH', this.config.username, this.config.password]
        : ['AUTH', this.config.password])
    }
    if (this.config.database > 0) {
      commands.push(['SELECT', String(this.config.database)])
    }
    commands.push(command)

    return new Promise<RedisValue>((resolve, reject) => {
      const socket = net.createConnection({ host: this.config.host, port: this.config.port })
      let buffer = Buffer.alloc(0)
      const responses: RedisValue[] = []
      let settled = false
      const timer = setTimeout(() => {
        fail(new Error(`Redis command timed out after ${this.timeoutMs}ms`))
      }, this.timeoutMs)

      const cleanup = () => {
        clearTimeout(timer)
        socket.removeAllListeners()
        socket.destroy()
      }
      const fail = (error: unknown) => {
        if (settled) return
        settled = true
        cleanup()
        reject(error)
      }
      const succeed = (value: RedisValue) => {
        if (settled) return
        settled = true
        cleanup()
        resolve(value)
      }

      socket.on('connect', () => {
        socket.write(Buffer.concat(commands.map(encodeRedisCommand)))
      })
      socket.on('data', (chunk) => {
        buffer = Buffer.concat([buffer, chunk])
        try {
          let offset = 0
          while (responses.length < commands.length) {
            const parsed = parseResp(buffer, offset)
            if (!parsed) break
            responses.push(parsed.value)
            offset = parsed.offset
          }
          if (offset > 0) buffer = buffer.subarray(offset)
          if (responses.length >= commands.length) {
            succeed(responses[responses.length - 1] ?? null)
          }
        } catch (error) {
          fail(error)
        }
      })
      socket.on('error', fail)
      socket.on('close', () => {
        if (!settled) fail(new Error('Redis connection closed before response'))
      })
    })
  }
}

type ParsedRedisUrl = {
  host: string
  port: number
  username: string
  password: string
  database: number
}

function parseRedisUrl(redisUrl: string): ParsedRedisUrl {
  const prefix = 'redis://'
  if (!redisUrl.startsWith(prefix)) {
    throw new Error('Unsupported Redis URL protocol. Expected redis://')
  }
  const authAndTarget = redisUrl.slice(prefix.length)
  const atIndex = authAndTarget.lastIndexOf('@')
  const auth = atIndex >= 0 ? authAndTarget.slice(0, atIndex) : ''
  const target = atIndex >= 0 ? authAndTarget.slice(atIndex + 1) : authAndTarget
  const slashIndex = target.indexOf('/')
  const hostPort = slashIndex >= 0 ? target.slice(0, slashIndex) : target
  const databaseRaw = slashIndex >= 0 ? target.slice(slashIndex + 1).split(/[?#]/)[0] : ''
  const { host, port } = parseHostPort(hostPort)
  const authColon = auth.indexOf(':')
  const username = auth && authColon > 0 ? decodeUrlPart(auth.slice(0, authColon)) : ''
  const password = auth
    ? decodeUrlPart(authColon >= 0 ? auth.slice(authColon + 1) : auth)
    : ''
  const database = Number.parseInt(databaseRaw || '0', 10)
  return {
    host,
    port,
    username,
    password,
    database: Number.isFinite(database) && database >= 0 ? database : 0,
  }
}

function parseHostPort(value: string): { host: string; port: number } {
  if (value.startsWith('[')) {
    const end = value.indexOf(']')
    if (end === -1) throw new Error('Invalid IPv6 host in Redis URL')
    const host = value.slice(1, end)
    const port = value.slice(end + 1).replace(/^:/, '')
    return { host, port: readPort(port, 6379) }
  }
  const colonIndex = value.lastIndexOf(':')
  if (colonIndex === -1) return { host: value || '127.0.0.1', port: 6379 }
  return {
    host: value.slice(0, colonIndex) || '127.0.0.1',
    port: readPort(value.slice(colonIndex + 1), 6379),
  }
}

function readPort(value: string, fallback: number): number {
  const parsed = Number.parseInt(value || String(fallback), 10)
  if (!Number.isFinite(parsed) || parsed <= 0) {
    throw new Error(`Invalid Redis port: ${value}`)
  }
  return parsed
}

function decodeUrlPart(value: string): string {
  try {
    return decodeURIComponent(value)
  } catch {
    return value
  }
}

function encodeRedisCommand(parts: string[]): Buffer {
  const buffers: Buffer[] = [Buffer.from(`*${parts.length}\r\n`)]
  for (const part of parts) {
    const bytes = Buffer.from(part)
    buffers.push(Buffer.from(`$${bytes.length}\r\n`), bytes, Buffer.from('\r\n'))
  }
  return Buffer.concat(buffers)
}

type RespParseResult = {
  value: RedisValue
  offset: number
}

function parseResp(buffer: Buffer, offset: number): RespParseResult | null {
  if (offset >= buffer.length) return null
  const prefix = String.fromCharCode(buffer[offset]!)
  if (prefix === '+' || prefix === '-' || prefix === ':') {
    const lineEnd = buffer.indexOf('\r\n', offset)
    if (lineEnd === -1) return null
    const line = buffer.toString('utf8', offset + 1, lineEnd)
    if (prefix === '-') throw new Error(`Redis error: ${line}`)
    return {
      value: prefix === ':' ? Number.parseInt(line, 10) : line,
      offset: lineEnd + 2,
    }
  }
  if (prefix === '$') {
    const lineEnd = buffer.indexOf('\r\n', offset)
    if (lineEnd === -1) return null
    const length = Number.parseInt(buffer.toString('utf8', offset + 1, lineEnd), 10)
    if (length === -1) return { value: null, offset: lineEnd + 2 }
    const start = lineEnd + 2
    const end = start + length
    if (buffer.length < end + 2) return null
    return {
      value: buffer.toString('utf8', start, end),
      offset: end + 2,
    }
  }
  if (prefix === '*') {
    const lineEnd = buffer.indexOf('\r\n', offset)
    if (lineEnd === -1) return null
    const length = Number.parseInt(buffer.toString('utf8', offset + 1, lineEnd), 10)
    if (length === -1) return { value: null, offset: lineEnd + 2 }
    const values: RedisValue[] = []
    let nextOffset = lineEnd + 2
    for (let index = 0; index < length; index += 1) {
      const parsed = parseResp(buffer, nextOffset)
      if (!parsed) return null
      values.push(parsed.value)
      nextOffset = parsed.offset
    }
    return { value: values, offset: nextOffset }
  }
  throw new Error(`Unsupported Redis response prefix: ${prefix}`)
}

function expectArray(value: RedisValue): RedisValue[] {
  if (!Array.isArray(value)) {
    throw new Error('Redis script returned a non-array response')
  }
  return value
}

function toNumber(value: RedisValue | undefined): number {
  if (typeof value === 'number') return Number.isFinite(value) ? value : 0
  if (typeof value === 'string') {
    const parsed = Number(value)
    return Number.isFinite(parsed) ? parsed : 0
  }
  return 0
}

function circuitSnapshotFromState(input: {
  label: string
  failureThreshold: number
  openMs: number
  consecutiveFailures: number
  openedUntil: number
  halfOpenInFlight: boolean
  backend: 'memory' | 'redis'
  fallbackActive: boolean
}): CircuitSnapshot {
  const now = Date.now()
  const isOpen = input.openedUntil > now
  const state = isOpen
    ? 'open'
    : input.openedUntil > 0 && input.halfOpenInFlight
      ? 'half_open'
      : 'closed'
  return {
    label: input.label,
    state,
    consecutiveFailures: input.consecutiveFailures,
    retryAfterMs: isOpen ? input.openedUntil - now : 0,
    openedUntil: isOpen ? new Date(input.openedUntil).toISOString() : null,
    halfOpenInFlight: input.halfOpenInFlight,
    failureThreshold: input.failureThreshold,
    openMs: input.openMs,
    backend: input.backend,
    fallbackActive: input.fallbackActive,
  }
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}
