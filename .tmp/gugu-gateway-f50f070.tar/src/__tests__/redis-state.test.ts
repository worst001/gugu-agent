import { describe, expect, test } from 'bun:test'
import { loadGatewayConfig } from '../config.js'
import {
  createCircuitBreaker,
  createRateLimiter,
  InMemoryCircuitBreaker,
  InMemoryTokenBucketRateLimiter,
} from '../redisState.js'
import type { GatewayConfig } from '../types.js'

describe('Redis-backed gateway state adapters', () => {
  test('keeps token bucket behavior for the in-memory limiter', async () => {
    const limiter = new InMemoryTokenBucketRateLimiter()

    expect(await limiter.consume('device:test', 1)).toMatchObject({
      allowed: true,
      limitPerMinute: 1,
    })

    const second = await limiter.consume('device:test', 1)
    expect(second.allowed).toBe(false)
    expect(second.retryAfterSeconds).toBeGreaterThan(0)
  })

  test('opens the in-memory circuit after the configured failure threshold', async () => {
    const circuit = new InMemoryCircuitBreaker('test-upstream', 1, 1_000)

    expect((await circuit.beforeRequest()).allowed).toBe(true)
    await circuit.recordFailure()

    const check = await circuit.beforeRequest()
    expect(check.allowed).toBe(false)
    expect(circuit.snapshot()).toMatchObject({
      state: 'open',
      backend: 'memory',
      fallbackActive: false,
    })
  })

  test('falls back to memory when Redis flags are enabled without a URL', async () => {
    const config = testConfig({
      redisLimiterEnabled: true,
      redisCircuitEnabled: true,
      redisUrl: '',
    })

    const limiter = createRateLimiter(config)
    expect((await limiter.consume('ip:test', 1)).allowed).toBe(true)
    expect((await limiter.consume('ip:test', 1)).allowed).toBe(false)

    const circuit = createCircuitBreaker('test-upstream', 1, 1_000, config)
    await circuit.recordFailure()
    expect(circuit.snapshot()).toMatchObject({
      state: 'open',
      backend: 'memory',
    })
  })
})

function testConfig(overrides: Partial<GatewayConfig>): GatewayConfig {
  return {
    ...loadGatewayConfig(),
    storeDriver: 'sqlite',
    mysqlUrl: '',
    redisUrl: '',
    redisLimiterEnabled: false,
    redisCircuitEnabled: false,
    redisAttachmentTasksEnabled: false,
    redisCommandTimeoutMs: 1_000,
    ...overrides,
  }
}
