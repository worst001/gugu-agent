import { afterEach, describe, expect, test } from 'bun:test'
import * as fs from 'node:fs/promises'
import * as os from 'node:os'
import * as path from 'node:path'
import { loadGatewayConfig } from '../config.js'
import { MysqlGatewayStore, MysqlGatewayStoreConfigError } from '../mysqlStore.js'
import { GatewayStore } from '../store.js'
import { createGatewayStorage } from '../storageFactory.js'

describe('Gateway storage factory', () => {
  const originalDbPath = process.env.GUGU_GATEWAY_DB_PATH
  const originalStoreDriver = process.env.GUGU_STORE_DRIVER
  const originalMysqlUrl = process.env.GUGU_MYSQL_URL
  let tmpDirs: string[] = []

  afterEach(async () => {
    restoreEnv('GUGU_GATEWAY_DB_PATH', originalDbPath)
    restoreEnv('GUGU_STORE_DRIVER', originalStoreDriver)
    restoreEnv('GUGU_MYSQL_URL', originalMysqlUrl)
    for (const tmpDir of tmpDirs) {
      await fs.rm(tmpDir, { recursive: true, force: true })
    }
    tmpDirs = []
  })

  test('uses SQLite storage by default', async () => {
    const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'gugu-storage-factory-'))
    tmpDirs.push(tmpDir)
    process.env.GUGU_GATEWAY_DB_PATH = path.join(tmpDir, 'gateway.sqlite')
    delete process.env.GUGU_STORE_DRIVER

    const config = loadGatewayConfig()
    const storage = createGatewayStorage(config)

    try {
      expect(config.storeDriver).toBe('sqlite')
      expect(storage).toBeInstanceOf(GatewayStore)
    } finally {
      await storage.close()
    }
  })

  test('constructs MySQL storage when the MySQL driver is explicitly selected', async () => {
    process.env.GUGU_STORE_DRIVER = 'mysql'
    process.env.GUGU_MYSQL_URL = 'mysql://gugu_gateway_app:secret@127.0.0.1:3306/gugu_gateway'

    const config = loadGatewayConfig()
    const storage = createGatewayStorage(config)

    try {
      expect(config.storeDriver).toBe('mysql')
      expect(config.mysqlUrl).toContain('gugu_gateway_app')
      expect(storage).toBeInstanceOf(MysqlGatewayStore)
    } finally {
      await storage.close()
    }
  })

  test('treats unknown store drivers as SQLite for conservative fallback', () => {
    process.env.GUGU_STORE_DRIVER = 'postgres'

    expect(loadGatewayConfig().storeDriver).toBe('sqlite')
  })

  test('requires a MySQL URL before constructing the MySQL store skeleton', () => {
    const config = {
      ...loadGatewayConfig(),
      storeDriver: 'mysql' as const,
      mysqlUrl: '',
    }

    expect(() => new MysqlGatewayStore(config)).toThrow(MysqlGatewayStoreConfigError)
  })
})

function restoreEnv(name: string, value: string | undefined): void {
  if (value === undefined) delete process.env[name]
  else process.env[name] = value
}
