import { test } from 'bun:test'
import { loadGatewayConfig } from '../config.js'
import { createGatewayStorage } from '../storageFactory.js'
import { registerGatewayStorageContract } from './storageContractSuite.js'

const mysqlUrl = process.env.GUGU_MYSQL_TEST_URL
const mysqlTest = mysqlUrl ? test : test.skip

registerGatewayStorageContract('MysqlGatewayStore storage contract', async () => {
  const originalStoreDriver = process.env.GUGU_STORE_DRIVER
  const originalMysqlUrl = process.env.GUGU_MYSQL_URL
  const originalFreeCredits = process.env.GUGU_FREE_CREDITS
  process.env.GUGU_STORE_DRIVER = 'mysql'
  process.env.GUGU_MYSQL_URL = mysqlUrl!
  process.env.GUGU_FREE_CREDITS = '5'

  return {
    storage: createGatewayStorage(loadGatewayConfig()),
    cleanup() {
      restoreEnv('GUGU_STORE_DRIVER', originalStoreDriver)
      restoreEnv('GUGU_MYSQL_URL', originalMysqlUrl)
      restoreEnv('GUGU_FREE_CREDITS', originalFreeCredits)
    },
  }
}, mysqlTest)

function restoreEnv(name: string, value: string | undefined): void {
  if (value === undefined) delete process.env[name]
  else process.env[name] = value
}
