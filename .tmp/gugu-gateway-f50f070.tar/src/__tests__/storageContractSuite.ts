import { describe, expect, test } from 'bun:test'
import {
  GatewayQuotaError,
  type GatewayStorage,
  type MaybePromise,
} from '../store.js'

type StorageContractInstance = {
  storage: GatewayStorage
  cleanup?: () => MaybePromise<void>
}

type CreateStorageContractInstance = () => MaybePromise<GatewayStorage | StorageContractInstance>

type ErrorClass = abstract new (...args: any[]) => Error

export function registerGatewayStorageContract(
  name: string,
  createStorage: CreateStorageContractInstance,
  testImpl: typeof test = test,
): void {
  describe(name, () => {
    testImpl('registers, activates, consumes, records usage, and refunds credits consistently', async () => {
      await withStorage(createStorage, async (storage, unique) => {
        const registered = await storage.registerDevice({
          deviceId: unique('device-contract'),
          appVersion: '0.1.16',
          platform: 'test',
        })
        const licenseKey = await storage.issueActivationCode({
          plan: 'pro',
          creditsTotal: 10,
          maxActivations: 1,
          licenseKey: unique('license').slice(0, 120),
        })

        const activated = await storage.activate(registered.deviceToken, licenseKey)
        const reservation = await storage.consumeUsage(
          registered.deviceToken,
          'message',
          'deepseek-v4-pro',
          2,
          { contract: true },
        )
        await storage.recordUsageTokens(reservation.usageEventId, {
          inputTokens: 11,
          outputTokens: 7,
        }, { upstreamStatus: 200 })
        const refunded = await storage.refundCredit(registered.deviceToken, 1)
        const events = await storage.listUsageEvents({
          deviceToken: registered.deviceToken,
          limit: 10,
        })

        expect(activated.plan).toBe('pro')
        expect(activated.creditsRemaining).toBe(10)
        expect(reservation.entitlement.creditsRemaining).toBe(8)
        expect(refunded.creditsRemaining).toBe(9)
        expect(events).toHaveLength(1)
        expect(events[0].credits).toBe(2)
        expect(events[0].inputTokens).toBe(11)
        expect(events[0].outputTokens).toBe(7)
        expect(JSON.parse(events[0].metadata || '{}')).toMatchObject({
          contract: true,
          upstreamStatus: 200,
        })
      })
    })

    testImpl('preserves order fulfillment and payment notification idempotency semantics', async () => {
      await withStorage(createStorage, async (storage, unique) => {
        const noticeId = unique('notice')
        const transactionId = unique('wx-tx')
        const order = await storage.createOrder({ packageId: 'pro-monthly', contact: `${unique('contract')}@example.com` })
        const orderToken = await storage.getOrderToken(order.orderId)
        const claim = await storage.beginPaymentNotification({
          provider: 'wechat',
          notificationId: noticeId,
          transactionId,
          orderId: order.orderId,
          payload: { ok: true },
        })
        const duplicateClaim = await storage.beginPaymentNotification({
          provider: 'wechat',
          notificationId: noticeId,
          transactionId,
          orderId: order.orderId,
          payload: { ok: true },
        })

        const fulfilled = await storage.completeWechatPayment({
          orderId: order.orderId,
          transactionId,
          tradeState: 'SUCCESS',
          successTime: '2026-05-27T00:00:00.000Z',
          amountCents: order.amountCents,
          payload: { ok: true },
        })
        await storage.markPaymentNotificationProcessed('wechat', claim.notificationId)
        const status = await storage.getOrderStatus(order.orderId, orderToken)

        expect(claim.alreadyProcessed).toBe(false)
        expect(duplicateClaim.alreadyProcessed).toBe(false)
        expect(fulfilled.status).toBe('fulfilled')
        expect(status.order.status).toBe('fulfilled')
        expect(status.licenseKey).toBeTruthy()
        expect(await storage.getPaymentNotificationStatus('wechat', noticeId)).toBe('processed')
      })
    })

    testImpl('keeps processed payment notifications terminal while allowing failed notifications to retry', async () => {
      await withStorage(createStorage, async (storage, unique) => {
        const noticeId = unique('notice-retry')
        const transactionId = unique('wx-tx-retry')
        const order = await storage.createOrder({ packageId: 'light-monthly' })
        const failedClaim = await storage.beginPaymentNotification({
          provider: 'wechat',
          notificationId: noticeId,
          transactionId,
          orderId: order.orderId,
          payload: { attempt: 1 },
        })
        await storage.markPaymentNotificationFailed('wechat', failedClaim.notificationId, 'temporary mismatch')
        const retryClaim = await storage.beginPaymentNotification({
          provider: 'wechat',
          notificationId: noticeId,
          transactionId,
          orderId: order.orderId,
          payload: { attempt: 2 },
        })
        await storage.markPaymentNotificationProcessed('wechat', retryClaim.notificationId)
        const processedClaim = await storage.beginPaymentNotification({
          provider: 'wechat',
          notificationId: noticeId,
          transactionId,
          orderId: order.orderId,
          payload: { attempt: 3 },
        })

        expect(failedClaim.alreadyProcessed).toBe(false)
        expect(retryClaim.alreadyProcessed).toBe(false)
        expect(processedClaim.alreadyProcessed).toBe(true)
        expect(await storage.getPaymentNotificationStatus('wechat', noticeId)).toBe('processed')
      })
    })

    testImpl('preserves the issued license and transaction id when the same order payment is replayed', async () => {
      await withStorage(createStorage, async (storage, unique) => {
        const transactionId = unique('wx-tx-replay-original')
        const order = await storage.createOrder({ packageId: 'max-monthly' })
        const first = await storage.completeWechatPayment({
          orderId: order.orderId,
          transactionId,
          tradeState: 'SUCCESS',
          successTime: '2026-05-27T01:00:00.000Z',
          amountCents: order.amountCents,
          payload: { replay: 1 },
        })
        const replay = await storage.completeWechatPayment({
          orderId: order.orderId,
          transactionId: unique('wx-tx-replay-different'),
          tradeState: 'SUCCESS',
          successTime: '2026-05-27T01:01:00.000Z',
          amountCents: order.amountCents,
          payload: { replay: 2 },
        })
        const status = await storage.getOrderStatus(order.orderId, await storage.getOrderToken(order.orderId))

        expect(first.status).toBe('fulfilled')
        expect(replay.status).toBe('fulfilled')
        expect(replay.licenseKey).toBe(first.licenseKey)
        expect(replay.wechatTransactionId).toBe(transactionId)
        expect(status.licenseKey).toBe(first.licenseKey)
      })
    })

    testImpl('rejects reused upstream transaction ids across different orders', async () => {
      await withStorage(createStorage, async (storage, unique) => {
        const wechatTransactionId = unique('wx-tx-contract-reused')
        const alipayTransactionId = unique('ali-tx-contract-reused')
        const firstOrder = await storage.createOrder({ packageId: 'pro-monthly' })
        const secondWechatOrder = await storage.createOrder({ packageId: 'pro-monthly' })
        const firstAlipayOrder = await storage.createOrder({ packageId: 'light-monthly' })
        const secondAlipayOrder = await storage.createOrder({ packageId: 'light-monthly' })

        await storage.completeWechatPayment({
          orderId: firstOrder.orderId,
          transactionId: wechatTransactionId,
          tradeState: 'SUCCESS',
          successTime: '2026-05-27T02:00:00.000Z',
          amountCents: firstOrder.amountCents,
          payload: { provider: 'wechat' },
        })
        await storage.completeAlipayPayment({
          orderId: firstAlipayOrder.orderId,
          transactionId: alipayTransactionId,
          tradeState: 'TRADE_SUCCESS',
          successTime: '2026-05-27T03:00:00.000Z',
          amountCents: firstAlipayOrder.amountCents,
          payload: { provider: 'alipay' },
        })

        await expectStorageError(() => storage.completeWechatPayment({
          orderId: secondWechatOrder.orderId,
          transactionId: wechatTransactionId,
          tradeState: 'SUCCESS',
          successTime: '2026-05-27T02:01:00.000Z',
          amountCents: secondWechatOrder.amountCents,
          payload: { provider: 'wechat' },
        }))
        await expectStorageError(() => storage.completeAlipayPayment({
          orderId: secondAlipayOrder.orderId,
          transactionId: alipayTransactionId,
          tradeState: 'TRADE_SUCCESS',
          successTime: '2026-05-27T03:01:00.000Z',
          amountCents: secondAlipayOrder.amountCents,
          payload: { provider: 'alipay' },
        }))

        expect((await storage.getOrderStatus(
          secondWechatOrder.orderId,
          await storage.getOrderToken(secondWechatOrder.orderId),
        )).order.status).toBe('pending_payment')
        expect((await storage.getOrderStatus(
          secondAlipayOrder.orderId,
          await storage.getOrderToken(secondAlipayOrder.orderId),
        )).order.status).toBe('pending_payment')
      })
    })

    testImpl('keeps cancelled and amount-mismatched orders unfulfilled', async () => {
      await withStorage(createStorage, async (storage, unique) => {
        const cancelled = await storage.createOrder({ packageId: 'light-monthly' })
        const wrongAmount = await storage.createOrder({ packageId: 'pro-monthly' })
        await storage.cancelOrder(cancelled.orderId)

        await expectStorageError(() => storage.completeWechatPayment({
          orderId: cancelled.orderId,
          transactionId: unique('wx-tx-cancelled'),
          tradeState: 'SUCCESS',
          successTime: '2026-05-27T04:00:00.000Z',
          amountCents: cancelled.amountCents,
          payload: { provider: 'wechat' },
        }), 'Order has been cancelled.')
        await expectStorageError(() => storage.completeAlipayPayment({
          orderId: wrongAmount.orderId,
          transactionId: unique('ali-tx-wrong-amount'),
          tradeState: 'TRADE_SUCCESS',
          successTime: '2026-05-27T04:01:00.000Z',
          amountCents: wrongAmount.amountCents + 1,
          payload: { provider: 'alipay' },
        }), 'Alipay paid amount does not match the order amount.')

        expect((await storage.getOrderStatus(
          cancelled.orderId,
          await storage.getOrderToken(cancelled.orderId),
        )).order.status).toBe('cancelled')
        expect((await storage.getOrderStatus(
          wrongAmount.orderId,
          await storage.getOrderToken(wrongAmount.orderId),
        )).order.status).toBe('pending_payment')
      })
    })

    testImpl('raises a quota error when credits are exhausted', async () => {
      await withStorage(createStorage, async (storage, unique) => {
        const registered = await storage.registerDevice({ deviceId: unique('device-quota') })
        await storage.consumeUsage(registered.deviceToken, 'message', 'deepseek-v4-flash', 5)

        await expectStorageError(
          () => storage.consumeUsage(registered.deviceToken, 'message', 'deepseek-v4-flash', 1),
          GatewayQuotaError,
        )
      })
    })
  })
}

async function withStorage(
  createStorage: CreateStorageContractInstance,
  run: (storage: GatewayStorage, unique: (label: string) => string) => Promise<void>,
): Promise<void> {
  const created = await createStorage()
  const instance = isStorageContractInstance(created)
    ? created
    : { storage: created }
  const suffix = `${Date.now()}-${Math.random().toString(16).slice(2)}`
  const unique = (label: string) => `${label}-${suffix}`.slice(0, 120)

  try {
    await run(instance.storage, unique)
  } finally {
    await instance.storage.close()
    await instance.cleanup?.()
  }
}

function isStorageContractInstance(value: GatewayStorage | StorageContractInstance): value is StorageContractInstance {
  return 'storage' in value
}

async function expectStorageError(
  action: () => unknown,
  expected?: string | ErrorClass,
): Promise<void> {
  let error: unknown
  try {
    await action()
  } catch (caught) {
    error = caught
  }
  expect(error).toBeTruthy()
  if (typeof expected === 'string') {
    expect(error instanceof Error ? error.message : String(error)).toContain(expected)
  } else if (expected) {
    expect(error).toBeInstanceOf(expected)
  }
}
